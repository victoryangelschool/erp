"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface SchoolInfo {
  name: string;
  motto: string;
  phone: string;
  email: string;
  address: string;
  logoUrl: string;
}

const defaults: SchoolInfo = {
  name: "Starlight Academy",
  motto: "Excellence, Integrity, Growth",
  phone: "+233 20 000 0000",
  email: "admin@starlight.edu.gh",
  address: "Accra, Ghana",
  logoUrl: "",
};

const SchoolContext = createContext<SchoolInfo>(defaults);

export function useSchool() { return useContext(SchoolContext); }

export default function SchoolProvider({ children }: { children: ReactNode }) {
  const [info, setInfo] = useState<SchoolInfo>(defaults);

  useEffect(() => {
    fetch("/api/school-profile")
      .then(r => r.json())
      .then(data => {
        if (data && data.name) {
          setInfo({
            name: data.name || defaults.name,
            motto: data.motto || defaults.motto,
            phone: data.phone || defaults.phone,
            email: data.email || defaults.email,
            address: data.address || defaults.address,
            logoUrl: data.logoUrl || "",
          });
        }
      })
      .catch(() => {});
  }, []);

  return <SchoolContext.Provider value={info}>{children}</SchoolContext.Provider>;
}
