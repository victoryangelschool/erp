"use client";

import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";
import { AuthUser, getUserFromCookie, clearAuthCookie } from "@/lib/auth";

interface AuthContextType {
  user: AuthUser | null;
  loading: boolean;
  login: (user: AuthUser) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  login: () => {},
  logout: () => {},
});

export function useAuth() {
  return useContext(AuthContext);
}

export default function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  // Read cookie on mount
  useEffect(() => {
    setUser(getUserFromCookie());
    setLoading(false);
  }, []);

  const login = useCallback((u: AuthUser) => {
    document.cookie = `erp_user=${encodeURIComponent(JSON.stringify(u))}; path=/; max-age=86400`;
    setUser(u);
    // Full page navigation — ensures clean server render with cookie present
    window.location.href = "/";
  }, []);

  const logout = useCallback(() => {
    clearAuthCookie();
    setUser(null);
    window.location.href = "/login";
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
