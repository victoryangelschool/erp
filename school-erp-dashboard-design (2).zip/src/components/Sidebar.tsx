"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "./AuthProvider";
import { useSchool } from "./SchoolProvider";
import { getVisibleNavItems } from "@/lib/auth";

export default function Sidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const school = useSchool();

  const visibleItems = getVisibleNavItems(user?.role || null);

  return (
    <aside className="hidden lg:flex w-80 flex-col fixed inset-y-0 z-30 glass border-r border-slate-700/40">
      <div className="p-6 border-b border-slate-700/40">
        <div className="flex items-center gap-4">
          {school.logoUrl ? (
            <img src={school.logoUrl} alt="Logo" className="w-14 h-14 rounded-2xl object-cover border border-white/10" />
          ) : (
            <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center overflow-hidden border border-white/10">
              <span className="text-2xl font-black text-sky-300">{school.name.charAt(0)}</span>
            </div>
          )}
          <div className="min-w-0">
            <h1 className="text-xl font-bold truncate">{school.name}</h1>
            <p className="text-sm text-slate-300 truncate">{school.motto}</p>
          </div>
        </div>
      </div>

      <nav className="p-4 space-y-2 overflow-y-auto flex-1">
        {visibleItems.map((item) => {
          const isActive = pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href));
          return (
            <Link key={item.href} href={item.href}
              className={`sidebar-item w-full text-left px-4 py-3 rounded-xl transition flex items-center ${isActive ? "active" : "hover:bg-white/5"}`}>
              <i className={`fas ${item.icon} mr-3 w-5`}></i>{item.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-5 border-t border-slate-700/40">
        {user ? (
          <div className="card rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-sky-500/20 flex items-center justify-center">
                <i className="fas fa-user text-sky-400"></i>
              </div>
              <div className="min-w-0">
                <p className="font-semibold text-sm truncate">{user.fullName}</p>
                <p className="text-xs text-slate-400 capitalize">{user.role}</p>
              </div>
            </div>
            <button onClick={logout} className="w-full py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 text-sm font-semibold transition">
              <i className="fas fa-sign-out-alt mr-2"></i>Logout
            </button>
          </div>
        ) : (
          <div className="card rounded-2xl p-4 text-center">
            <a href="/login" className="text-sky-400 hover:text-sky-300 font-semibold text-sm"><i className="fas fa-sign-in-alt mr-2"></i>Login</a>
          </div>
        )}
      </div>
    </aside>
  );
}
