"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "./AuthProvider";
import { getVisibleNavItems } from "@/lib/auth";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pathname = usePathname();
  const { user, logout } = useAuth();

  const visibleItems = getVisibleNavItems(user?.role || null);

  return (
    <header className="sticky top-0 z-20 glass border-b border-slate-700/40">
      <div className="px-4 sm:px-6 py-4 flex flex-col lg:flex-row lg:items-center gap-4 justify-between">
        <div className="flex items-center gap-3">
          <button
            className="lg:hidden btn px-4 py-2 rounded-xl bg-slate-800/80 border border-slate-600"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <i className="fas fa-bars"></i>
          </button>
          <div>
            <h2 className="text-2xl font-bold">School ERP System</h2>
            <p className="text-sm text-slate-300">Comprehensive solution for school management</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-sm">
            Academic Year: <span className="text-sky-300 font-semibold">2025/2026</span>
          </div>
          <div className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-sm">
            Term: <span className="text-emerald-300 font-semibold">First Term</span>
          </div>
          {user && (
            <div className="flex items-center gap-2">
              <span className="px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-sm">
                <i className="fas fa-user mr-1 text-sky-400"></i>
                {user.fullName}
                <span className="ml-2 px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-400 text-xs capitalize">{user.role}</span>
              </span>
              <button onClick={logout} className="btn px-3 py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 text-sm" title="Logout">
                <i className="fas fa-sign-out-alt"></i>
              </button>
            </div>
          )}
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="lg:hidden px-4 pb-4">
          <div className="card rounded-2xl p-3 grid grid-cols-2 gap-2">
            {visibleItems.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`sidebar-item px-3 py-3 rounded-xl text-left ${isActive ? "active" : ""}`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <i className={`fas ${item.icon} mr-2`}></i> {item.label}
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
}
