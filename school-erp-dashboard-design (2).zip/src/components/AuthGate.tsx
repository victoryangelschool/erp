"use client";

import { ReactNode } from "react";
import { useAuth } from "./AuthProvider";

/**
 * Wraps page content. Shows nothing while loading,
 * redirects to /login if not authenticated.
 * Does NOT auto-redirect — just renders a login prompt.
 */
export default function AuthGate({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-spinner fa-spin text-3xl text-sky-400 mb-4"></i>
          <p className="text-slate-400">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    // Not logged in — show a redirect prompt
    if (typeof window !== "undefined") {
      window.location.href = "/login";
    }
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-lock text-3xl text-slate-500 mb-4"></i>
          <p className="text-slate-400">Please log in to continue.</p>
          <a href="/login" className="text-sky-400 hover:text-sky-300 mt-2 inline-block">Go to Login</a>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
