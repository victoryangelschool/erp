interface StatCardProps {
  icon: string;
  iconBg: string;
  iconColor: string;
  label: string;
  value: string | number;
}

export default function StatCard({
  icon,
  iconBg,
  iconColor,
  label,
  value,
}: StatCardProps) {
  return (
    <div className="stat-card card rounded-2xl p-6">
      <div className="flex items-center">
        <div className={`p-3 rounded-xl ${iconBg} ${iconColor}`}>
          <i className={`fas ${icon} text-2xl`}></i>
        </div>
        <div className="ml-4">
          <p className="text-slate-400">{label}</p>
          <p className="text-3xl font-bold">{value}</p>
        </div>
      </div>
    </div>
  );
}
