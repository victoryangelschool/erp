import {
  pgTable,
  serial,
  text,
  varchar,
  timestamp,
  integer,
  decimal,
  boolean,
  date,
  pgEnum,
} from "drizzle-orm/pg-core";

// Enums
export const genderEnum = pgEnum("gender", ["male", "female", "other"]);
export const statusEnum = pgEnum("status", ["active", "inactive", "suspended"]);
export const attendanceStatusEnum = pgEnum("attendance_status", ["present", "absent", "late", "excused"]);
export const paymentStatusEnum = pgEnum("payment_status", ["pending", "paid", "overdue", "partial"]);
export const inventoryStatusEnum = pgEnum("inventory_status", ["in_stock", "low_stock", "out_of_stock"]);
export const assetStatusEnum = pgEnum("asset_status", ["operational", "maintenance", "retired", "needs_upgrade"]);
export const userRoleEnum = pgEnum("user_role", ["admin", "headmaster", "finance", "registrar", "teacher"]);

// School Profile
export const schoolProfile = pgTable("school_profile", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull().default("Starlight Academy"),
  motto: varchar("motto", { length: 500 }).default("Excellence, Integrity, Growth"),
  phone: varchar("phone", { length: 50 }),
  email: varchar("email", { length: 255 }),
  address: text("address"),
  logoUrl: text("logo_url"),
  academicYear: varchar("academic_year", { length: 20 }).default("2025/2026"),
  currentTerm: varchar("current_term", { length: 50 }).default("First Term"),
  currency: varchar("currency", { length: 10 }).default("GHS"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Classes
export const classes = pgTable("classes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  level: varchar("level", { length: 50 }),
  capacity: integer("capacity").default(40),
  teacherId: integer("teacher_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Students
export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  studentId: varchar("student_id", { length: 20 }).notNull().unique(),
  firstName: varchar("first_name", { length: 100 }).notNull(),
  lastName: varchar("last_name", { length: 100 }).notNull(),
  dateOfBirth: date("date_of_birth"),
  gender: genderEnum("gender"),
  classId: integer("class_id").references(() => classes.id),
  parentName: varchar("parent_name", { length: 255 }),
  parentPhone: varchar("parent_phone", { length: 50 }),
  parentEmail: varchar("parent_email", { length: 255 }),
  guardianPhotoUrl: text("guardian_photo_url"),
  address: text("address"),
  gpsLocation: varchar("gps_location", { length: 100 }),
  admissionDate: date("admission_date"),
  status: statusEnum("status").default("active"),
  enrollmentDate: date("enrollment_date").defaultNow(),
  photoUrl: text("photo_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Staff
export const staff = pgTable("staff", {
  id: serial("id").primaryKey(),
  staffId: varchar("staff_id", { length: 20 }).notNull().unique(),
  firstName: varchar("first_name", { length: 100 }).notNull(),
  lastName: varchar("last_name", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }),
  phone: varchar("phone", { length: 50 }),
  position: varchar("position", { length: 100 }).notNull(),
  department: varchar("department", { length: 100 }),
  qualification: varchar("qualification", { length: 255 }),
  yearsOfExperience: integer("years_of_experience"),
  careerStatement: text("career_statement"),
  taxId: varchar("tax_id", { length: 50 }),
  ssnitNumber: varchar("ssnit_number", { length: 50 }),
  basicSalary: decimal("basic_salary", { precision: 12, scale: 2 }).default("0"),
  allowances: decimal("allowances", { precision: 12, scale: 2 }).default("0"),
  hireDate: date("hire_date"),
  status: statusEnum("status").default("active"),
  photoUrl: text("photo_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Daily Sign-In / Sign-Out Log
export const signLog = pgTable("sign_log", {
  id: serial("id").primaryKey(),
  personType: varchar("person_type", { length: 10 }).notNull(), // "student" | "staff"
  personId: integer("person_id").notNull(),
  personCode: varchar("person_code", { length: 20 }).notNull(),
  action: varchar("action", { length: 10 }).notNull(), // "sign_in" | "sign_out"
  method: varchar("method", { length: 20 }).notNull(), // "id" | "qr"
  date: date("date").notNull(),
  time: varchar("time", { length: 10 }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Attendance
export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  studentId: integer("student_id").references(() => students.id),
  staffId: integer("staff_id").references(() => staff.id),
  status: attendanceStatusEnum("status").notNull(),
  timeIn: varchar("time_in", { length: 10 }),
  timeOut: varchar("time_out", { length: 10 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Subjects
export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  code: varchar("code", { length: 20 }),
  description: text("description"),
  classId: integer("class_id").references(() => classes.id),
  teacherId: integer("teacher_id").references(() => staff.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Grades/Results
export const grades = pgTable("grades", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => students.id).notNull(),
  subjectId: integer("subject_id").references(() => subjects.id).notNull(),
  term: varchar("term", { length: 50 }),
  academicYear: varchar("academic_year", { length: 20 }),
  classScore: decimal("class_score", { precision: 5, scale: 2 }),
  examScore: decimal("exam_score", { precision: 5, scale: 2 }),
  totalScore: decimal("total_score", { precision: 5, scale: 2 }),
  grade: varchar("grade", { length: 5 }),
  remarks: text("remarks"),
  scoreWeight: varchar("score_weight", { length: 10 }).default("30:70"), // "30:70" | "40:60" | "50:50"
  createdAt: timestamp("created_at").defaultNow(),
});

// Fee Structure
export const feeStructure = pgTable("fee_structure", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  classId: integer("class_id").references(() => classes.id),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  term: varchar("term", { length: 50 }),
  academicYear: varchar("academic_year", { length: 20 }),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Fee Payments
export const feePayments = pgTable("fee_payments", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => students.id).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  paymentDate: date("payment_date").defaultNow(),
  paymentMethod: varchar("payment_method", { length: 50 }),
  receiptNumber: varchar("receipt_number", { length: 50 }),
  term: varchar("term", { length: 50 }),
  academicYear: varchar("academic_year", { length: 20 }),
  status: paymentStatusEnum("status").default("paid"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Payroll
export const payroll = pgTable("payroll", {
  id: serial("id").primaryKey(),
  staffId: integer("staff_id").references(() => staff.id).notNull(),
  payPeriod: varchar("pay_period", { length: 50 }).notNull(),
  basicSalary: decimal("basic_salary", { precision: 12, scale: 2 }).notNull(),
  // Itemised allowances
  transportAllowance: decimal("transport_allowance", { precision: 12, scale: 2 }).default("0"),
  healthAllowance: decimal("health_allowance", { precision: 12, scale: 2 }).default("0"),
  rentAllowance: decimal("rent_allowance", { precision: 12, scale: 2 }).default("0"),
  responsibilityAllowance: decimal("responsibility_allowance", { precision: 12, scale: 2 }).default("0"),
  overtimeAllowance: decimal("overtime_allowance", { precision: 12, scale: 2 }).default("0"),
  feedingAllowance: decimal("feeding_allowance", { precision: 12, scale: 2 }).default("0"),
  totalAllowances: decimal("total_allowances", { precision: 12, scale: 2 }).default("0"),
  grossPay: decimal("gross_pay", { precision: 12, scale: 2 }).default("0"),
  // Deductions
  ssnitDeduction: decimal("ssnit_deduction", { precision: 12, scale: 2 }).default("0"),
  payeDeduction: decimal("paye_deduction", { precision: 12, scale: 2 }).default("0"),
  loanDeduction: decimal("loan_deduction", { precision: 12, scale: 2 }).default("0"),
  otherDeductions: decimal("other_deductions", { precision: 12, scale: 2 }).default("0"),
  totalDeductions: decimal("total_deductions", { precision: 12, scale: 2 }).default("0"),
  netPay: decimal("net_pay", { precision: 12, scale: 2 }).notNull(),
  paymentDate: date("payment_date"),
  status: paymentStatusEnum("status").default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Staff Loans / Salary Advances
export const staffLoans = pgTable("staff_loans", {
  id: serial("id").primaryKey(),
  staffId: integer("staff_id").references(() => staff.id).notNull(),
  type: varchar("type", { length: 50 }).notNull(), // "loan" | "salary_advance"
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  monthlyDeduction: decimal("monthly_deduction", { precision: 12, scale: 2 }).notNull(),
  totalRepaid: decimal("total_repaid", { precision: 12, scale: 2 }).default("0"),
  balance: decimal("balance", { precision: 12, scale: 2 }).notNull(),
  startDate: date("start_date"),
  description: text("description"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Inventory
export const inventory = pgTable("inventory", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }),
  quantity: integer("quantity").notNull().default(0),
  unitPrice: decimal("unit_price", { precision: 12, scale: 2 }).default("0"),
  reorderLevel: integer("reorder_level").default(10),
  supplier: varchar("supplier", { length: 255 }),
  location: varchar("location", { length: 255 }),
  status: inventoryStatusEnum("status").default("in_stock"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Assets
export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  assetId: varchar("asset_id", { length: 20 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }),
  photoUrl: text("photo_url"),
  purchaseDate: date("purchase_date"),
  purchaseCost: decimal("purchase_cost", { precision: 12, scale: 2 }),
  depreciation: decimal("depreciation", { precision: 12, scale: 2 }).default("0"),
  currentValue: decimal("current_value", { precision: 12, scale: 2 }),
  location: varchar("location", { length: 255 }),
  status: assetStatusEnum("status").default("operational"),
  lastMaintenanceDate: date("last_maintenance_date"),
  nextMaintenanceDate: date("next_maintenance_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Feeding/Meals
export const feedingMenu = pgTable("feeding_menu", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  mealType: varchar("meal_type", { length: 50 }).notNull(), // breakfast, lunch, supper
  description: text("description"),
  startTime: varchar("start_time", { length: 10 }),
  endTime: varchar("end_time", { length: 10 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const kitchenInventory = pgTable("kitchen_inventory", {
  id: serial("id").primaryKey(),
  itemName: varchar("item_name", { length: 255 }).notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unit: varchar("unit", { length: 20 }),
  reorderLevel: decimal("reorder_level", { precision: 10, scale: 2 }).default("5"),
  status: inventoryStatusEnum("status").default("in_stock"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Daily Kitchen Inventory Request Batches
export const dailyRequestBatches = pgTable("daily_request_batches", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  requestedBy: varchar("requested_by", { length: 255 }),
  purpose: text("purpose"),
  status: varchar("request_status", { length: 20 }).default("pending"), // pending, approved, issued
  createdAt: timestamp("created_at").defaultNow(),
});

// Daily Kitchen Inventory Request Items (children of a batch)
export const dailyRequestItems = pgTable("daily_request_items", {
  id: serial("id").primaryKey(),
  batchId: integer("batch_id").references(() => dailyRequestBatches.id).notNull(),
  inventoryItemId: integer("inventory_item_id").references(() => kitchenInventory.id),
  itemName: varchar("item_name", { length: 255 }).notNull(),
  quantityRequested: decimal("quantity_requested", { precision: 10, scale: 2 }).notNull(),
  unit: varchar("unit", { length: 20 }),
});

// Activities Log
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  type: varchar("type", { length: 100 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  entityType: varchar("entity_type", { length: 50 }),
  entityId: integer("entity_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Transaction type enum
export const transactionTypeEnum = pgEnum("transaction_type", ["income", "expense"]);

// Income Items (categories of income)
export const incomeItems = pgTable("income_items", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Expense Items (categories of expense)
export const expenseItems = pgTable("expense_items", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Transactions (income & expense records)
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  type: transactionTypeEnum("type").notNull(),
  categoryId: integer("category_id").notNull(), // references incomeItems or expenseItems
  categoryName: varchar("category_name", { length: 255 }).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  description: text("description"),
  reference: varchar("reference", { length: 100 }),
  paymentMethod: varchar("payment_method", { length: 50 }),
  paidTo: varchar("paid_to", { length: 255 }), // for expenses
  receivedFrom: varchar("received_from", { length: 255 }), // for income
  transactionDate: date("transaction_date").defaultNow(),
  term: varchar("term", { length: 50 }),
  academicYear: varchar("academic_year", { length: 20 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Assessments
export const assessments = pgTable("assessments", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(), // quiz, assignment, exam, test
  subjectId: integer("subject_id").references(() => subjects.id),
  classId: integer("class_id").references(() => classes.id),
  totalMarks: integer("total_marks").default(100),
  date: date("date"),
  term: varchar("term", { length: 50 }),
  academicYear: varchar("academic_year", { length: 20 }),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Continuous Assessment Scores
export const caScores = pgTable("ca_scores", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => students.id).notNull(),
  subjectId: integer("subject_id").references(() => subjects.id).notNull(),
  classId: integer("class_id").references(() => classes.id),
  assessmentTitle: varchar("assessment_title", { length: 255 }).notNull(),
  assessmentType: varchar("assessment_type", { length: 50 }).notNull(), // quiz, test, homework, classwork, project
  scoreObtained: decimal("score_obtained", { precision: 5, scale: 2 }).notNull(),
  totalMarks: decimal("total_marks", { precision: 5, scale: 2 }).notNull(),
  date: date("date"),
  term: varchar("term", { length: 50 }).notNull(),
  academicYear: varchar("academic_year", { length: 20 }).notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Timetable Entries
export const timetableEntries = pgTable("timetable_entries", {
  id: serial("id").primaryKey(),
  classId: integer("class_id").references(() => classes.id),
  subjectId: integer("subject_id").references(() => subjects.id),
  teacherId: integer("teacher_id").references(() => staff.id),
  dayOfWeek: varchar("day_of_week", { length: 15 }).notNull(), // Monday..Friday
  startTime: varchar("start_time", { length: 10 }).notNull(),
  endTime: varchar("end_time", { length: 10 }).notNull(),
  room: varchar("room", { length: 50 }),
  term: varchar("term", { length: 50 }),
  academicYear: varchar("academic_year", { length: 20 }),
  createdAt: timestamp("created_at").defaultNow(),
});

// Student Bills
export const studentBills = pgTable("student_bills", {
  id: serial("id").primaryKey(),
  billNumber: varchar("bill_number", { length: 30 }).notNull().unique(),
  studentId: integer("student_id").references(() => students.id).notNull(),
  term: varchar("term", { length: 50 }).notNull(),
  academicYear: varchar("academic_year", { length: 20 }).notNull(),
  totalAmount: decimal("total_amount", { precision: 12, scale: 2 }).notNull(),
  amountPaid: decimal("amount_paid", { precision: 12, scale: 2 }).default("0"),
  balance: decimal("balance", { precision: 12, scale: 2 }).notNull(),
  status: varchar("bill_status", { length: 20 }).default("unpaid"), // unpaid, partial, paid
  createdAt: timestamp("created_at").defaultNow(),
});

// Student Bill Items (line items on a bill)
export const studentBillItems = pgTable("student_bill_items", {
  id: serial("id").primaryKey(),
  billId: integer("bill_id").references(() => studentBills.id).notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
});

// Student Bill Payments (installments)
export const studentBillPayments = pgTable("student_bill_payments", {
  id: serial("id").primaryKey(),
  billId: integer("bill_id").references(() => studentBills.id).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  paymentDate: date("payment_date").defaultNow(),
  paymentMethod: varchar("payment_method", { length: 50 }),
  receiptNumber: varchar("receipt_number", { length: 50 }),
  receivedBy: varchar("received_by", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow(),
});

// System Users (Role-Based Access)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  role: userRoleEnum("role").notNull(),
  fullName: varchar("full_name", { length: 255 }).notNull(),
  staffId: integer("staff_id").references(() => staff.id),
  classId: integer("class_id").references(() => classes.id), // for teachers: their assigned class
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});
