"use client";

import { useEffect, useRef } from "react";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
declare const ApexCharts: any;

declare global {
  interface Window {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    ApexCharts: any;
  }
}

export default function DashboardCharts() {
  const chartRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const loadChart = async () => {
      // Dynamically load ApexCharts
      if (typeof window !== "undefined" && !window.ApexCharts) {
        const script = document.createElement("script");
        script.src = "https://cdn.jsdelivr.net/npm/apexcharts";
        script.async = true;
        document.head.appendChild(script);

        await new Promise((resolve) => {
          script.onload = resolve;
        });
      }

      if (chartRef.current && window.ApexCharts) {
        const options = {
          series: [
            {
              name: "Enrollment",
              data: [1200, 1350, 1480, 1620, 1780, 1950, 2100, 2250, 2400, 2450],
            },
            {
              name: "Revenue (K)",
              data: [800, 900, 1000, 1100, 1150, 1180, 1200, 1220, 1240, 1260],
            },
          ],
          chart: {
            type: "area" as const,
            height: 300,
            toolbar: { show: false },
            background: "transparent",
          },
          colors: ["#5b8cff", "#22c55e"],
          dataLabels: { enabled: false },
          stroke: { curve: "smooth" as const, width: 2 },
          fill: {
            type: "gradient",
            gradient: {
              shade: "dark",
              gradientToColors: ["#5b8cff", "#22c55e"],
              opacityFrom: 0.3,
              opacityTo: 0.1,
            },
          },
          xaxis: {
            categories: [
              "Jan",
              "Feb",
              "Mar",
              "Apr",
              "May",
              "Jun",
              "Jul",
              "Aug",
              "Sep",
              "Oct",
            ],
            labels: { style: { colors: "#9fb0d0" } },
          },
          yaxis: {
            labels: { style: { colors: "#9fb0d0" } },
          },
          grid: { borderColor: "#334155" },
          tooltip: { theme: "dark" },
          legend: {
            labels: { colors: "#9fb0d0" },
          },
        };

        chartRef.current.innerHTML = "";
        const chart = new window.ApexCharts(chartRef.current, options);
        chart.render();

        return () => {
          chart.destroy();
        };
      }
    };

    loadChart();
  }, []);

  return <div ref={chartRef} className="mt-6 min-h-[300px]"></div>;
}
