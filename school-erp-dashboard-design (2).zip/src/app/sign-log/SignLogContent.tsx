"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import jsQR from "jsqr";

interface LogEntry {
  id: number;
  personType: string;
  personId: number;
  personCode: string;
  action: string;
  method: string;
  date: string;
  time: string;
  name?: string;
}

export default function SignLogContent({ initialLogs }: { initialLogs: LogEntry[] }) {
  const [logs, setLogs] = useState<LogEntry[]>(initialLogs);
  const [code, setCode] = useState("");
  const [action, setAction] = useState<"sign_in" | "sign_out">("sign_in");
  const [method, setMethod] = useState<"id" | "qr">("id");
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<{ type: "success" | "error"; message: string } | null>(null);
  const [dateFilter, setDateFilter] = useState(new Date().toISOString().split("T")[0]);

  // QR camera state
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState("");
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Submit sign-in/out
  const submitCode = useCallback(async (scannedCode: string, usedMethod: "id" | "qr") => {
    if (!scannedCode.trim()) return;
    setBusy(true);
    setFeedback(null);
    try {
      const res = await fetch("/api/sign-log", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: scannedCode.trim().toUpperCase(), action, method: usedMethod }),
      });
      const data = await res.json();
      if (res.ok) {
        setLogs((prev) => [data, ...prev]);
        setFeedback({
          type: "success",
          message: `${data.name || data.personCode} — ${action === "sign_in" ? "Signed In" : "Signed Out"} at ${data.time}`,
        });
        setCode("");
      } else {
        setFeedback({ type: "error", message: data.error || "Failed" });
      }
    } catch {
      setFeedback({ type: "error", message: "Network error" });
    } finally {
      setBusy(false);
    }
  }, [action]);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitCode(code, method);
  };

  // ──── Camera QR scanning ────

  const stopCamera = useCallback(() => {
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current);
      scanIntervalRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  }, []);

  const startCamera = useCallback(async () => {
    setCameraError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 640 }, height: { ideal: 480 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute("playsinline", "true");
        await videoRef.current.play();
      }
      setCameraActive(true);

      // Start scanning loop
      scanIntervalRef.current = setInterval(() => {
        if (!videoRef.current || !canvasRef.current) return;
        const video = videoRef.current;
        const canvas = canvasRef.current;
        if (video.readyState !== video.HAVE_ENOUGH_DATA) return;

        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const qrResult = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: "dontInvert",
        });
        if (qrResult && qrResult.data) {
          // Found a QR code! Stop scanning and submit
          stopCamera();
          setCode(qrResult.data);
          submitCode(qrResult.data, "qr");
        }
      }, 250);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Unknown error";
      if (msg.includes("NotAllowed") || msg.includes("Permission")) {
        setCameraError("Camera permission denied. Please allow camera access in your browser settings.");
      } else if (msg.includes("NotFound") || msg.includes("DevicesNotFound")) {
        setCameraError("No camera found on this device.");
      } else {
        setCameraError(`Camera error: ${msg}`);
      }
    }
  }, [stopCamera, submitCode]);

  // Cleanup on unmount or method change
  useEffect(() => {
    return () => { stopCamera(); };
  }, [stopCamera]);

  // When switching to QR mode, auto-start camera
  useEffect(() => {
    if (method === "qr") {
      startCamera();
    } else {
      stopCamera();
    }
  }, [method, startCamera, stopCamera]);

  const loadDate = async (date: string) => {
    setDateFilter(date);
    try {
      const res = await fetch(`/api/sign-log?date=${date}`);
      if (res.ok) setLogs(await res.json());
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <section className="fade-up space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Sign In / Sign Out</h2>
        <p className="text-slate-400">
          Quick sign-in and sign-out for students and staff using their ID or QR code
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ── Left panel ── */}
        <div className="card rounded-3xl p-6">
          <h3 className="text-2xl font-bold mb-5">Record Entry / Exit</h3>

          {/* action toggle */}
          <div className="flex gap-2 mb-4">
            <button
              type="button"
              onClick={() => setAction("sign_in")}
              className={`flex-1 py-4 rounded-xl text-lg font-bold transition border ${
                action === "sign_in"
                  ? "bg-emerald-500 border-emerald-400 text-white"
                  : "bg-white/5 border-white/10 hover:bg-white/10 text-slate-300"
              }`}
            >
              <i className="fas fa-sign-in-alt mr-2"></i>Sign In
            </button>
            <button
              type="button"
              onClick={() => setAction("sign_out")}
              className={`flex-1 py-4 rounded-xl text-lg font-bold transition border ${
                action === "sign_out"
                  ? "bg-red-500 border-red-400 text-white"
                  : "bg-white/5 border-white/10 hover:bg-white/10 text-slate-300"
              }`}
            >
              <i className="fas fa-sign-out-alt mr-2"></i>Sign Out
            </button>
          </div>

          {/* method toggle */}
          <div className="mb-4">
            <label className="text-sm text-slate-300">Method</label>
            <div className="flex gap-2 mt-2">
              <button
                type="button"
                onClick={() => setMethod("id")}
                className={`flex-1 py-3 rounded-xl text-sm font-semibold transition border ${
                  method === "id"
                    ? "bg-sky-500 border-sky-400 text-white"
                    : "bg-white/5 border-white/10 hover:bg-white/10 text-slate-300"
                }`}
              >
                <i className="fas fa-keyboard mr-2"></i>Type ID
              </button>
              <button
                type="button"
                onClick={() => setMethod("qr")}
                className={`flex-1 py-3 rounded-xl text-sm font-semibold transition border ${
                  method === "qr"
                    ? "bg-sky-500 border-sky-400 text-white"
                    : "bg-white/5 border-white/10 hover:bg-white/10 text-slate-300"
                }`}
              >
                <i className="fas fa-camera mr-2"></i>Scan QR Code
              </button>
            </div>
          </div>

          {/* ── ID input mode ── */}
          {method === "id" && (
            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div>
                <label className="text-sm text-slate-300">Enter ID (e.g. STU001 or STF001)</label>
                <input
                  className="input mt-2 text-lg text-center font-mono tracking-wider"
                  placeholder="STU001 or STF001"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  autoFocus
                  required
                />
              </div>
              <button
                type="submit"
                disabled={busy}
                className={`btn w-full py-4 rounded-xl text-white font-bold text-lg disabled:opacity-50 ${
                  action === "sign_in"
                    ? "bg-emerald-500 hover:bg-emerald-400"
                    : "bg-red-500 hover:bg-red-400"
                }`}
              >
                {busy ? (
                  <><i className="fas fa-spinner fa-spin mr-2"></i>Processing…</>
                ) : (
                  <><i className="fas fa-check mr-2"></i>Confirm {action === "sign_in" ? "Sign In" : "Sign Out"}</>
                )}
              </button>
            </form>
          )}

          {/* ── QR camera mode ── */}
          {method === "qr" && (
            <div className="space-y-4">
              {cameraError && (
                <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
                  <i className="fas fa-exclamation-triangle mr-2"></i>{cameraError}
                  <button
                    onClick={startCamera}
                    className="ml-3 underline hover:text-red-300"
                  >
                    Retry
                  </button>
                </div>
              )}

              <div className="relative rounded-2xl overflow-hidden bg-black aspect-video flex items-center justify-center">
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  muted
                  playsInline
                />
                {/* Hidden canvas for QR processing */}
                <canvas ref={canvasRef} className="hidden" />

                {/* Scanning overlay */}
                {cameraActive && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-48 h-48 border-2 border-sky-400 rounded-2xl relative">
                      <div className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-sky-400 rounded-tl-lg"></div>
                      <div className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-sky-400 rounded-tr-lg"></div>
                      <div className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-sky-400 rounded-bl-lg"></div>
                      <div className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-sky-400 rounded-br-lg"></div>
                    </div>
                  </div>
                )}

                {!cameraActive && !cameraError && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400">
                    <i className="fas fa-camera text-4xl mb-3"></i>
                    <p className="text-sm">Starting camera...</p>
                  </div>
                )}
              </div>

              <p className="text-sm text-slate-400 text-center">
                <i className="fas fa-info-circle mr-1"></i>
                Point the camera at a student or staff ID card QR code. It will auto-detect and submit.
              </p>

              {!cameraActive && !cameraError && (
                <button
                  onClick={startCamera}
                  className="btn w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold"
                >
                  <i className="fas fa-camera mr-2"></i>Open Camera
                </button>
              )}

              {cameraActive && (
                <button
                  onClick={stopCamera}
                  className="btn w-full py-3 rounded-xl bg-slate-600 hover:bg-slate-500 text-white font-semibold"
                >
                  <i className="fas fa-stop mr-2"></i>Stop Camera
                </button>
              )}
            </div>
          )}

          {/* feedback */}
          {feedback && (
            <div
              className={`mt-4 p-4 rounded-xl border text-center font-semibold ${
                feedback.type === "success"
                  ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                  : "bg-red-500/10 border-red-500/30 text-red-400"
              }`}
            >
              <i className={`fas ${feedback.type === "success" ? "fa-check-circle" : "fa-exclamation-circle"} mr-2`}></i>
              {feedback.message}
            </div>
          )}
        </div>

        {/* ── Right panel: log ── */}
        <div className="card rounded-3xl p-6">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-2xl font-bold">Activity Log</h3>
            <input
              type="date"
              className="input w-44"
              value={dateFilter}
              onChange={(e) => loadDate(e.target.value)}
            />
          </div>

          {logs.length === 0 ? (
            <div className="text-center py-16">
              <i className="fas fa-clipboard-list text-4xl text-slate-600 mb-4"></i>
              <p className="text-slate-400">No sign-in/out records for this date.</p>
            </div>
          ) : (
            <div className="table-wrap overflow-auto max-h-[500px]">
              <table className="min-w-full text-left text-sm">
                <thead className="text-slate-300 sticky top-0 bg-[#16213a]">
                  <tr className="border-b border-slate-700">
                    <th className="py-3 pr-4">Time</th>
                    <th className="py-3 pr-4">Type</th>
                    <th className="py-3 pr-4">ID</th>
                    <th className="py-3 pr-4">Action</th>
                    <th className="py-3 pr-4">Method</th>
                  </tr>
                </thead>
                <tbody>
                  {logs.map((log) => (
                    <tr key={log.id} className="border-b border-slate-800/70">
                      <td className="py-3 pr-4 font-mono">{log.time}</td>
                      <td className="py-3 pr-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${log.personType === "student" ? "bg-sky-500/20 text-sky-400" : "bg-green-500/20 text-green-400"}`}>
                          {log.personType === "student" ? "Student" : "Staff"}
                        </span>
                      </td>
                      <td className="py-3 pr-4 font-mono text-xs">{log.personCode}</td>
                      <td className="py-3 pr-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${log.action === "sign_in" ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}>
                          {log.action === "sign_in" ? "IN" : "OUT"}
                        </span>
                      </td>
                      <td className="py-3 pr-4 text-xs text-slate-400 capitalize">{log.method === "qr" ? "QR Scan" : "Manual ID"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
