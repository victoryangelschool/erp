import { db } from "@/db";
import { signLog } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import SignLogContent from "./SignLogContent";

export const dynamic = "force-dynamic";

export default async function SignLogPage() {
  const today = new Date().toISOString().split("T")[0];
  const logs = await db
    .select()
    .from(signLog)
    .where(eq(signLog.date, today))
    .orderBy(desc(signLog.createdAt))
    .limit(200);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6">
          <SignLogContent initialLogs={logs} />
        </main>
      </div>
    </div>
  );
}
