import { db } from "@/db";
import { assets } from "@/db/schema";
import { desc, sql } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import StatCard from "@/components/StatCard";
import AssetList from "./AssetList";

export const dynamic = "force-dynamic";

async function getStats() {
  const [total] = await db.select({ count: sql<number>`count(*)::int` }).from(assets);
  const [maint] = await db.select({ count: sql<number>`count(*)::int` }).from(assets).where(sql`status = 'maintenance'`);
  const [val] = await db.select({ total: sql<string>`COALESCE(SUM(current_value), 0)` }).from(assets);
  return {
    totalAssets: total.count,
    inMaintenance: maint.count,
    totalValue: parseFloat(val.total),
  };
}

function fmtCurrency(n: number) {
  if (n >= 1000000) return `GHS ${(n / 1000000).toFixed(1)}M`;
  return `GHS ${n.toLocaleString()}`;
}

export default async function AssetsPage() {
  const [stats, assetsList] = await Promise.all([
    getStats(),
    db.select().from(assets).orderBy(desc(assets.createdAt)),
  ]);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6 space-y-6">
          <section className="fade-up">
            <div className="mb-6">
              <h2 className="text-3xl font-bold">Asset Management</h2>
              <p className="text-slate-400">Track fixed assets, maintenance, and depreciation</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <StatCard icon="fa-tools" iconBg="bg-blue-500/20" iconColor="text-blue-400" label="Total Assets" value={stats.totalAssets} />
              <StatCard icon="fa-wrench" iconBg="bg-amber-500/20" iconColor="text-amber-400" label="In Maintenance" value={stats.inMaintenance} />
              <StatCard icon="fa-coins" iconBg="bg-green-500/20" iconColor="text-green-400" label="Total Asset Value" value={fmtCurrency(stats.totalValue)} />
            </div>
            <AssetList initialAssets={assetsList} />
          </section>
        </main>
      </div>
    </div>
  );
}
