"use client";

import { useState } from "react";
import Modal from "@/components/Modal";

interface Asset {
  id: number; assetId: string; name: string; category: string | null; photoUrl: string | null;
  purchaseDate: string | null; purchaseCost: string | null; depreciation: string | null;
  currentValue: string | null; location: string | null; status: string | null;
  lastMaintenanceDate: string | null; nextMaintenanceDate: string | null;
}

const CATEGORIES = ["Transportation", "ICT Equipment", "Infrastructure", "Furniture", "Sports", "Kitchen", "Office Equipment", "Other"];
const STATUSES: { value: string; label: string }[] = [
  { value: "operational", label: "Operational" },
  { value: "maintenance", label: "In Maintenance" },
  { value: "needs_upgrade", label: "Needs Upgrade" },
  { value: "retired", label: "Retired" },
];

function toBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader(); r.onload = () => resolve(r.result as string); r.onerror = reject; r.readAsDataURL(file);
  });
}

const p = (v: string | null) => parseFloat(v || "0");
const f = (n: number) => `GHS ${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const emptyForm = {
  name: "", category: "", photoUrl: "", purchaseDate: "", purchaseCost: "", depreciation: "0",
  currentValue: "", location: "", status: "operational",
  lastMaintenanceDate: "", nextMaintenanceDate: "",
};

export default function AssetList({ initialAssets }: { initialAssets: Asset[] }) {
  const [list, setList] = useState<Asset[]>(initialAssets);
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Asset | null>(null);
  const [form, setForm] = useState({ ...emptyForm });
  const [busy, setBusy] = useState(false);

  // Detail view
  const [detailModal, setDetailModal] = useState(false);
  const [selected, setSelected] = useState<Asset | null>(null);

  const filtered = list.filter(a =>
    `${a.name} ${a.assetId} ${a.category}`.toLowerCase().includes(search.toLowerCase())
  );

  const openAdd = () => { setEditing(null); setForm({ ...emptyForm }); setModal(true); };
  const openEdit = (a: Asset) => {
    setEditing(a);
    setForm({
      name: a.name, category: a.category || "", photoUrl: a.photoUrl || "",
      purchaseDate: a.purchaseDate || "", purchaseCost: a.purchaseCost || "",
      depreciation: a.depreciation || "0", currentValue: a.currentValue || "",
      location: a.location || "", status: a.status || "operational",
      lastMaintenanceDate: a.lastMaintenanceDate || "", nextMaintenanceDate: a.nextMaintenanceDate || "",
    });
    setModal(true);
  };
  const openDetail = (a: Asset) => { setSelected(a); setDetailModal(true); };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    setForm({ ...form, photoUrl: await toBase64(file) });
  };

  // Auto-calculate current value when cost or depreciation changes
  const updateCost = (field: string, value: string) => {
    const next = { ...form, [field]: value };
    if (field === "purchaseCost" || field === "depreciation") {
      const cost = parseFloat(field === "purchaseCost" ? value : next.purchaseCost) || 0;
      const dep = parseFloat(field === "depreciation" ? value : next.depreciation) || 0;
      next.currentValue = Math.max(0, cost - dep).toString();
    }
    setForm(next);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    try {
      if (editing) {
        const res = await fetch(`/api/assets/${editing.id}`, {
          method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form),
        });
        if (res.ok) { const updated = await res.json(); setList(list.map(a => a.id === updated.id ? updated : a)); setModal(false); }
      } else {
        const res = await fetch("/api/assets", {
          method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form),
        });
        if (res.ok) { const created = await res.json(); setList([created, ...list]); setModal(false); }
      }
    } catch (err) { console.error(err); } finally { setBusy(false); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this asset?")) return;
    const res = await fetch(`/api/assets/${id}`, { method: "DELETE" });
    if (res.ok) setList(list.filter(a => a.id !== id));
  };

  const statusBadge = (s: string | null) => {
    const map: Record<string, string> = {
      operational: "bg-emerald-500/20 text-emerald-400",
      maintenance: "bg-amber-500/20 text-amber-400",
      needs_upgrade: "bg-blue-500/20 text-blue-400",
      retired: "bg-red-500/20 text-red-400",
    };
    const labels: Record<string, string> = {
      operational: "Operational", maintenance: "In Maintenance",
      needs_upgrade: "Needs Upgrade", retired: "Retired",
    };
    return <span className={`px-2 py-1 rounded-full text-xs font-semibold ${map[s || ""] || "bg-slate-500/20 text-slate-400"}`}>{labels[s || ""] || "Unknown"}</span>;
  };

  return (
    <>
      <div className="card rounded-3xl p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-5">
          <h3 className="text-2xl font-bold">Asset Register</h3>
          <div className="flex gap-3">
            <input className="input max-w-xs" placeholder="Search assets..." value={search} onChange={e => setSearch(e.target.value)} />
            <button onClick={openAdd} className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold whitespace-nowrap">
              <i className="fas fa-plus mr-2"></i>Add Asset
            </button>
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-16">
            <i className="fas fa-tools text-4xl text-slate-600 mb-4"></i>
            <p className="text-slate-400">No assets found. Click &quot;Add Asset&quot; to register one.</p>
          </div>
        ) : (
          <div className="table-wrap overflow-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-300">
                <tr className="border-b border-slate-700">
                  <th className="py-3 pr-3">Photo</th>
                  <th className="py-3 pr-3">Asset ID</th>
                  <th className="py-3 pr-3">Name</th>
                  <th className="py-3 pr-3">Category</th>
                  <th className="py-3 pr-3">Purchase Date</th>
                  <th className="py-3 pr-3 text-right">Cost</th>
                  <th className="py-3 pr-3 text-right">Current Value</th>
                  <th className="py-3 pr-3">Location</th>
                  <th className="py-3 pr-3">Status</th>
                  <th className="py-3 pr-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(a => (
                  <tr key={a.id} className="border-b border-slate-800/70">
                    <td className="py-3 pr-3">
                      {a.photoUrl
                        ? <img src={a.photoUrl} alt="" className="w-10 h-10 rounded-lg object-cover" />
                        : <div className="w-10 h-10 rounded-lg bg-slate-700/50 flex items-center justify-center"><i className="fas fa-image text-slate-500"></i></div>
                      }
                    </td>
                    <td className="py-3 pr-3 font-mono text-xs text-sky-300">{a.assetId}</td>
                    <td className="py-3 pr-3 font-semibold">{a.name}</td>
                    <td className="py-3 pr-3 text-xs">{a.category || "—"}</td>
                    <td className="py-3 pr-3 text-xs">{a.purchaseDate || "—"}</td>
                    <td className="py-3 pr-3 text-right">{f(p(a.purchaseCost))}</td>
                    <td className="py-3 pr-3 text-right font-semibold">{f(p(a.currentValue))}</td>
                    <td className="py-3 pr-3 text-xs">{a.location || "—"}</td>
                    <td className="py-3 pr-3">{statusBadge(a.status)}</td>
                    <td className="py-3 pr-3 text-right space-x-2">
                      <button onClick={() => openDetail(a)} className="text-sky-400 hover:text-sky-300" title="View"><i className="fas fa-eye"></i></button>
                      <button onClick={() => openEdit(a)} className="text-amber-400 hover:text-amber-300" title="Edit"><i className="fas fa-edit"></i></button>
                      <button onClick={() => handleDelete(a.id)} className="text-red-400 hover:text-red-300" title="Delete"><i className="fas fa-trash"></i></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ── ADD / EDIT MODAL ── */}
      <Modal isOpen={modal} onClose={() => setModal(false)} title={editing ? `Edit Asset — ${editing.assetId}` : "Add New Asset"}>
        <form onSubmit={handleSubmit}>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="text-sm text-slate-300">Asset Name *</label>
              <input className="input mt-2" placeholder="e.g. School Bus, Projector" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
            </div>
            <div>
              <label className="text-sm text-slate-300">Category</label>
              <select className="select mt-2" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                <option value="">Select Category</option>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-sm text-slate-300">Location</label>
              <input className="input mt-2" placeholder="e.g. Building A, Room 12" value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} />
            </div>
            <div>
              <label className="text-sm text-slate-300">Purchase Date</label>
              <input type="date" className="input mt-2" value={form.purchaseDate} onChange={e => setForm({ ...form, purchaseDate: e.target.value })} />
            </div>
            <div>
              <label className="text-sm text-slate-300">Status</label>
              <select className="select mt-2" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                {STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            </div>
            <div>
              <label className="text-sm text-slate-300">Purchase Cost (GHS)</label>
              <input type="number" step="0.01" className="input mt-2" value={form.purchaseCost} onChange={e => updateCost("purchaseCost", e.target.value)} />
            </div>
            <div>
              <label className="text-sm text-slate-300">Depreciation (GHS)</label>
              <input type="number" step="0.01" className="input mt-2" value={form.depreciation} onChange={e => updateCost("depreciation", e.target.value)} />
            </div>
            <div>
              <label className="text-sm text-slate-300">Current Value (GHS)</label>
              <input type="number" step="0.01" className="input mt-2 bg-slate-800/50" value={form.currentValue} readOnly />
            </div>
            <div>
              <label className="text-sm text-slate-300">Asset Photo</label>
              <input type="file" accept="image/*" className="input mt-2" onChange={handlePhotoUpload} />
              {form.photoUrl && <img src={form.photoUrl} alt="" className="w-20 h-20 rounded-lg object-cover mt-2 border border-white/10" />}
            </div>
            <div>
              <label className="text-sm text-slate-300">Last Maintenance</label>
              <input type="date" className="input mt-2" value={form.lastMaintenanceDate} onChange={e => setForm({ ...form, lastMaintenanceDate: e.target.value })} />
            </div>
            <div>
              <label className="text-sm text-slate-300">Next Maintenance</label>
              <input type="date" className="input mt-2" value={form.nextMaintenanceDate} onChange={e => setForm({ ...form, nextMaintenanceDate: e.target.value })} />
            </div>
          </div>

          {/* live value preview */}
          {(form.purchaseCost || form.depreciation) && (
            <div className="mt-4 p-3 rounded-xl bg-slate-900/60 border border-slate-700/40 flex gap-6 text-sm">
              <div><span className="text-slate-400">Cost:</span> <strong>{f(parseFloat(form.purchaseCost || "0"))}</strong></div>
              <div><span className="text-slate-400">Depreciation:</span> <strong className="text-red-400">{f(parseFloat(form.depreciation || "0"))}</strong></div>
              <div><span className="text-slate-400">Current Value:</span> <strong className="text-emerald-400">{f(parseFloat(form.currentValue || "0"))}</strong></div>
            </div>
          )}

          <div className="mt-6 flex gap-4">
            <button type="submit" disabled={busy} className="btn flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold disabled:opacity-50">
              {busy ? "Saving…" : editing ? "Update Asset" : "Add Asset"}
            </button>
            <button type="button" onClick={() => setModal(false)} className="btn px-5 py-3 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button>
          </div>
        </form>
      </Modal>

      {/* ── DETAIL VIEW MODAL ── */}
      {selected && (
        <Modal isOpen={detailModal} onClose={() => setDetailModal(false)} title={`Asset Details — ${selected.assetId}`}>
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row gap-6">
              {selected.photoUrl
                ? <img src={selected.photoUrl} alt="" className="w-40 h-40 rounded-2xl object-cover border border-white/10" />
                : <div className="w-40 h-40 rounded-2xl bg-slate-700/50 flex items-center justify-center"><i className="fas fa-image text-4xl text-slate-500"></i></div>
              }
              <div className="flex-1">
                <p className="text-2xl font-bold">{selected.name}</p>
                <p className="text-sm text-sky-300 font-mono mt-1">{selected.assetId}</p>
                <div className="mt-2">{statusBadge(selected.status)}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><span className="text-xs text-slate-400">Category</span><p>{selected.category || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Location</span><p>{selected.location || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Purchase Date</span><p>{selected.purchaseDate || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Purchase Cost</span><p className="font-semibold">{f(p(selected.purchaseCost))}</p></div>
              <div><span className="text-xs text-slate-400">Depreciation</span><p className="text-red-400">{f(p(selected.depreciation))}</p></div>
              <div><span className="text-xs text-slate-400">Current Value</span><p className="font-bold text-emerald-400">{f(p(selected.currentValue))}</p></div>
              <div><span className="text-xs text-slate-400">Last Maintenance</span><p>{selected.lastMaintenanceDate || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Next Maintenance</span><p>{selected.nextMaintenanceDate || "—"}</p></div>
            </div>
            <button onClick={() => { setDetailModal(false); openEdit(selected); }} className="btn w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-white font-semibold">
              <i className="fas fa-edit mr-2"></i>Edit This Asset
            </button>
          </div>
        </Modal>
      )}
    </>
  );
}
