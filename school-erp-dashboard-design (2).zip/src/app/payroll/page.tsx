import { db } from "@/db";
import { payroll, staff, staffLoans } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import PayrollContent from "./PayrollContent";

export const dynamic = "force-dynamic";

export default async function PayrollPage() {
  const [payrollRecords, staffList, loans] = await Promise.all([
    db.select().from(payroll).orderBy(desc(payroll.createdAt)).limit(100),
    db.select().from(staff).where(eq(staff.status, "active")).orderBy(staff.firstName),
    db.select().from(staffLoans).orderBy(desc(staffLoans.createdAt)),
  ]);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6">
          <PayrollContent
            initialRecords={payrollRecords}
            staffList={staffList}
            initialLoans={loans}
          />
        </main>
      </div>
    </div>
  );
}
