"use client";

import { useState, useRef } from "react";
import Modal from "@/components/Modal";
import StatCard from "@/components/StatCard";
import { useSchool } from "@/components/SchoolProvider";
import { printWithHeader } from "@/lib/printHeader";

interface PayrollRecord {
  id: number; staffId: number; payPeriod: string; basicSalary: string;
  transportAllowance: string | null; healthAllowance: string | null; rentAllowance: string | null;
  responsibilityAllowance: string | null; overtimeAllowance: string | null; feedingAllowance: string | null;
  totalAllowances: string | null; grossPay: string | null;
  ssnitDeduction: string | null; payeDeduction: string | null; loanDeduction: string | null;
  otherDeductions: string | null; totalDeductions: string | null;
  netPay: string; paymentDate: string | null; status: string | null;
}
interface Staff {
  id: number; staffId: string; firstName: string; lastName: string; position: string;
  department: string | null; taxId: string | null; ssnitNumber: string | null;
  basicSalary: string | null; phone: string | null;
}
interface Loan {
  id: number; staffId: number; type: string; amount: string; monthlyDeduction: string;
  totalRepaid: string | null; balance: string; startDate: string | null;
  description: string | null; isActive: boolean | null;
}

interface PayrollContentProps {
  initialRecords: PayrollRecord[];
  staffList: Staff[];
  initialLoans: Loan[];
}

const p = (v: string | null) => parseFloat(v || "0");
const f = (n: number) => `GHS ${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export default function PayrollContent({ initialRecords, staffList, initialLoans }: PayrollContentProps) {
  const school = useSchool();
  const [records, setRecords] = useState<PayrollRecord[]>(initialRecords);
  const [loans, setLoans] = useState<Loan[]>(initialLoans);
  const [tab, setTab] = useState<"payroll" | "loans">("payroll");
  const [payPeriod, setPayPeriod] = useState("February 2025");
  const [processing, setProcessing] = useState(false);
  const [distributing, setDistributing] = useState(false);

  // Edit modal
  const [editModal, setEditModal] = useState(false);
  const [editRecord, setEditRecord] = useState<PayrollRecord | null>(null);
  const [editForm, setEditForm] = useState<Record<string, string>>({});
  const [editBusy, setEditBusy] = useState(false);

  // Payslip modal
  const [payslipModal, setPayslipModal] = useState(false);
  const [payslipRecord, setPayslipRecord] = useState<PayrollRecord | null>(null);
  const payslipRef = useRef<HTMLDivElement>(null);

  // Loan modal
  const [loanModal, setLoanModal] = useState(false);
  const [loanForm, setLoanForm] = useState({ staffId: "", type: "loan", amount: "", monthlyDeduction: "", startDate: "", description: "" });
  const [loanBusy, setLoanBusy] = useState(false);

  const sName = (id: number) => { const s = staffList.find(s => s.id === id); return s ? `${s.firstName} ${s.lastName}` : "—"; };
  const sDetail = (id: number) => staffList.find(s => s.id === id);
  const filteredRecords = records.filter(r => r.payPeriod === payPeriod);

  // Stats
  const totalGross = filteredRecords.reduce((s, r) => s + p(r.grossPay), 0);
  const totalDed = filteredRecords.reduce((s, r) => s + p(r.totalDeductions), 0);
  const totalNet = filteredRecords.reduce((s, r) => s + p(r.netPay), 0);

  // Process payroll
  const handleProcess = async () => {
    if (!confirm(`Generate payroll for ${payPeriod}? This will create records for all active staff.`)) return;
    setProcessing(true);
    try {
      const res = await fetch("/api/payroll/process", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ payPeriod }) });
      if (res.ok) { alert("Payroll processed!"); window.location.reload(); }
      else { const d = await res.json(); alert(d.error || "Failed"); }
    } catch { alert("Error"); } finally { setProcessing(false); }
  };

  // Distribute
  const handleDistribute = async () => {
    if (!confirm(`Mark all pending ${payPeriod} payments as PAID and update loan balances?`)) return;
    setDistributing(true);
    try {
      const res = await fetch("/api/payroll/distribute", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ payPeriod }) });
      const d = await res.json();
      if (res.ok) { alert(d.message); window.location.reload(); }
      else alert(d.error || "Failed");
    } catch { alert("Error"); } finally { setDistributing(false); }
  };

  // Edit
  const openEdit = (r: PayrollRecord) => {
    setEditRecord(r);
    setEditForm({
      basicSalary: r.basicSalary,
      transportAllowance: r.transportAllowance || "0",
      healthAllowance: r.healthAllowance || "0",
      rentAllowance: r.rentAllowance || "0",
      responsibilityAllowance: r.responsibilityAllowance || "0",
      overtimeAllowance: r.overtimeAllowance || "0",
      feedingAllowance: r.feedingAllowance || "0",
      ssnitDeduction: r.ssnitDeduction || "0",
      payeDeduction: r.payeDeduction || "0",
      loanDeduction: r.loanDeduction || "0",
      otherDeductions: r.otherDeductions || "0",
    });
    setEditModal(true);
  };
  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setEditBusy(true);
    try {
      const res = await fetch(`/api/payroll/${editRecord!.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(editForm) });
      if (res.ok) { const updated = await res.json(); setRecords(records.map(r => r.id === updated.id ? updated : r)); setEditModal(false); }
    } catch { alert("Error"); } finally { setEditBusy(false); }
  };
  // live preview
  const editGross = (parseFloat(editForm.basicSalary || "0") + parseFloat(editForm.transportAllowance || "0") + parseFloat(editForm.healthAllowance || "0") + parseFloat(editForm.rentAllowance || "0") + parseFloat(editForm.responsibilityAllowance || "0") + parseFloat(editForm.overtimeAllowance || "0") + parseFloat(editForm.feedingAllowance || "0"));
  const editTotalDed = (parseFloat(editForm.ssnitDeduction || "0") + parseFloat(editForm.payeDeduction || "0") + parseFloat(editForm.loanDeduction || "0") + parseFloat(editForm.otherDeductions || "0"));
  const editNet = editGross - editTotalDed;

  // Payslip
  const openPayslip = (r: PayrollRecord) => { setPayslipRecord(r); setPayslipModal(true); };
  const printPayslip = () => {
    if (!payslipRef.current) return;
    printWithHeader(school, payslipRef.current.innerHTML, "Payslip");
  };

  // Add loan
  const handleAddLoan = async (e: React.FormEvent) => {
    e.preventDefault(); setLoanBusy(true);
    try {
      const res = await fetch("/api/loans", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(loanForm) });
      if (res.ok) { const l = await res.json(); setLoans([l, ...loans]); setLoanModal(false); setLoanForm({ staffId: "", type: "loan", amount: "", monthlyDeduction: "", startDate: "", description: "" }); }
    } catch { alert("Error"); } finally { setLoanBusy(false); }
  };

  const EF = ({ label, field }: { label: string; field: string }) => (
    <div>
      <label className="text-xs text-slate-400">{label}</label>
      <input type="number" step="0.01" className="input mt-1" value={editForm[field] || "0"} onChange={e => setEditForm({ ...editForm, [field]: e.target.value })} />
    </div>
  );

  return (
    <section className="fade-up space-y-6">
      <div className="mb-6">
        <h2 className="text-3xl font-bold">Payroll Management</h2>
        <p className="text-slate-400">Process salaries, manage allowances, deductions, loans &amp; payslips</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard icon="fa-users" iconBg="bg-blue-500/20" iconColor="text-blue-400" label="Staff Count" value={staffList.length} />
        <StatCard icon="fa-money-bill-wave" iconBg="bg-green-500/20" iconColor="text-green-400" label="Gross Pay" value={f(totalGross)} />
        <StatCard icon="fa-minus-circle" iconBg="bg-red-500/20" iconColor="text-red-400" label="Total Deductions" value={f(totalDed)} />
        <StatCard icon="fa-wallet" iconBg="bg-emerald-500/20" iconColor="text-emerald-400" label="Net Pay" value={f(totalNet)} />
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        <button onClick={() => setTab("payroll")} className={`btn px-5 py-3 rounded-xl font-semibold transition ${tab === "payroll" ? "bg-sky-500 text-white" : "bg-white/5 border border-white/10 hover:bg-white/10"}`}><i className="fas fa-file-invoice-dollar mr-2"></i>Payroll</button>
        <button onClick={() => setTab("loans")} className={`btn px-5 py-3 rounded-xl font-semibold transition ${tab === "loans" ? "bg-sky-500 text-white" : "bg-white/5 border border-white/10 hover:bg-white/10"}`}><i className="fas fa-hand-holding-usd mr-2"></i>Loans &amp; Advances ({loans.filter(l => l.isActive).length})</button>
      </div>

      {/* ─── PAYROLL TAB ─── */}
      {tab === "payroll" && (
        <>
          {/* Controls */}
          <div className="card rounded-3xl p-6">
            <div className="grid md:grid-cols-4 gap-4 items-end">
              <div><label className="text-sm text-slate-300">Pay Period</label>
                <select className="select mt-2" value={payPeriod} onChange={e => setPayPeriod(e.target.value)}>
                  {["January","February","March","April","May","June","July","August","September","October","November","December"].map(m => <option key={m} value={`${m} 2025`}>{m} 2025</option>)}
                </select>
              </div>
              <button onClick={handleProcess} disabled={processing} className="btn py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold disabled:opacity-50"><i className="fas fa-calculator mr-2"></i>{processing ? "Processing…" : "Generate Payroll"}</button>
              <button onClick={handleDistribute} disabled={distributing} className="btn py-3 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-semibold disabled:opacity-50"><i className="fas fa-paper-plane mr-2"></i>{distributing ? "Distributing…" : "Distribute Payments"}</button>
              <div className="text-sm text-slate-400 text-right">{filteredRecords.length} records for {payPeriod}</div>
            </div>
          </div>

          {/* Payroll table */}
          <div className="card rounded-3xl p-6">
            {filteredRecords.length === 0 ? (
              <div className="text-center py-16"><i className="fas fa-file-invoice text-4xl text-slate-600 mb-4"></i><p className="text-slate-400">No payroll records for {payPeriod}. Click &quot;Generate Payroll&quot; to create them.</p></div>
            ) : (
              <div className="table-wrap overflow-auto">
                <table className="min-w-full text-left text-sm">
                  <thead className="text-slate-300"><tr className="border-b border-slate-700">
                    <th className="py-3 pr-3">Staff</th><th className="py-3 pr-3">Position</th>
                    <th className="py-3 pr-3 text-right">Basic</th><th className="py-3 pr-3 text-right">Allowances</th>
                    <th className="py-3 pr-3 text-right">Gross</th><th className="py-3 pr-3 text-right">Deductions</th>
                    <th className="py-3 pr-3 text-right">Net Pay</th><th className="py-3 pr-3">Status</th>
                    <th className="py-3 pr-3 text-right">Actions</th>
                  </tr></thead>
                  <tbody>
                    {filteredRecords.map(r => {
                      const s = sDetail(r.staffId);
                      return (
                        <tr key={r.id} className="border-b border-slate-800/70">
                          <td className="py-3 pr-3 font-semibold">{sName(r.staffId)}<br/><span className="text-xs text-slate-500">{s?.staffId}</span></td>
                          <td className="py-3 pr-3 text-xs">{s?.position || "—"}</td>
                          <td className="py-3 pr-3 text-right">{f(p(r.basicSalary))}</td>
                          <td className="py-3 pr-3 text-right">{f(p(r.totalAllowances))}</td>
                          <td className="py-3 pr-3 text-right font-semibold">{f(p(r.grossPay))}</td>
                          <td className="py-3 pr-3 text-right text-red-400">{f(p(r.totalDeductions))}</td>
                          <td className="py-3 pr-3 text-right font-bold text-emerald-400">{f(p(r.netPay))}</td>
                          <td className="py-3 pr-3"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${r.status === "paid" ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-500/20 text-amber-400"}`}>{r.status === "paid" ? "Paid" : "Pending"}</span></td>
                          <td className="py-3 pr-3 text-right space-x-2">
                            <button onClick={() => openEdit(r)} className="text-sky-400 hover:text-sky-300" title="Edit"><i className="fas fa-edit"></i></button>
                            <button onClick={() => openPayslip(r)} className="text-purple-400 hover:text-purple-300" title="Payslip"><i className="fas fa-file-alt"></i></button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}

      {/* ─── LOANS TAB ─── */}
      {tab === "loans" && (
        <>
          <div className="flex justify-between mb-4">
            <h3 className="text-xl font-bold">Loans &amp; Salary Advances</h3>
            <button onClick={() => setLoanModal(true)} className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"><i className="fas fa-plus mr-2"></i>Add Loan / Advance</button>
          </div>
          <div className="card rounded-3xl p-6">
            {loans.length === 0 ? (
              <p className="text-slate-400 text-center py-10">No loans or advances recorded.</p>
            ) : (
              <div className="table-wrap overflow-auto">
                <table className="min-w-full text-left text-sm">
                  <thead className="text-slate-300"><tr className="border-b border-slate-700">
                    <th className="py-3 pr-3">Staff</th><th className="py-3 pr-3">Type</th>
                    <th className="py-3 pr-3 text-right">Amount</th><th className="py-3 pr-3 text-right">Monthly Ded.</th>
                    <th className="py-3 pr-3 text-right">Repaid</th><th className="py-3 pr-3 text-right">Balance</th>
                    <th className="py-3 pr-3">Status</th><th className="py-3 pr-3">Description</th>
                  </tr></thead>
                  <tbody>
                    {loans.map(l => (
                      <tr key={l.id} className="border-b border-slate-800/70">
                        <td className="py-3 pr-3 font-semibold">{sName(l.staffId)}</td>
                        <td className="py-3 pr-3"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${l.type === "loan" ? "bg-blue-500/20 text-blue-400" : "bg-amber-500/20 text-amber-400"}`}>{l.type === "loan" ? "Loan" : "Salary Advance"}</span></td>
                        <td className="py-3 pr-3 text-right">{f(p(l.amount))}</td>
                        <td className="py-3 pr-3 text-right">{f(p(l.monthlyDeduction))}</td>
                        <td className="py-3 pr-3 text-right text-emerald-400">{f(p(l.totalRepaid))}</td>
                        <td className="py-3 pr-3 text-right font-bold">{f(p(l.balance))}</td>
                        <td className="py-3 pr-3"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${l.isActive ? "bg-amber-500/20 text-amber-400" : "bg-emerald-500/20 text-emerald-400"}`}>{l.isActive ? "Active" : "Cleared"}</span></td>
                        <td className="py-3 pr-3 text-xs text-slate-400 max-w-[150px] truncate">{l.description || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}

      {/* ─── EDIT PAYROLL MODAL ─── */}
      <Modal isOpen={editModal} onClose={() => setEditModal(false)} title={`Edit Payroll — ${editRecord ? sName(editRecord.staffId) : ""}`}>
        {editRecord && (
          <form onSubmit={handleEditSubmit}>
            <h4 className="font-bold text-sky-300 mb-2">Earnings</h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <EF label="Basic Salary" field="basicSalary" />
              <EF label="Transport Allow." field="transportAllowance" />
              <EF label="Health Insurance" field="healthAllowance" />
              <EF label="Rent Allowance" field="rentAllowance" />
              <EF label="Responsibility" field="responsibilityAllowance" />
              <EF label="Overtime" field="overtimeAllowance" />
              <EF label="Feeding Allow." field="feedingAllowance" />
            </div>
            <h4 className="font-bold text-red-400 mt-5 mb-2">Deductions</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <EF label="SSNIT (5.5%)" field="ssnitDeduction" />
              <EF label="PAYE Tax" field="payeDeduction" />
              <EF label="Loan Repayment" field="loanDeduction" />
              <EF label="Other Deductions" field="otherDeductions" />
            </div>
            {/* Live preview */}
            <div className="mt-5 p-4 rounded-xl bg-slate-900/60 border border-slate-700/40 grid grid-cols-3 gap-4 text-center">
              <div><span className="text-xs text-slate-400">Gross</span><p className="font-bold text-lg">{f(editGross)}</p></div>
              <div><span className="text-xs text-slate-400">Deductions</span><p className="font-bold text-lg text-red-400">{f(editTotalDed)}</p></div>
              <div><span className="text-xs text-slate-400">Net Pay</span><p className="font-bold text-lg text-emerald-400">{f(editNet)}</p></div>
            </div>
            <div className="mt-5 flex gap-4">
              <button type="submit" disabled={editBusy} className="btn flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold disabled:opacity-50">{editBusy ? "Saving…" : "Save Changes"}</button>
              <button type="button" onClick={() => setEditModal(false)} className="btn px-5 py-3 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button>
            </div>
          </form>
        )}
      </Modal>

      {/* ─── PAYSLIP MODAL ─── */}
      <Modal isOpen={payslipModal} onClose={() => setPayslipModal(false)} title="Payslip">
        {payslipRecord && (() => {
          const s = sDetail(payslipRecord.staffId);
          return (
            <div>
              <div ref={payslipRef}>
                <p style={{ textAlign: "center", margin: "0 0 12px", fontWeight: "bold" }}>Payslip — {payslipRecord.payPeriod}</p>
                <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: 12 }}>
                  <tbody>
                    <tr><td style={{ padding: "4px 8px", color: "#666" }}>Name</td><td style={{ padding: "4px 8px", fontWeight: "bold" }}>{sName(payslipRecord.staffId)}</td><td style={{ padding: "4px 8px", color: "#666" }}>Staff ID</td><td style={{ padding: "4px 8px" }}>{s?.staffId}</td></tr>
                    <tr><td style={{ padding: "4px 8px", color: "#666" }}>Position</td><td style={{ padding: "4px 8px" }}>{s?.position}</td><td style={{ padding: "4px 8px", color: "#666" }}>Department</td><td style={{ padding: "4px 8px" }}>{s?.department || "—"}</td></tr>
                    <tr><td style={{ padding: "4px 8px", color: "#666" }}>Tax ID</td><td style={{ padding: "4px 8px" }}>{s?.taxId || "—"}</td><td style={{ padding: "4px 8px", color: "#666" }}>SSNIT No.</td><td style={{ padding: "4px 8px" }}>{s?.ssnitNumber || "—"}</td></tr>
                  </tbody>
                </table>
                <h4 style={{ margin: "16px 0 4px", color: "#059669" }}>Earnings</h4>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead><tr style={{ background: "#f5f5f5" }}><th style={{ padding: "6px 10px", textAlign: "left", borderBottom: "1px solid #ddd" }}>Item</th><th style={{ padding: "6px 10px", textAlign: "right", borderBottom: "1px solid #ddd" }}>Amount (GHS)</th></tr></thead>
                  <tbody>
                    {[["Basic Salary", payslipRecord.basicSalary],["Transport Allowance", payslipRecord.transportAllowance],["Health Insurance", payslipRecord.healthAllowance],["Rent Allowance", payslipRecord.rentAllowance],["Responsibility Allowance", payslipRecord.responsibilityAllowance],["Overtime", payslipRecord.overtimeAllowance],["Feeding Allowance", payslipRecord.feedingAllowance]].map(([label, val]) => p(val as string) > 0 ? <tr key={label as string}><td style={{ padding: "6px 10px", borderBottom: "1px solid #eee" }}>{label}</td><td style={{ padding: "6px 10px", textAlign: "right", borderBottom: "1px solid #eee" }}>{p(val as string).toFixed(2)}</td></tr> : null)}
                    <tr style={{ fontWeight: "bold", borderTop: "2px solid #333" }}><td style={{ padding: "6px 10px" }}>Gross Pay</td><td style={{ padding: "6px 10px", textAlign: "right" }}>{p(payslipRecord.grossPay).toFixed(2)}</td></tr>
                  </tbody>
                </table>
                <h4 style={{ margin: "16px 0 4px", color: "#dc2626" }}>Deductions</h4>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead><tr style={{ background: "#f5f5f5" }}><th style={{ padding: "6px 10px", textAlign: "left", borderBottom: "1px solid #ddd" }}>Item</th><th style={{ padding: "6px 10px", textAlign: "right", borderBottom: "1px solid #ddd" }}>Amount (GHS)</th></tr></thead>
                  <tbody>
                    {[["SSNIT (5.5%)", payslipRecord.ssnitDeduction],["PAYE Tax", payslipRecord.payeDeduction],["Loan Repayment", payslipRecord.loanDeduction],["Other Deductions", payslipRecord.otherDeductions]].map(([label, val]) => p(val as string) > 0 ? <tr key={label as string}><td style={{ padding: "6px 10px", borderBottom: "1px solid #eee" }}>{label}</td><td style={{ padding: "6px 10px", textAlign: "right", borderBottom: "1px solid #eee" }}>{p(val as string).toFixed(2)}</td></tr> : null)}
                    <tr style={{ fontWeight: "bold", borderTop: "2px solid #333" }}><td style={{ padding: "6px 10px" }}>Total Deductions</td><td style={{ padding: "6px 10px", textAlign: "right" }}>{p(payslipRecord.totalDeductions).toFixed(2)}</td></tr>
                  </tbody>
                </table>
                <div style={{ fontSize: 20, padding: 16, background: "#f0fdf4", borderRadius: 8, textAlign: "center", marginTop: 16, fontWeight: "bold" }}>Net Pay: GHS {p(payslipRecord.netPay).toFixed(2)}</div>
              </div>
              <div className="mt-5 flex gap-4">
                <button onClick={printPayslip} className="btn flex-1 py-3 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-semibold"><i className="fas fa-print mr-2"></i>Print Payslip</button>
                <button onClick={() => setPayslipModal(false)} className="btn px-5 py-3 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Close</button>
              </div>
            </div>
          );
        })()}
      </Modal>

      {/* ─── LOAN MODAL ─── */}
      <Modal isOpen={loanModal} onClose={() => setLoanModal(false)} title="Add Loan / Salary Advance">
        <form onSubmit={handleAddLoan}>
          <div className="grid md:grid-cols-2 gap-4">
            <div><label className="text-sm text-slate-300">Staff *</label>
              <select className="select mt-2" value={loanForm.staffId} onChange={e => setLoanForm({ ...loanForm, staffId: e.target.value })} required>
                <option value="">Select Staff</option>{staffList.map(s => <option key={s.id} value={s.id}>{s.firstName} {s.lastName} ({s.staffId})</option>)}
              </select>
            </div>
            <div><label className="text-sm text-slate-300">Type *</label>
              <select className="select mt-2" value={loanForm.type} onChange={e => setLoanForm({ ...loanForm, type: e.target.value })}>
                <option value="loan">Loan</option><option value="salary_advance">Salary Advance</option>
              </select>
            </div>
            <div><label className="text-sm text-slate-300">Amount (GHS) *</label><input type="number" step="0.01" className="input mt-2" value={loanForm.amount} onChange={e => setLoanForm({ ...loanForm, amount: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Monthly Deduction (GHS) *</label><input type="number" step="0.01" className="input mt-2" value={loanForm.monthlyDeduction} onChange={e => setLoanForm({ ...loanForm, monthlyDeduction: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Start Date</label><input type="date" className="input mt-2" value={loanForm.startDate} onChange={e => setLoanForm({ ...loanForm, startDate: e.target.value })} /></div>
            <div className="md:col-span-2"><label className="text-sm text-slate-300">Description</label><textarea className="textarea mt-2" value={loanForm.description} onChange={e => setLoanForm({ ...loanForm, description: e.target.value })} /></div>
          </div>
          {loanForm.amount && loanForm.monthlyDeduction && parseFloat(loanForm.monthlyDeduction) > 0 && (
            <div className="mt-4 p-3 rounded-xl bg-slate-900/60 border border-slate-700/40 text-sm text-slate-300">
              Repayment: <strong>{Math.ceil(parseFloat(loanForm.amount) / parseFloat(loanForm.monthlyDeduction))}</strong> months at <strong>{f(parseFloat(loanForm.monthlyDeduction))}</strong>/month
            </div>
          )}
          <div className="mt-5 flex gap-4">
            <button type="submit" disabled={loanBusy} className="btn flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold disabled:opacity-50">{loanBusy ? "Saving…" : "Add Loan"}</button>
            <button type="button" onClick={() => setLoanModal(false)} className="btn px-5 py-3 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button>
          </div>
        </form>
      </Modal>
    </section>
  );
}
