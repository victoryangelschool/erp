"use client";

import { useState, useEffect } from "react";
import { getUserFromCookie } from "@/lib/auth";
import { useSchool } from "@/components/SchoolProvider";

export default function LoginPage() {
  const school = useSchool();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [checking, setChecking] = useState(true);

  // If already logged in, redirect to home
  useEffect(() => {
    const u = getUserFromCookie();
    if (u) {
      window.location.href = "/";
    } else {
      setChecking(false);
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (res.ok) {
        // Set cookie on client side directly, then navigate
        document.cookie = `erp_user=${encodeURIComponent(JSON.stringify(data))}; path=/; max-age=86400`;
        // Full page load to ensure cookie is picked up everywhere
        window.location.href = "/";
      } else {
        setError(data.error || "Login failed");
        setBusy(false);
      }
    } catch {
      setError("Network error. Please try again.");
      setBusy(false);
    }
  };

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <i className="fas fa-spinner fa-spin text-2xl text-sky-400"></i>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          {school.logoUrl ? (
            <img src={school.logoUrl} alt="" className="w-20 h-20 rounded-3xl object-cover mx-auto mb-4 border border-sky-500/30" />
          ) : (
            <div className="w-20 h-20 rounded-3xl bg-sky-500/20 flex items-center justify-center mx-auto mb-4 border border-sky-500/30">
              <span className="text-4xl font-black text-sky-300">{school.name.charAt(0)}</span>
            </div>
          )}
          <h1 className="text-3xl font-bold">{school.name}</h1>
          <p className="text-slate-400 mt-1">School ERP System</p>
        </div>

        <div className="card rounded-3xl p-8">
          <h2 className="text-2xl font-bold mb-2">Sign In</h2>
          <p className="text-slate-400 text-sm mb-6">Enter your credentials to access the system</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm text-slate-300">Username</label>
              <div className="relative mt-2">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500"><i className="fas fa-user"></i></span>
                <input className="input pl-11" placeholder="Enter your username" value={username} onChange={(e) => setUsername(e.target.value)} autoFocus required />
              </div>
            </div>

            <div>
              <label className="text-sm text-slate-300">Password</label>
              <div className="relative mt-2">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500"><i className="fas fa-lock"></i></span>
                <input type="password" className="input pl-11" placeholder="Enter your password" value={password} onChange={(e) => setPassword(e.target.value)} required />
              </div>
            </div>

            {error && (
              <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm text-center">
                <i className="fas fa-exclamation-circle mr-2"></i>{error}
              </div>
            )}

            <button type="submit" disabled={busy} className="btn w-full py-4 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-bold text-lg disabled:opacity-50">
              {busy ? <><i className="fas fa-spinner fa-spin mr-2"></i>Signing in…</> : <><i className="fas fa-sign-in-alt mr-2"></i>Sign In</>}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-slate-700/40">
            <p className="text-xs text-slate-500 text-center mb-3">Access is role-based. Contact your administrator for credentials.</p>
            <div className="flex flex-wrap gap-1 justify-center">
              {["Admin", "Headmaster", "Finance", "Registrar", "Teacher"].map(r => (
                <span key={r} className="px-2 py-1 rounded-full bg-white/5 text-slate-400 text-xs">{r}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
