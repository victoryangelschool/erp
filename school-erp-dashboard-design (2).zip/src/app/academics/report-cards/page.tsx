import { db } from "@/db";
import { students, classes, grades, subjects } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import ReportCardsContent from "./ReportCardsContent";

export const dynamic = "force-dynamic";

export default async function ReportCardsPage() {
  const [studentsList, classesList, gradesList, subjectsList] = await Promise.all([
    db.select({ id: students.id, studentId: students.studentId, firstName: students.firstName, lastName: students.lastName, classId: students.classId, photoUrl: students.photoUrl }).from(students).where(eq(students.status, "active")).orderBy(asc(students.firstName)),
    db.select().from(classes).orderBy(asc(classes.name)),
    db.select().from(grades),
    db.select().from(subjects).orderBy(asc(subjects.name)),
  ]);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6">
          <ReportCardsContent students={studentsList} classes={classesList} grades={gradesList} subjects={subjectsList} />
        </main>
      </div>
    </div>
  );
}
