"use client";

import { useState, useRef } from "react";
import Link from "next/link";
import { useSchool } from "@/components/SchoolProvider";
import { printWithHeader } from "@/lib/printHeader";

interface Student {
  id: number;
  studentId: string;
  firstName: string;
  lastName: string;
  classId: number | null;
  photoUrl: string | null;
}
interface Class { id: number; name: string; }
interface Grade {
  id: number;
  studentId: number;
  subjectId: number;
  classScore: string | null;
  examScore: string | null;
  totalScore: string | null;
  grade: string | null;
  remarks: string | null;
  term: string | null;
  academicYear: string | null;
  scoreWeight: string | null;
}
interface Subject { id: number; name: string; }

function parseWeight(w: string | null): [number, number] {
  if (!w) return [30, 70];
  const parts = w.split(":").map(Number);
  if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) return [parts[0], parts[1]];
  return [30, 70];
}

export default function ReportCardsContent({
  students,
  classes: cls,
  grades,
  subjects,
}: {
  students: Student[];
  classes: Class[];
  grades: Grade[];
  subjects: Subject[];
}) {
  const school = useSchool();
  const [selectedStudent, setSelectedStudent] = useState("");
  const [filterTerm, setFilterTerm] = useState("First Term");
  const [filterYear, setFilterYear] = useState("2025/2026");
  const printRef = useRef<HTMLDivElement>(null);

  const className = (id: number | null) =>
    cls.find((c) => c.id === id)?.name || "—";
  const subjectName = (id: number) =>
    subjects.find((s) => s.id === id)?.name || "—";

  const student = students.find((s) => String(s.id) === selectedStudent);
  const studentGrades = student
    ? grades.filter(
        (g) =>
          g.studentId === student.id &&
          g.term === filterTerm &&
          g.academicYear === filterYear
      )
    : [];

  const totalScore = studentGrades.reduce(
    (s, g) => s + parseFloat(g.totalScore || "0"),
    0
  );
  const avgScore =
    studentGrades.length > 0
      ? (totalScore / studentGrades.length).toFixed(1)
      : "0";

  const handlePrint = () => {
    if (!printRef.current) return;
    printWithHeader(school, printRef.current.innerHTML, "Student Report Card");
  };

  return (
    <section className="fade-up space-y-6">
      <div>
        <Link
          href="/academics"
          className="text-sky-400 hover:text-sky-300 text-sm mb-2 inline-block"
        >
          <i className="fas fa-arrow-left mr-1"></i> Back to Academics
        </Link>
        <h2 className="text-3xl font-bold">Report Cards</h2>
        <p className="text-slate-400">
          Generate and view student term report cards
        </p>
      </div>

      {/* controls */}
      <div className="card rounded-3xl p-6">
        <h3 className="text-xl font-bold mb-4">Select Student &amp; Term</h3>
        <div className="grid md:grid-cols-4 gap-4">
          <div>
            <label className="text-sm text-slate-300">Student</label>
            <select
              className="select mt-2"
              value={selectedStudent}
              onChange={(e) => setSelectedStudent(e.target.value)}
            >
              <option value="">Select Student</option>
              {students.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.firstName} {s.lastName} ({s.studentId})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-sm text-slate-300">Term</label>
            <select
              className="select mt-2"
              value={filterTerm}
              onChange={(e) => setFilterTerm(e.target.value)}
            >
              <option>First Term</option>
              <option>Second Term</option>
              <option>Third Term</option>
            </select>
          </div>
          <div>
            <label className="text-sm text-slate-300">Academic Year</label>
            <select
              className="select mt-2"
              value={filterYear}
              onChange={(e) => setFilterYear(e.target.value)}
            >
              <option>2025/2026</option>
              <option>2024/2025</option>
            </select>
          </div>
          <div className="flex items-end">
            {student && studentGrades.length > 0 && (
              <button
                onClick={handlePrint}
                className="btn w-full py-3 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-semibold"
              >
                <i className="fas fa-print mr-2"></i>Print
              </button>
            )}
          </div>
        </div>
      </div>

      {/* report card */}
      {!student ? (
        <div className="card rounded-3xl p-6 text-center py-16">
          <i className="fas fa-file-alt text-4xl text-slate-600 mb-4"></i>
          <p className="text-slate-400">
            Select a student above to view their report card.
          </p>
        </div>
      ) : studentGrades.length === 0 ? (
        <div className="card rounded-3xl p-6 text-center py-16">
          <i className="fas fa-inbox text-4xl text-slate-600 mb-4"></i>
          <p className="text-slate-400">
            No grades recorded for {student.firstName} {student.lastName} in{" "}
            {filterTerm} {filterYear}.
          </p>
          <p className="text-slate-500 text-sm mt-2">
            Go to{" "}
            <Link
              href="/academics/grading"
              className="text-sky-400 underline"
            >
              Grading
            </Link>{" "}
            to enter scores first.
          </p>
        </div>
      ) : (
        <div className="card rounded-3xl p-6">
          {/* On-screen school header */}
          <div className="text-center border-b border-slate-700 pb-4 mb-6">
            {school.logoUrl && <img src={school.logoUrl} alt="" className="w-12 h-12 rounded-lg object-cover mx-auto mb-2" />}
            <h2 className="text-2xl font-bold">{school.name}</h2>
            <p className="text-slate-400 text-sm">{school.motto}</p>
            <p className="text-slate-300 mt-2 font-semibold">Student Terminal Report Card — {filterTerm} {filterYear}</p>
          </div>

          {/* Student info with photo for authentication (also used in print) */}
          <div ref={printRef}>
            <div style={{ display: "flex", gap: 20, alignItems: "center", marginBottom: 20, padding: 12, background: "#f8fafc", borderRadius: 8, color: "#111" }}>
              {student.photoUrl ? (
                <img src={student.photoUrl} alt="Student" style={{ width: 80, height: 100, borderRadius: 8, objectFit: "cover", border: "2px solid #cbd5e1" }} />
              ) : (
                <div style={{ width: 80, height: 100, borderRadius: 8, background: "#e2e8f0", display: "flex", alignItems: "center", justifyContent: "center", border: "2px solid #cbd5e1", color: "#94a3b8" }}>No Photo</div>
              )}
              <div style={{ flex: 1 }}>
                <div style={{ marginBottom: 4 }}><span style={{ color: "#64748b", fontSize: 13 }}>Name:</span> <strong style={{ fontSize: 16 }}>{student.firstName} {student.lastName}</strong></div>
                <div style={{ marginBottom: 4 }}><span style={{ color: "#64748b", fontSize: 13 }}>Student ID:</span> <strong>{student.studentId}</strong></div>
                <div><span style={{ color: "#64748b", fontSize: 13 }}>Class:</span> <strong>{className(student.classId)}</strong></div>
              </div>
            </div>

            <div className="table-wrap overflow-auto">
              <table className="min-w-full text-left text-sm">
                <thead className="text-slate-300">
                  <tr className="border-b border-slate-700">
                    <th className="py-3 pr-4">Subject</th>
                    <th className="py-3 pr-4 text-center">Weight</th>
                    <th className="py-3 pr-4 text-right">Class Score</th>
                    <th className="py-3 pr-4 text-right">Exam Score</th>
                    <th className="py-3 pr-4 text-right">Total (100)</th>
                    <th className="py-3 pr-4">Grade</th>
                    <th className="py-3 pr-4">Remarks</th>
                  </tr>
                </thead>
                <tbody>
                  {studentGrades.map((g) => {
                    const [cw, ew] = parseWeight(g.scoreWeight);
                    return (
                      <tr key={g.id} className="border-b border-slate-800/70" style={{ color: "#111" }}>
                        <td className="py-3 pr-4 font-semibold" style={{ color: "#111" }}>{subjectName(g.subjectId)}</td>
                        <td className="py-3 pr-4 text-center" style={{ color: "#64748b" }}>{cw}:{ew}</td>
                        <td className="py-3 pr-4 text-right" style={{ color: "#111" }}>{g.classScore}<span style={{ color: "#94a3b8", fontSize: 11 }}>/{cw}</span></td>
                        <td className="py-3 pr-4 text-right" style={{ color: "#111" }}>{g.examScore}<span style={{ color: "#94a3b8", fontSize: 11 }}>/{ew}</span></td>
                        <td className="py-3 pr-4 text-right font-bold" style={{ color: "#111" }}>{g.totalScore}</td>
                        <td className="py-3 pr-4"><span className="px-2 py-1 rounded-full bg-sky-100 text-sky-700 text-xs font-semibold">{g.grade}</span></td>
                        <td className="py-3 pr-4" style={{ color: "#334155" }}>{g.remarks}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div style={{ marginTop: 24, padding: 16, background: "#f0f9ff", borderRadius: 8, color: "#111", display: "flex", gap: 40 }}>
              <div>
                <span style={{ color: "#64748b", fontSize: 13 }}>Subjects Taken</span>
                <p style={{ fontWeight: "bold", fontSize: 20, margin: 0 }}>{studentGrades.length}</p>
              </div>
              <div>
                <span style={{ color: "#64748b", fontSize: 13 }}>Total Score</span>
                <p style={{ fontWeight: "bold", fontSize: 20, margin: 0 }}>{totalScore}</p>
              </div>
              <div>
                <span style={{ color: "#64748b", fontSize: 13 }}>Average</span>
                <p style={{ fontWeight: "bold", fontSize: 20, margin: 0 }}>{avgScore}%</p>
              </div>
            </div>
          </div>

          {/* Print button */}
          <div className="mt-5 flex gap-3">
            <button onClick={handlePrint} className="btn flex-1 py-3 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-semibold">
              <i className="fas fa-print mr-2"></i>Print Report Card
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
