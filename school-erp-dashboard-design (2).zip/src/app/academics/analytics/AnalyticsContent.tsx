"use client";

import Link from "next/link";
import StatCard from "@/components/StatCard";

interface SubjectPerf { subjectId: number; avg: string; count: number; maxScore: string; minScore: string; }
interface GradeDist { grade: string | null; count: number; }
interface Subject { id: number; name: string; }
interface Class { id: number; name: string; }

interface AnalyticsData {
  bySubject: SubjectPerf[];
  byGrade: GradeDist[];
  subjectsList: Subject[];
  classesList: Class[];
  totalGrades: number;
  overallAvg: number;
}

export default function AnalyticsContent({ data }: { data: AnalyticsData }) {
  const subjectName = (id: number) => data.subjectsList.find(s => s.id === id)?.name || "Unknown";

  const gradeBadgeColor = (g: string | null) => {
    if (!g) return "bg-slate-500/20 text-slate-400";
    if (g.startsWith("A")) return "bg-emerald-500/20 text-emerald-400";
    if (g.startsWith("B")) return "bg-blue-500/20 text-blue-400";
    if (g.startsWith("C")) return "bg-amber-500/20 text-amber-400";
    if (g.startsWith("D") || g.startsWith("E")) return "bg-orange-500/20 text-orange-400";
    return "bg-red-500/20 text-red-400";
  };

  const barWidth = (val: number, max: number) => max > 0 ? `${Math.round((val / max) * 100)}%` : "0%";
  const maxAvg = Math.max(...data.bySubject.map(s => parseFloat(s.avg)), 1);
  const maxGradeCount = Math.max(...data.byGrade.map(g => g.count), 1);

  return (
    <section className="fade-up space-y-6">
      <div>
        <Link href="/academics" className="text-sky-400 hover:text-sky-300 text-sm mb-2 inline-block"><i className="fas fa-arrow-left mr-1"></i> Back to Academics</Link>
        <h2 className="text-3xl font-bold">Academic Analytics</h2>
        <p className="text-slate-400">Analyse class and subject performance trends</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard icon="fa-file-alt" iconBg="bg-blue-500/20" iconColor="text-blue-400" label="Total Grade Entries" value={data.totalGrades} />
        <StatCard icon="fa-chart-line" iconBg="bg-emerald-500/20" iconColor="text-emerald-400" label="Overall Average" value={`${data.overallAvg}%`} />
        <StatCard icon="fa-book" iconBg="bg-purple-500/20" iconColor="text-purple-400" label="Subjects Graded" value={data.bySubject.length} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Subject performance */}
        <div className="card rounded-3xl p-6">
          <h3 className="text-xl font-bold mb-5">Average Score by Subject</h3>
          {data.bySubject.length === 0 ? (
            <p className="text-slate-400 text-center py-10">No grades recorded yet. Go to <Link href="/academics/grading" className="text-sky-400 underline">Grading</Link> to enter scores.</p>
          ) : (
            <div className="space-y-4">
              {data.bySubject
                .sort((a, b) => parseFloat(b.avg) - parseFloat(a.avg))
                .map(s => (
                  <div key={s.subjectId}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="font-medium">{subjectName(s.subjectId)}</span>
                      <span className="text-slate-400">{s.avg}% <span className="text-xs">({s.count} entries)</span></span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-3">
                      <div
                        className="h-3 rounded-full bg-gradient-to-r from-sky-500 to-emerald-400 transition-all"
                        style={{ width: barWidth(parseFloat(s.avg), maxAvg) }}
                      />
                    </div>
                    <div className="flex justify-between text-xs text-slate-500 mt-1">
                      <span>Min: {s.minScore}</span>
                      <span>Max: {s.maxScore}</span>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>

        {/* Grade distribution */}
        <div className="card rounded-3xl p-6">
          <h3 className="text-xl font-bold mb-5">Grade Distribution</h3>
          {data.byGrade.length === 0 ? (
            <p className="text-slate-400 text-center py-10">No data yet.</p>
          ) : (
            <div className="space-y-3">
              {data.byGrade.map(g => (
                <div key={g.grade || "null"} className="flex items-center gap-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold w-12 text-center ${gradeBadgeColor(g.grade)}`}>{g.grade || "—"}</span>
                  <div className="flex-1 bg-slate-800 rounded-full h-4">
                    <div
                      className={`h-4 rounded-full transition-all ${
                        g.grade?.startsWith("A") ? "bg-emerald-500" :
                        g.grade?.startsWith("B") ? "bg-blue-500" :
                        g.grade?.startsWith("C") ? "bg-amber-500" :
                        (g.grade?.startsWith("D") || g.grade?.startsWith("E")) ? "bg-orange-500" :
                        "bg-red-500"
                      }`}
                      style={{ width: barWidth(g.count, maxGradeCount) }}
                    />
                  </div>
                  <span className="text-sm font-semibold w-10 text-right">{g.count}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
