import { db } from "@/db";
import { grades, subjects, classes, students } from "@/db/schema";
import { sql, eq, asc } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import AnalyticsContent from "./AnalyticsContent";

export const dynamic = "force-dynamic";

async function getAnalyticsData() {
  const bySubject = await db
    .select({
      subjectId: grades.subjectId,
      avg: sql<string>`ROUND(AVG(${grades.totalScore}),1)`,
      count: sql<number>`count(*)::int`,
      maxScore: sql<string>`MAX(${grades.totalScore})`,
      minScore: sql<string>`MIN(${grades.totalScore})`,
    })
    .from(grades)
    .groupBy(grades.subjectId);

  const byGrade = await db
    .select({
      grade: grades.grade,
      count: sql<number>`count(*)::int`,
    })
    .from(grades)
    .groupBy(grades.grade)
    .orderBy(grades.grade);

  const subjectsList = await db.select().from(subjects).orderBy(asc(subjects.name));
  const classesList = await db.select().from(classes).orderBy(asc(classes.name));

  const [totalGrades] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(grades);

  const [overallAvg] = await db
    .select({ avg: sql<string>`COALESCE(ROUND(AVG(${grades.totalScore}),1), 0)` })
    .from(grades);

  return { bySubject, byGrade, subjectsList, classesList, totalGrades: totalGrades.count, overallAvg: parseFloat(overallAvg.avg) };
}

export default async function AnalyticsPage() {
  const data = await getAnalyticsData();

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6">
          <AnalyticsContent data={data} />
        </main>
      </div>
    </div>
  );
}
