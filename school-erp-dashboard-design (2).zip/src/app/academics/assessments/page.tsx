import { db } from "@/db";
import { assessments, subjects, classes } from "@/db/schema";
import { desc, asc } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import AssessmentsContent from "./AssessmentsContent";

export const dynamic = "force-dynamic";

export default async function AssessmentsPage() {
  const [list, subjectsList, classesList] = await Promise.all([
    db.select().from(assessments).orderBy(desc(assessments.createdAt)),
    db.select().from(subjects).orderBy(asc(subjects.name)),
    db.select().from(classes).orderBy(asc(classes.name)),
  ]);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6">
          <AssessmentsContent initialList={list} subjects={subjectsList} classes={classesList} />
        </main>
      </div>
    </div>
  );
}
