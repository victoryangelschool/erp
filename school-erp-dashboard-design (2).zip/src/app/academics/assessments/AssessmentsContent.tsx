"use client";

import { useState } from "react";
import Link from "next/link";
import Modal from "@/components/Modal";

interface Assessment { id: number; title: string; type: string; subjectId: number | null; classId: number | null; totalMarks: number | null; date: string | null; term: string | null; academicYear: string | null; description: string | null; }
interface Subject { id: number; name: string; }
interface Class { id: number; name: string; }

export default function AssessmentsContent({ initialList, subjects, classes: cls }: { initialList: Assessment[]; subjects: Subject[]; classes: Class[] }) {
  const [list, setList] = useState(initialList);
  const [modal, setModal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ title: "", type: "exam", subjectId: "", classId: "", totalMarks: "100", date: "", term: "First Term", academicYear: "2025/2026", description: "" });

  const subjectName = (id: number | null) => subjects.find(s => s.id === id)?.name || "—";
  const className = (id: number | null) => cls.find(c => c.id === id)?.name || "All";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    try {
      const res = await fetch("/api/assessments", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      if (res.ok) { const a = await res.json(); setList([a, ...list]); setModal(false); setForm({ title: "", type: "exam", subjectId: "", classId: "", totalMarks: "100", date: "", term: "First Term", academicYear: "2025/2026", description: "" }); }
    } catch (err) { console.error(err); } finally { setBusy(false); }
  };

  const handleDelete = async (id: number) => { if (!confirm("Delete this assessment?")) return; const res = await fetch(`/api/assessments/${id}`, { method: "DELETE" }); if (res.ok) setList(list.filter(a => a.id !== id)); };

  const typeBadge = (t: string) => {
    const map: Record<string, string> = { exam: "bg-red-500/20 text-red-400", test: "bg-amber-500/20 text-amber-400", quiz: "bg-blue-500/20 text-blue-400", assignment: "bg-green-500/20 text-green-400" };
    return <span className={`px-2 py-1 rounded-full text-xs font-semibold ${map[t] || "bg-slate-500/20 text-slate-400"}`}>{t.charAt(0).toUpperCase() + t.slice(1)}</span>;
  };

  return (
    <section className="fade-up space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <Link href="/academics" className="text-sky-400 hover:text-sky-300 text-sm mb-2 inline-block"><i className="fas fa-arrow-left mr-1"></i> Back to Academics</Link>
          <h2 className="text-3xl font-bold">Assessments</h2>
          <p className="text-slate-400">Create and manage quizzes, assignments, tests and exams</p>
        </div>
        <button onClick={() => setModal(true)} className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold self-start"><i className="fas fa-plus mr-2"></i>Create Assessment</button>
      </div>

      <div className="card rounded-3xl p-6">
        {list.length === 0 ? (
          <p className="text-slate-400 text-center py-10">No assessments created yet.</p>
        ) : (
          <div className="table-wrap overflow-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-300"><tr className="border-b border-slate-700"><th className="py-3 pr-4">Title</th><th className="py-3 pr-4">Type</th><th className="py-3 pr-4">Subject</th><th className="py-3 pr-4">Class</th><th className="py-3 pr-4">Marks</th><th className="py-3 pr-4">Date</th><th className="py-3 pr-4">Term</th><th className="py-3 pr-4 text-right">Actions</th></tr></thead>
              <tbody>
                {list.map(a => (
                  <tr key={a.id} className="border-b border-slate-800/70">
                    <td className="py-3 pr-4 font-semibold">{a.title}</td>
                    <td className="py-3 pr-4">{typeBadge(a.type)}</td>
                    <td className="py-3 pr-4">{subjectName(a.subjectId)}</td>
                    <td className="py-3 pr-4">{className(a.classId)}</td>
                    <td className="py-3 pr-4">{a.totalMarks}</td>
                    <td className="py-3 pr-4">{a.date || "—"}</td>
                    <td className="py-3 pr-4">{a.term || "—"}</td>
                    <td className="py-3 pr-4 text-right"><button onClick={() => handleDelete(a.id)} className="text-red-400 hover:text-red-300"><i className="fas fa-trash"></i></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Modal isOpen={modal} onClose={() => setModal(false)} title="Create Assessment">
        <form onSubmit={handleSubmit}>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="md:col-span-2"><label className="text-sm text-slate-300">Title *</label><input className="input mt-2" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Type *</label>
              <select className="select mt-2" value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}>
                <option value="exam">Exam</option><option value="test">Test</option><option value="quiz">Quiz</option><option value="assignment">Assignment</option>
              </select>
            </div>
            <div><label className="text-sm text-slate-300">Total Marks</label><input type="number" className="input mt-2" value={form.totalMarks} onChange={e => setForm({ ...form, totalMarks: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Subject</label>
              <select className="select mt-2" value={form.subjectId} onChange={e => setForm({ ...form, subjectId: e.target.value })}><option value="">Select</option>{subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
            </div>
            <div><label className="text-sm text-slate-300">Class</label>
              <select className="select mt-2" value={form.classId} onChange={e => setForm({ ...form, classId: e.target.value })}><option value="">All</option>{cls.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
            </div>
            <div><label className="text-sm text-slate-300">Date</label><input type="date" className="input mt-2" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Term</label>
              <select className="select mt-2" value={form.term} onChange={e => setForm({ ...form, term: e.target.value })}><option>First Term</option><option>Second Term</option><option>Third Term</option></select>
            </div>
            <div className="md:col-span-2"><label className="text-sm text-slate-300">Description</label><textarea className="textarea mt-2" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
          </div>
          <div className="mt-6 flex gap-4">
            <button type="submit" disabled={busy} className="btn px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white disabled:opacity-50">{busy ? "Creating…" : "Create Assessment"}</button>
            <button type="button" onClick={() => setModal(false)} className="btn px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button>
          </div>
        </form>
      </Modal>
    </section>
  );
}
