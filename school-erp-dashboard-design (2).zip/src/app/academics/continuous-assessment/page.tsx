import { db } from "@/db";
import { caScores, students, subjects, classes } from "@/db/schema";
import { desc, asc, eq } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import CAContent from "./CAContent";

export const dynamic = "force-dynamic";

export default async function ContinuousAssessmentPage() {
  const [scores, studentsList, subjectsList, classesList] = await Promise.all([
    db.select().from(caScores).orderBy(desc(caScores.createdAt)).limit(200),
    db
      .select({
        id: students.id,
        studentId: students.studentId,
        firstName: students.firstName,
        lastName: students.lastName,
        classId: students.classId,
      })
      .from(students)
      .where(eq(students.status, "active"))
      .orderBy(asc(students.firstName)),
    db.select().from(subjects).orderBy(asc(subjects.name)),
    db.select().from(classes).orderBy(asc(classes.name)),
  ]);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6">
          <CAContent
            initialScores={scores}
            students={studentsList}
            subjects={subjectsList}
            classes={classesList}
          />
        </main>
      </div>
    </div>
  );
}
