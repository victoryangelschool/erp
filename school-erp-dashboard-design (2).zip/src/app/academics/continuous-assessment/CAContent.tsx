"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import Modal from "@/components/Modal";

/* ---------- types ---------- */
interface CAScore {
  id: number;
  studentId: number;
  subjectId: number;
  classId: number | null;
  assessmentTitle: string;
  assessmentType: string;
  scoreObtained: string;
  totalMarks: string;
  date: string | null;
  term: string;
  academicYear: string;
  notes: string | null;
}
interface Student {
  id: number;
  studentId: string;
  firstName: string;
  lastName: string;
  classId: number | null;
}
interface Subject { id: number; name: string; }
interface Class { id: number; name: string; }

interface Summary {
  studentId: number;
  subjectId: number;
  totalObtained: number;
  totalPossible: number;
  count: number;
  percentage: number;
}

const CA_TYPES = [
  { value: "quiz", label: "Quiz" },
  { value: "test", label: "Class Test" },
  { value: "homework", label: "Homework" },
  { value: "classwork", label: "Classwork" },
  { value: "project", label: "Project" },
];

const WEIGHT_OPTIONS = [
  { value: "30:70", label: "30 : 70" },
  { value: "40:60", label: "40 : 60" },
  { value: "50:50", label: "50 : 50" },
];

/* ========================================================== */
export default function CAContent({
  initialScores,
  students,
  subjects,
  classes: cls,
}: {
  initialScores: CAScore[];
  students: Student[];
  subjects: Subject[];
  classes: Class[];
}) {
  /* state */
  const [scores, setScores] = useState<CAScore[]>(initialScores);
  const [tab, setTab] = useState<"scores" | "summary">("scores");

  /* filters */
  const [filterTerm, setFilterTerm] = useState("First Term");
  const [filterYear, setFilterYear] = useState("2025/2026");
  const [filterClass, setFilterClass] = useState("");
  const [filterSubject, setFilterSubject] = useState("");

  /* add score modal */
  const [addModal, setAddModal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    studentId: "",
    subjectId: "",
    classId: "",
    assessmentTitle: "",
    assessmentType: "quiz",
    scoreObtained: "",
    totalMarks: "10",
    date: new Date().toISOString().split("T")[0],
    term: "First Term",
    academicYear: "2025/2026",
    notes: "",
  });

  /* import modal */
  const [importModal, setImportModal] = useState(false);
  const [importBusy, setImportBusy] = useState(false);
  const [importWeight, setImportWeight] = useState("30:70");
  const [importResult, setImportResult] = useState<string | null>(null);

  /* lookups */
  const studentName = (id: number) => {
    const s = students.find((st) => st.id === id);
    return s ? `${s.firstName} ${s.lastName}` : "—";
  };
  const studentCode = (id: number) =>
    students.find((s) => s.id === id)?.studentId || "";
  const subjectName = (id: number) =>
    subjects.find((s) => s.id === id)?.name || "—";
  const className = (id: number | null) =>
    cls.find((c) => c.id === id)?.name || "—";

  const typeBadge = (t: string) => {
    const map: Record<string, string> = {
      quiz: "bg-blue-500/20 text-blue-400",
      test: "bg-amber-500/20 text-amber-400",
      homework: "bg-green-500/20 text-green-400",
      classwork: "bg-purple-500/20 text-purple-400",
      project: "bg-pink-500/20 text-pink-400",
    };
    return (
      <span
        className={`px-2 py-1 rounded-full text-xs font-semibold ${
          map[t] || "bg-slate-500/20 text-slate-400"
        }`}
      >
        {t.charAt(0).toUpperCase() + t.slice(1)}
      </span>
    );
  };

  /* filtered scores */
  const filtered = useMemo(() => {
    return scores.filter((s) => {
      if (s.term !== filterTerm) return false;
      if (s.academicYear !== filterYear) return false;
      if (filterClass && String(s.classId) !== filterClass) return false;
      if (filterSubject && String(s.subjectId) !== filterSubject) return false;
      return true;
    });
  }, [scores, filterTerm, filterYear, filterClass, filterSubject]);

  /* summaries (aggregated per student+subject) */
  const summaries = useMemo<Summary[]>(() => {
    const map = new Map<string, Summary>();
    filtered.forEach((s) => {
      const key = `${s.studentId}:${s.subjectId}`;
      const existing = map.get(key);
      const obt = parseFloat(s.scoreObtained);
      const tot = parseFloat(s.totalMarks);
      if (existing) {
        existing.totalObtained += obt;
        existing.totalPossible += tot;
        existing.count += 1;
        existing.percentage =
          existing.totalPossible > 0
            ? Math.round(
                (existing.totalObtained / existing.totalPossible) * 10000
              ) / 100
            : 0;
      } else {
        map.set(key, {
          studentId: s.studentId,
          subjectId: s.subjectId,
          totalObtained: obt,
          totalPossible: tot,
          count: 1,
          percentage: tot > 0 ? Math.round((obt / tot) * 10000) / 100 : 0,
        });
      }
    });
    return Array.from(map.values()).sort(
      (a, b) => b.percentage - a.percentage
    );
  }, [filtered]);

  /* add score handler */
  const handleAddScore = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const res = await fetch("/api/ca-scores", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        const created = await res.json();
        setScores([created, ...scores]);
        setAddModal(false);
        setForm({
          ...form,
          studentId: "",
          assessmentTitle: "",
          scoreObtained: "",
          notes: "",
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setBusy(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this CA score?")) return;
    const res = await fetch(`/api/ca-scores/${id}`, { method: "DELETE" });
    if (res.ok) setScores(scores.filter((s) => s.id !== id));
  };

  /* import handler */
  const handleImport = async () => {
    setImportBusy(true);
    setImportResult(null);
    try {
      const res = await fetch("/api/ca-scores/summary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          term: filterTerm,
          academicYear: filterYear,
          scoreWeight: importWeight,
          classId: filterClass || null,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setImportResult(
          `✓ Successfully imported ${data.imported} class score(s) into the Grading System.`
        );
      } else {
        setImportResult(`✗ ${data.error || "Import failed"}`);
      }
    } catch (err) {
      console.error(err);
      setImportResult("✗ Import failed. Please try again.");
    } finally {
      setImportBusy(false);
    }
  };

  const classWeightNum = parseInt(importWeight.split(":")[0]);

  /* when student is chosen, auto-fill class */
  const onStudentChange = (studentId: string) => {
    const stu = students.find((s) => String(s.id) === studentId);
    setForm({
      ...form,
      studentId,
      classId: stu?.classId ? String(stu.classId) : form.classId,
    });
  };

  /* ---- render ---- */
  return (
    <section className="fade-up space-y-6">
      {/* header */}
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <Link
            href="/academics"
            className="text-sky-400 hover:text-sky-300 text-sm mb-2 inline-block"
          >
            <i className="fas fa-arrow-left mr-1"></i> Back to Academics
          </Link>
          <h2 className="text-3xl font-bold">Continuous Assessment (CA)</h2>
          <p className="text-slate-400">
            Record quizzes, tests, homework &amp; classwork throughout the term.
            Import the aggregated total as the class score at term end.
          </p>
        </div>
        <div className="flex gap-3 self-start">
          <button
            onClick={() => setAddModal(true)}
            className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"
          >
            <i className="fas fa-plus mr-2"></i>Record Score
          </button>
          <button
            onClick={() => {
              setImportResult(null);
              setImportModal(true);
            }}
            className="btn px-4 py-3 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-semibold"
          >
            <i className="fas fa-file-import mr-2"></i>Import to Grades
          </button>
        </div>
      </div>

      {/* filters */}
      <div className="card rounded-3xl p-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div>
            <label className="text-xs text-slate-400">Term</label>
            <select
              className="select mt-1"
              value={filterTerm}
              onChange={(e) => setFilterTerm(e.target.value)}
            >
              <option>First Term</option>
              <option>Second Term</option>
              <option>Third Term</option>
            </select>
          </div>
          <div>
            <label className="text-xs text-slate-400">Academic Year</label>
            <select
              className="select mt-1"
              value={filterYear}
              onChange={(e) => setFilterYear(e.target.value)}
            >
              <option>2025/2026</option>
              <option>2024/2025</option>
            </select>
          </div>
          <div>
            <label className="text-xs text-slate-400">Class</label>
            <select
              className="select mt-1"
              value={filterClass}
              onChange={(e) => setFilterClass(e.target.value)}
            >
              <option value="">All Classes</option>
              {cls.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs text-slate-400">Subject</label>
            <select
              className="select mt-1"
              value={filterSubject}
              onChange={(e) => setFilterSubject(e.target.value)}
            >
              <option value="">All Subjects</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* tab bar */}
      <div className="flex gap-2">
        <button
          onClick={() => setTab("scores")}
          className={`btn px-5 py-3 rounded-xl font-semibold transition ${
            tab === "scores"
              ? "bg-sky-500 text-white"
              : "bg-white/5 border border-white/10 hover:bg-white/10"
          }`}
        >
          <i className="fas fa-list mr-2"></i>Individual Scores ({filtered.length})
        </button>
        <button
          onClick={() => setTab("summary")}
          className={`btn px-5 py-3 rounded-xl font-semibold transition ${
            tab === "summary"
              ? "bg-sky-500 text-white"
              : "bg-white/5 border border-white/10 hover:bg-white/10"
          }`}
        >
          <i className="fas fa-calculator mr-2"></i>Summary &amp; Totals ({summaries.length})
        </button>
      </div>

      {/* ---- INDIVIDUAL SCORES TAB ---- */}
      {tab === "scores" && (
        <div className="card rounded-3xl p-6">
          {filtered.length === 0 ? (
            <div className="text-center py-16">
              <i className="fas fa-clipboard-list text-4xl text-slate-600 mb-4"></i>
              <p className="text-slate-400">
                No CA scores recorded for {filterTerm} {filterYear}.
              </p>
              <p className="text-slate-500 text-sm mt-1">
                Click &quot;Record Score&quot; to add a quiz, test or homework
                score.
              </p>
            </div>
          ) : (
            <div className="table-wrap overflow-auto">
              <table className="min-w-full text-left text-sm">
                <thead className="text-slate-300">
                  <tr className="border-b border-slate-700">
                    <th className="py-3 pr-4">Student</th>
                    <th className="py-3 pr-4">Subject</th>
                    <th className="py-3 pr-4">Assessment</th>
                    <th className="py-3 pr-4">Type</th>
                    <th className="py-3 pr-4 text-right">Score</th>
                    <th className="py-3 pr-4">Date</th>
                    <th className="py-3 pr-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((s) => (
                    <tr
                      key={s.id}
                      className="border-b border-slate-800/70"
                    >
                      <td className="py-3 pr-4">
                        <p className="font-semibold">
                          {studentName(s.studentId)}
                        </p>
                        <p className="text-xs text-slate-500">
                          {studentCode(s.studentId)}
                        </p>
                      </td>
                      <td className="py-3 pr-4">{subjectName(s.subjectId)}</td>
                      <td className="py-3 pr-4 font-medium">
                        {s.assessmentTitle}
                      </td>
                      <td className="py-3 pr-4">{typeBadge(s.assessmentType)}</td>
                      <td className="py-3 pr-4 text-right font-bold">
                        {s.scoreObtained}
                        <span className="text-slate-500 font-normal">
                          /{s.totalMarks}
                        </span>
                      </td>
                      <td className="py-3 pr-4 text-slate-400 text-xs">
                        {s.date || "—"}
                      </td>
                      <td className="py-3 pr-4 text-right">
                        <button
                          onClick={() => handleDelete(s.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ---- SUMMARY TAB ---- */}
      {tab === "summary" && (
        <div className="card rounded-3xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl font-bold">
                CA Summary — {filterTerm} {filterYear}
              </h3>
              <p className="text-slate-400 text-sm">
                Aggregated totals per student + subject. These are scaled and
                imported as the class score.
              </p>
            </div>
          </div>

          {summaries.length === 0 ? (
            <div className="text-center py-16">
              <i className="fas fa-calculator text-4xl text-slate-600 mb-4"></i>
              <p className="text-slate-400">
                No CA data to summarise. Record some scores first.
              </p>
            </div>
          ) : (
            <div className="table-wrap overflow-auto">
              <table className="min-w-full text-left text-sm">
                <thead className="text-slate-300">
                  <tr className="border-b border-slate-700">
                    <th className="py-3 pr-4">Student</th>
                    <th className="py-3 pr-4">Subject</th>
                    <th className="py-3 pr-4 text-right">Assessments</th>
                    <th className="py-3 pr-4 text-right">Obtained</th>
                    <th className="py-3 pr-4 text-right">Possible</th>
                    <th className="py-3 pr-4 text-right">Percentage</th>
                    <th className="py-3 pr-4 text-right">
                      Scaled to {parseInt(importWeight.split(":")[0])}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {summaries.map((s, i) => {
                    const scaled =
                      s.totalPossible > 0
                        ? Math.round(
                            (s.totalObtained / s.totalPossible) *
                              classWeightNum *
                              100
                          ) / 100
                        : 0;
                    return (
                      <tr
                        key={i}
                        className="border-b border-slate-800/70"
                      >
                        <td className="py-3 pr-4 font-semibold">
                          {studentName(s.studentId)}
                        </td>
                        <td className="py-3 pr-4">
                          {subjectName(s.subjectId)}
                        </td>
                        <td className="py-3 pr-4 text-right">{s.count}</td>
                        <td className="py-3 pr-4 text-right font-semibold">
                          {s.totalObtained}
                        </td>
                        <td className="py-3 pr-4 text-right text-slate-400">
                          {s.totalPossible}
                        </td>
                        <td className="py-3 pr-4 text-right">
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-semibold ${
                              s.percentage >= 70
                                ? "bg-emerald-500/20 text-emerald-400"
                                : s.percentage >= 50
                                ? "bg-amber-500/20 text-amber-400"
                                : "bg-red-500/20 text-red-400"
                            }`}
                          >
                            {s.percentage}%
                          </span>
                        </td>
                        <td className="py-3 pr-4 text-right font-bold text-sky-300">
                          {scaled}
                          <span className="text-slate-500 font-normal text-xs">
                            /{classWeightNum}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* weight selector for preview */}
          <div className="mt-4 p-4 rounded-xl bg-slate-900/60 border border-slate-700/40">
            <label className="text-sm text-slate-300 font-semibold">
              Preview scale with weight:
            </label>
            <div className="flex gap-2 mt-2">
              {WEIGHT_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setImportWeight(opt.value)}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold transition border ${
                    importWeight === opt.value
                      ? "bg-sky-500 border-sky-400 text-white"
                      : "bg-white/5 border-white/10 hover:bg-white/10 text-slate-300"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ---- ADD SCORE MODAL ---- */}
      <Modal
        isOpen={addModal}
        onClose={() => setAddModal(false)}
        title="Record CA Score"
      >
        <form onSubmit={handleAddScore}>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-slate-300">Student *</label>
              <select
                className="select mt-2"
                value={form.studentId}
                onChange={(e) => onStudentChange(e.target.value)}
                required
              >
                <option value="">Select Student</option>
                {students.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.firstName} {s.lastName} ({s.studentId})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm text-slate-300">Subject *</label>
              <select
                className="select mt-2"
                value={form.subjectId}
                onChange={(e) =>
                  setForm({ ...form, subjectId: e.target.value })
                }
                required
              >
                <option value="">Select Subject</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm text-slate-300">Class</label>
              <select
                className="select mt-2"
                value={form.classId}
                onChange={(e) =>
                  setForm({ ...form, classId: e.target.value })
                }
              >
                <option value="">Select</option>
                {cls.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm text-slate-300">Assessment Type *</label>
              <select
                className="select mt-2"
                value={form.assessmentType}
                onChange={(e) =>
                  setForm({ ...form, assessmentType: e.target.value })
                }
              >
                {CA_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>
                    {t.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="text-sm text-slate-300">
                Assessment Title *
              </label>
              <input
                className="input mt-2"
                placeholder="e.g. Week 3 Quiz, Mid-term Test, Homework 5"
                value={form.assessmentTitle}
                onChange={(e) =>
                  setForm({ ...form, assessmentTitle: e.target.value })
                }
                required
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">Score Obtained *</label>
              <input
                type="number"
                step="0.1"
                min="0"
                className="input mt-2"
                placeholder="e.g. 8"
                value={form.scoreObtained}
                onChange={(e) =>
                  setForm({ ...form, scoreObtained: e.target.value })
                }
                required
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">
                Total Marks (out of) *
              </label>
              <input
                type="number"
                step="0.1"
                min="1"
                className="input mt-2"
                placeholder="e.g. 10"
                value={form.totalMarks}
                onChange={(e) =>
                  setForm({ ...form, totalMarks: e.target.value })
                }
                required
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">Date</label>
              <input
                type="date"
                className="input mt-2"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">Term</label>
              <select
                className="select mt-2"
                value={form.term}
                onChange={(e) => setForm({ ...form, term: e.target.value })}
              >
                <option>First Term</option>
                <option>Second Term</option>
                <option>Third Term</option>
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="text-sm text-slate-300">Notes</label>
              <input
                className="input mt-2"
                placeholder="Optional notes"
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
              />
            </div>
          </div>

          {/* live score preview */}
          {form.scoreObtained && form.totalMarks && (
            <div className="mt-4 p-3 rounded-xl bg-slate-900/60 border border-slate-700/40 flex items-center gap-6">
              <div>
                <span className="text-slate-400 text-xs">Score</span>
                <p className="font-bold text-lg">
                  {form.scoreObtained}/{form.totalMarks}
                </p>
              </div>
              <div>
                <span className="text-slate-400 text-xs">Percentage</span>
                <p className="font-bold text-lg">
                  {(
                    (parseFloat(form.scoreObtained) /
                      parseFloat(form.totalMarks)) *
                    100
                  ).toFixed(1)}
                  %
                </p>
              </div>
            </div>
          )}

          <div className="mt-6 flex gap-4">
            <button
              type="submit"
              disabled={busy}
              className="btn px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white disabled:opacity-50"
            >
              {busy ? "Saving…" : "Save Score"}
            </button>
            <button
              type="button"
              onClick={() => setAddModal(false)}
              className="btn px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>

      {/* ---- IMPORT MODAL ---- */}
      <Modal
        isOpen={importModal}
        onClose={() => setImportModal(false)}
        title="Import CA Totals → Class Score"
      >
        <div className="space-y-5">
          <div className="p-4 rounded-xl bg-sky-500/10 border border-sky-500/30">
            <p className="text-sm">
              This will calculate each student&apos;s CA percentage for{" "}
              <strong>
                {filterTerm} {filterYear}
              </strong>
              {filterClass
                ? ` (${className(parseInt(filterClass))})`
                : " (all classes)"}
              , scale it to the class score weight, and save it in the{" "}
              <strong>Grading System</strong> as the Class Score.
            </p>
          </div>

          <div>
            <label className="text-sm text-slate-300 font-semibold">
              Score Weight (Class : Exam)
            </label>
            <div className="flex gap-2 mt-2">
              {WEIGHT_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setImportWeight(opt.value)}
                  className={`flex-1 py-3 rounded-xl text-sm font-semibold transition border ${
                    importWeight === opt.value
                      ? "bg-sky-500 border-sky-400 text-white"
                      : "bg-white/5 border-white/10 hover:bg-white/10 text-slate-300"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
            <p className="text-slate-500 text-xs mt-2">
              CA total will be scaled to a maximum of{" "}
              <strong>{parseInt(importWeight.split(":")[0])}</strong> marks (the
              class score portion).
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-700/40">
            <h4 className="font-semibold text-sm mb-2">How it works:</h4>
            <ol className="text-sm text-slate-400 space-y-1 list-decimal list-inside">
              <li>
                All CA scores for the selected term are summed per
                student+subject
              </li>
              <li>
                The percentage is calculated: (obtained ÷ possible) × 100
              </li>
              <li>
                That percentage is scaled to the class score weight (e.g. 75%
                of 30 = 22.5)
              </li>
              <li>
                The scaled score is saved as the Class Score in the Grading
                System
              </li>
              <li>
                If a grade already exists it updates the class score; otherwise
                it creates a new entry
              </li>
            </ol>
          </div>

          {importResult && (
            <div
              className={`p-4 rounded-xl border ${
                importResult.startsWith("✓")
                  ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                  : "bg-red-500/10 border-red-500/30 text-red-400"
              }`}
            >
              {importResult}
            </div>
          )}

          <div className="flex gap-4">
            <button
              onClick={handleImport}
              disabled={importBusy}
              className="btn flex-1 py-3 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-semibold disabled:opacity-50"
            >
              {importBusy ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>Importing…
                </>
              ) : (
                <>
                  <i className="fas fa-file-import mr-2"></i>Import Now
                </>
              )}
            </button>
            <button
              onClick={() => setImportModal(false)}
              className="btn px-5 py-3 rounded-xl bg-slate-600 hover:bg-slate-500 text-white"
            >
              Close
            </button>
          </div>
        </div>
      </Modal>
    </section>
  );
}
