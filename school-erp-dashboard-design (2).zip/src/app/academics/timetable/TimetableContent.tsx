"use client";

import { useState } from "react";
import Link from "next/link";
import Modal from "@/components/Modal";

interface Entry { id: number; classId: number | null; subjectId: number | null; teacherId: number | null; dayOfWeek: string; startTime: string; endTime: string; room: string | null; }
interface Subject { id: number; name: string; }
interface Class { id: number; name: string; }
interface Staff { id: number; firstName: string; lastName: string; }

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

export default function TimetableContent({ initialEntries, subjects, classes: cls, staff }: { initialEntries: Entry[]; subjects: Subject[]; classes: Class[]; staff: Staff[] }) {
  const [list, setList] = useState(initialEntries);
  const [filterClass, setFilterClass] = useState("");
  const [modal, setModal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ classId: "", subjectId: "", teacherId: "", dayOfWeek: "Monday", startTime: "08:00", endTime: "09:00", room: "", term: "First Term", academicYear: "2025/2026" });

  const subjectName = (id: number | null) => subjects.find(s => s.id === id)?.name || "—";
  const className = (id: number | null) => cls.find(c => c.id === id)?.name || "—";
  const teacherName = (id: number | null) => { const s = staff.find(s => s.id === id); return s ? `${s.firstName} ${s.lastName}` : "—"; };

  const filtered = filterClass ? list.filter(e => String(e.classId) === filterClass) : list;
  const grouped: Record<string, Entry[]> = {};
  DAYS.forEach(d => { grouped[d] = filtered.filter(e => e.dayOfWeek === d).sort((a, b) => a.startTime.localeCompare(b.startTime)); });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    try {
      const res = await fetch("/api/timetable", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      if (res.ok) { const entry = await res.json(); setList([...list, entry]); setModal(false); setForm({ classId: "", subjectId: "", teacherId: "", dayOfWeek: "Monday", startTime: "08:00", endTime: "09:00", room: "", term: "First Term", academicYear: "2025/2026" }); }
    } catch (err) { console.error(err); } finally { setBusy(false); }
  };

  const handleDelete = async (id: number) => { if (!confirm("Delete this entry?")) return; const res = await fetch(`/api/timetable/${id}`, { method: "DELETE" }); if (res.ok) setList(list.filter(e => e.id !== id)); };

  return (
    <section className="fade-up space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <Link href="/academics" className="text-sky-400 hover:text-sky-300 text-sm mb-2 inline-block"><i className="fas fa-arrow-left mr-1"></i> Back to Academics</Link>
          <h2 className="text-3xl font-bold">Timetable</h2>
          <p className="text-slate-400">Create and manage weekly class schedules</p>
        </div>
        <div className="flex gap-3 self-start">
          <select className="select w-44" value={filterClass} onChange={e => setFilterClass(e.target.value)}><option value="">All Classes</option>{cls.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
          <button onClick={() => setModal(true)} className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"><i className="fas fa-plus mr-2"></i>Add Entry</button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="card rounded-3xl p-6 text-center py-16"><i className="fas fa-calendar-alt text-4xl text-slate-600 mb-4"></i><p className="text-slate-400">No timetable entries yet. Click &quot;Add Entry&quot; to create a schedule.</p></div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
          {DAYS.map(day => (
            <div key={day} className="card rounded-2xl p-4">
              <h4 className="font-bold text-center mb-3 text-sky-300">{day}</h4>
              <div className="space-y-2">
                {grouped[day].length === 0 ? (
                  <p className="text-slate-500 text-xs text-center py-4">No classes</p>
                ) : grouped[day].map(entry => (
                  <div key={entry.id} className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/40 group relative">
                    <p className="font-semibold text-sm">{subjectName(entry.subjectId)}</p>
                    <p className="text-xs text-slate-400 mt-1">{entry.startTime} – {entry.endTime}</p>
                    <p className="text-xs text-slate-500">{className(entry.classId)} {entry.room ? `• ${entry.room}` : ""}</p>
                    <p className="text-xs text-slate-500">{teacherName(entry.teacherId)}</p>
                    <button onClick={() => handleDelete(entry.id)} className="absolute top-2 right-2 text-red-400 hover:text-red-300 opacity-0 group-hover:opacity-100 transition"><i className="fas fa-times text-xs"></i></button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modal} onClose={() => setModal(false)} title="Add Timetable Entry">
        <form onSubmit={handleSubmit}>
          <div className="grid md:grid-cols-2 gap-4">
            <div><label className="text-sm text-slate-300">Day *</label>
              <select className="select mt-2" value={form.dayOfWeek} onChange={e => setForm({ ...form, dayOfWeek: e.target.value })}>{DAYS.map(d => <option key={d}>{d}</option>)}</select>
            </div>
            <div><label className="text-sm text-slate-300">Class *</label>
              <select className="select mt-2" value={form.classId} onChange={e => setForm({ ...form, classId: e.target.value })} required><option value="">Select</option>{cls.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
            </div>
            <div><label className="text-sm text-slate-300">Subject *</label>
              <select className="select mt-2" value={form.subjectId} onChange={e => setForm({ ...form, subjectId: e.target.value })} required><option value="">Select</option>{subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
            </div>
            <div><label className="text-sm text-slate-300">Teacher</label>
              <select className="select mt-2" value={form.teacherId} onChange={e => setForm({ ...form, teacherId: e.target.value })}><option value="">Select</option>{staff.map(s => <option key={s.id} value={s.id}>{s.firstName} {s.lastName}</option>)}</select>
            </div>
            <div><label className="text-sm text-slate-300">Start Time *</label><input type="time" className="input mt-2" value={form.startTime} onChange={e => setForm({ ...form, startTime: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">End Time *</label><input type="time" className="input mt-2" value={form.endTime} onChange={e => setForm({ ...form, endTime: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Room</label><input className="input mt-2" value={form.room} onChange={e => setForm({ ...form, room: e.target.value })} /></div>
          </div>
          <div className="mt-6 flex gap-4">
            <button type="submit" disabled={busy} className="btn px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white disabled:opacity-50">{busy ? "Saving…" : "Add Entry"}</button>
            <button type="button" onClick={() => setModal(false)} className="btn px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button>
          </div>
        </form>
      </Modal>
    </section>
  );
}
