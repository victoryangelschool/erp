import { db } from "@/db";
import { timetableEntries, subjects, classes, staff } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import TimetableContent from "./TimetableContent";

export const dynamic = "force-dynamic";

export default async function TimetablePage() {
  const [entries, subjectsList, classesList, staffList] = await Promise.all([
    db.select().from(timetableEntries).orderBy(asc(timetableEntries.dayOfWeek), asc(timetableEntries.startTime)),
    db.select().from(subjects).orderBy(asc(subjects.name)),
    db.select().from(classes).orderBy(asc(classes.name)),
    db.select({ id: staff.id, firstName: staff.firstName, lastName: staff.lastName }).from(staff).where(eq(staff.status, "active")),
  ]);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6">
          <TimetableContent initialEntries={entries} subjects={subjectsList} classes={classesList} staff={staffList} />
        </main>
      </div>
    </div>
  );
}
