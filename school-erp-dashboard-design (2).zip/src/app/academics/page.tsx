import { db } from "@/db";
import { subjects, classes, grades } from "@/db/schema";
import { sql } from "drizzle-orm";
import Link from "next/link";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";

export const dynamic = "force-dynamic";

async function getAcademicStats() {
  const [totalSubjects] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(subjects);
  const [totalClasses] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(classes);
  const [avgResult] = await db
    .select({ avg: sql<string>`COALESCE(AVG(total_score),0)` })
    .from(grades);

  return {
    totalSubjects: totalSubjects.count,
    totalClasses: totalClasses.count,
    averagePerformance: parseFloat(parseFloat(avgResult.avg).toFixed(0)) || 0,
  };
}

const academicModules = [
  {
    title: "Curriculum Management",
    description: "View subjects, assign to classes, and manage the academic structure",
    icon: "fa-book",
    color: "blue",
    href: "/academics/curriculum",
  },
  {
    title: "Assessments",
    description: "Create and manage quizzes, assignments, and exams",
    icon: "fa-tasks",
    color: "green",
    href: "/academics/assessments",
  },
  {
    title: "Continuous Assessment",
    description: "Record CA scores throughout the term and import totals as class scores",
    icon: "fa-pen-fancy",
    color: "rose",
    href: "/academics/continuous-assessment",
  },
  {
    title: "Grading System",
    description: "Enter scores, auto-calculate grades and view student results",
    icon: "fa-clipboard-check",
    color: "amber",
    href: "/academics/grading",
  },
  {
    title: "Timetable",
    description: "Create and manage weekly class schedules",
    icon: "fa-clock",
    color: "purple",
    href: "/academics/timetable",
  },
  {
    title: "Report Cards",
    description: "Generate and view student term report cards",
    icon: "fa-file-alt",
    color: "pink",
    href: "/academics/report-cards",
  },
  {
    title: "Academic Analytics",
    description: "Analyse class and subject performance trends",
    icon: "fa-chart-bar",
    color: "cyan",
    href: "/academics/analytics",
  },
];

const colorMap: Record<string, { bg: string; text: string; button: string }> = {
  blue:   { bg: "bg-blue-500/20",   text: "text-blue-400",   button: "bg-blue-500 hover:bg-blue-400" },
  green:  { bg: "bg-green-500/20",  text: "text-green-400",  button: "bg-green-500 hover:bg-green-400" },
  amber:  { bg: "bg-amber-500/20",  text: "text-amber-400",  button: "bg-amber-500 hover:bg-amber-400" },
  purple: { bg: "bg-purple-500/20", text: "text-purple-400", button: "bg-purple-500 hover:bg-purple-400" },
  pink:   { bg: "bg-pink-500/20",   text: "text-pink-400",   button: "bg-pink-500 hover:bg-pink-400" },
  cyan:   { bg: "bg-cyan-500/20",   text: "text-cyan-400",   button: "bg-cyan-500 hover:bg-cyan-400" },
  rose:   { bg: "bg-rose-500/20",   text: "text-rose-400",   button: "bg-rose-500 hover:bg-rose-400" },
};

export default async function AcademicsPage() {
  const stats = await getAcademicStats();

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6 space-y-6">
          <section className="fade-up">
            <div className="mb-6">
              <h2 className="text-3xl font-bold">Academics</h2>
              <p className="text-slate-400">
                Manage curriculum, assessments, and academic records
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="stat-card card rounded-2xl p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-xl bg-blue-500/20 text-blue-400">
                    <i className="fas fa-book text-2xl"></i>
                  </div>
                  <div className="ml-4">
                    <p className="text-slate-400">Total Subjects</p>
                    <p className="text-3xl font-bold">{stats.totalSubjects}</p>
                  </div>
                </div>
              </div>
              <div className="stat-card card rounded-2xl p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-xl bg-green-500/20 text-green-400">
                    <i className="fas fa-chalkboard text-2xl"></i>
                  </div>
                  <div className="ml-4">
                    <p className="text-slate-400">Total Classes</p>
                    <p className="text-3xl font-bold">{stats.totalClasses}</p>
                  </div>
                </div>
              </div>
              <div className="stat-card card rounded-2xl p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-xl bg-amber-500/20 text-amber-400">
                    <i className="fas fa-chart-line text-2xl"></i>
                  </div>
                  <div className="ml-4">
                    <p className="text-slate-400">Avg. Performance</p>
                    <p className="text-3xl font-bold">{stats.averagePerformance}%</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {academicModules.map((mod) => {
                const c = colorMap[mod.color] || colorMap.blue;
                return (
                  <Link key={mod.href} href={mod.href} className="module-card card rounded-3xl p-6 block">
                    <div className={`p-3 rounded-xl ${c.bg} ${c.text} w-12 h-12 flex items-center justify-center`}>
                      <i className={`fas ${mod.icon} text-2xl`}></i>
                    </div>
                    <h3 className="text-xl font-bold mt-4">{mod.title}</h3>
                    <p className="text-slate-400 mt-2">{mod.description}</p>
                    <span className={`btn mt-4 w-full py-3 rounded-xl ${c.button} text-white font-semibold inline-flex items-center justify-center`}>
                      Access Module <i className="fas fa-arrow-right ml-2"></i>
                    </span>
                  </Link>
                );
              })}
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
