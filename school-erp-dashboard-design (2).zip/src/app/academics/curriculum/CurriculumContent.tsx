"use client";

import { useState } from "react";
import Link from "next/link";
import Modal from "@/components/Modal";

interface Subject { id: number; name: string; code: string | null; description: string | null; classId: number | null; teacherId: number | null; }
interface Class { id: number; name: string; }
interface Staff { id: number; firstName: string; lastName: string; }

export default function CurriculumContent({ subjects: init, classes: cls, staff }: { subjects: Subject[]; classes: Class[]; staff: Staff[] }) {
  const [list, setList] = useState(init);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ name: "", code: "", description: "", classId: "", teacherId: "" });
  const [busy, setBusy] = useState(false);

  const className = (id: number | null) => cls.find(c => c.id === id)?.name || "All Classes";
  const teacherName = (id: number | null) => { const s = staff.find(s => s.id === id); return s ? `${s.firstName} ${s.lastName}` : "—"; };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    try {
      const res = await fetch("/api/subjects", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      if (res.ok) { const s = await res.json(); setList([...list, s].sort((a, b) => a.name.localeCompare(b.name))); setModal(false); setForm({ name: "", code: "", description: "", classId: "", teacherId: "" }); }
    } catch (err) { console.error(err); } finally { setBusy(false); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this subject?")) return;
    const res = await fetch(`/api/subjects/${id}`, { method: "DELETE" });
    if (res.ok) setList(list.filter(s => s.id !== id));
  };

  return (
    <section className="fade-up space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <Link href="/academics" className="text-sky-400 hover:text-sky-300 text-sm mb-2 inline-block"><i className="fas fa-arrow-left mr-1"></i> Back to Academics</Link>
          <h2 className="text-3xl font-bold">Curriculum Management</h2>
          <p className="text-slate-400">View and manage subjects and their class assignments</p>
        </div>
        <button onClick={() => setModal(true)} className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold self-start"><i className="fas fa-plus mr-2"></i>Add Subject</button>
      </div>

      <div className="card rounded-3xl p-6">
        {list.length === 0 ? (
          <p className="text-slate-400 text-center py-10">No subjects yet. Add one or go to <Link href="/settings" className="text-sky-400 underline">Settings</Link> to manage subjects.</p>
        ) : (
          <div className="table-wrap overflow-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-300"><tr className="border-b border-slate-700"><th className="py-3 pr-4">#</th><th className="py-3 pr-4">Subject</th><th className="py-3 pr-4">Code</th><th className="py-3 pr-4">Class</th><th className="py-3 pr-4">Teacher</th><th className="py-3 pr-4 text-right">Actions</th></tr></thead>
              <tbody>
                {list.map((s, i) => (
                  <tr key={s.id} className="border-b border-slate-800/70">
                    <td className="py-3 pr-4 text-slate-400">{i + 1}</td>
                    <td className="py-3 pr-4 font-semibold">{s.name}</td>
                    <td className="py-3 pr-4">{s.code || "—"}</td>
                    <td className="py-3 pr-4">{className(s.classId)}</td>
                    <td className="py-3 pr-4">{teacherName(s.teacherId)}</td>
                    <td className="py-3 pr-4 text-right"><button onClick={() => handleDelete(s.id)} className="text-red-400 hover:text-red-300"><i className="fas fa-trash"></i></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Modal isOpen={modal} onClose={() => setModal(false)} title="Add Subject">
        <form onSubmit={handleSubmit}>
          <div className="grid md:grid-cols-2 gap-4">
            <div><label className="text-sm text-slate-300">Name *</label><input className="input mt-2" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Code</label><input className="input mt-2" value={form.code} onChange={e => setForm({ ...form, code: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Class</label>
              <select className="select mt-2" value={form.classId} onChange={e => setForm({ ...form, classId: e.target.value })}>
                <option value="">All Classes</option>{cls.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div className="md:col-span-2"><label className="text-sm text-slate-300">Description</label><textarea className="textarea mt-2" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
          </div>
          <div className="mt-6 flex gap-4">
            <button type="submit" disabled={busy} className="btn px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white disabled:opacity-50">{busy ? "Saving…" : "Add Subject"}</button>
            <button type="button" onClick={() => setModal(false)} className="btn px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button>
          </div>
        </form>
      </Modal>
    </section>
  );
}
