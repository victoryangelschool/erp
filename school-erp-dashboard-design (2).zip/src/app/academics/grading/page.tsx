import { db } from "@/db";
import { grades, students, subjects, classes } from "@/db/schema";
import { desc, asc, eq } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import GradingContent from "./GradingContent";

export const dynamic = "force-dynamic";

export default async function GradingPage() {
  const [gradesList, studentsList, subjectsList, classesList] = await Promise.all([
    db.select().from(grades).orderBy(desc(grades.createdAt)).limit(100),
    db.select({ id: students.id, studentId: students.studentId, firstName: students.firstName, lastName: students.lastName }).from(students).where(eq(students.status, "active")).orderBy(asc(students.firstName)),
    db.select().from(subjects).orderBy(asc(subjects.name)),
    db.select().from(classes).orderBy(asc(classes.name)),
  ]);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6">
          <GradingContent initialGrades={gradesList} students={studentsList} subjects={subjectsList} classes={classesList} />
        </main>
      </div>
    </div>
  );
}
