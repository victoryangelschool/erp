"use client";

import { useState } from "react";
import Link from "next/link";
import Modal from "@/components/Modal";

interface Grade {
  id: number;
  studentId: number;
  subjectId: number;
  classScore: string | null;
  examScore: string | null;
  totalScore: string | null;
  grade: string | null;
  remarks: string | null;
  term: string | null;
  academicYear: string | null;
  scoreWeight: string | null;
}
interface Student { id: number; studentId: string; firstName: string; lastName: string; }
interface Subject { id: number; name: string; }
interface Class { id: number; name: string; }

const WEIGHT_OPTIONS = [
  { value: "30:70", label: "30% Class : 70% Exam" },
  { value: "40:60", label: "40% Class : 60% Exam" },
  { value: "50:50", label: "50% Class : 50% Exam" },
];

function parseWeight(w: string | null): [number, number] {
  if (!w) return [30, 70];
  const parts = w.split(":").map(Number);
  if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) return [parts[0], parts[1]];
  return [30, 70];
}

export default function GradingContent({
  initialGrades,
  students,
  subjects,
}: {
  initialGrades: Grade[];
  students: Student[];
  subjects: Subject[];
  classes: Class[];
}) {
  const [list, setList] = useState(initialGrades);
  const [modal, setModal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    studentId: "",
    subjectId: "",
    classScore: "",
    examScore: "",
    term: "First Term",
    academicYear: "2025/2026",
    scoreWeight: "30:70",
  });

  const [classPct, examPct] = parseWeight(form.scoreWeight);

  const studentName = (id: number) => {
    const s = students.find((st) => st.id === id);
    return s ? `${s.firstName} ${s.lastName}` : "—";
  };
  const subjectName = (id: number) => subjects.find((s) => s.id === id)?.name || "—";

  const gradeBadgeColor = (g: string | null) => {
    if (!g) return "bg-slate-500/20 text-slate-400";
    if (g.startsWith("A")) return "bg-emerald-500/20 text-emerald-400";
    if (g.startsWith("B")) return "bg-blue-500/20 text-blue-400";
    if (g.startsWith("C")) return "bg-amber-500/20 text-amber-400";
    if (g.startsWith("D") || g.startsWith("E")) return "bg-orange-500/20 text-orange-400";
    return "bg-red-500/20 text-red-400";
  };

  /* live preview of total & grade */
  const previewTotal = (parseFloat(form.classScore) || 0) + (parseFloat(form.examScore) || 0);
  const previewGradeLetter = (() => {
    if (previewTotal >= 80) return "A1";
    if (previewTotal >= 70) return "B2";
    if (previewTotal >= 65) return "B3";
    if (previewTotal >= 60) return "C4";
    if (previewTotal >= 55) return "C5";
    if (previewTotal >= 50) return "C6";
    if (previewTotal >= 45) return "D7";
    if (previewTotal >= 40) return "E8";
    return "F9";
  })();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const res = await fetch("/api/grades", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        const g = await res.json();
        setList([g, ...list]);
        setModal(false);
        setForm({
          studentId: "",
          subjectId: "",
          classScore: "",
          examScore: "",
          term: "First Term",
          academicYear: "2025/2026",
          scoreWeight: form.scoreWeight,
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setBusy(false);
    }
  };

  const weightLabel = (w: string | null) => {
    const [c, x] = parseWeight(w);
    return `${c}:${x}`;
  };

  return (
    <section className="fade-up space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <Link
            href="/academics"
            className="text-sky-400 hover:text-sky-300 text-sm mb-2 inline-block"
          >
            <i className="fas fa-arrow-left mr-1"></i> Back to Academics
          </Link>
          <h2 className="text-3xl font-bold">Grading System</h2>
          <p className="text-slate-400">
            Enter class &amp; exam scores — grades are auto-calculated
          </p>
        </div>
        <button
          onClick={() => setModal(true)}
          className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold self-start"
        >
          <i className="fas fa-plus mr-2"></i>Enter Grades
        </button>
      </div>

      {/* grading scale reference */}
      <div className="card rounded-3xl p-4">
        <p className="text-sm text-slate-300 font-semibold mb-2">
          Ghana Grading Scale (total always out of 100)
        </p>
        <div className="flex flex-wrap gap-2 text-xs">
          {[
            ["A1", "80-100", "Excellent"],
            ["B2", "70-79", "Very Good"],
            ["B3", "65-69", "Good"],
            ["C4", "60-64", "Credit"],
            ["C5", "55-59", "Credit"],
            ["C6", "50-54", "Credit"],
            ["D7", "45-49", "Pass"],
            ["E8", "40-44", "Pass"],
            ["F9", "0-39", "Fail"],
          ].map(([g, r, l]) => (
            <span
              key={g}
              className={`px-2 py-1 rounded-lg ${gradeBadgeColor(g)}`}
            >
              {g} ({r}) — {l}
            </span>
          ))}
        </div>
      </div>

      {/* grades table */}
      <div className="card rounded-3xl p-6">
        {list.length === 0 ? (
          <p className="text-slate-400 text-center py-10">
            No grades recorded yet. Click &quot;Enter Grades&quot; to begin.
          </p>
        ) : (
          <div className="table-wrap overflow-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-300">
                <tr className="border-b border-slate-700">
                  <th className="py-3 pr-4">Student</th>
                  <th className="py-3 pr-4">Subject</th>
                  <th className="py-3 pr-4 text-center">Weight</th>
                  <th className="py-3 pr-4 text-right">Class Score</th>
                  <th className="py-3 pr-4 text-right">Exam Score</th>
                  <th className="py-3 pr-4 text-right">Total</th>
                  <th className="py-3 pr-4">Grade</th>
                  <th className="py-3 pr-4">Remarks</th>
                  <th className="py-3 pr-4">Term</th>
                </tr>
              </thead>
              <tbody>
                {list.map((g) => {
                  const [cw, ew] = parseWeight(g.scoreWeight);
                  return (
                    <tr key={g.id} className="border-b border-slate-800/70">
                      <td className="py-3 pr-4 font-semibold">
                        {studentName(g.studentId)}
                      </td>
                      <td className="py-3 pr-4">{subjectName(g.subjectId)}</td>
                      <td className="py-3 pr-4 text-center">
                        <span className="px-2 py-0.5 rounded-full bg-slate-700/60 text-slate-300 text-xs">
                          {cw}:{ew}
                        </span>
                      </td>
                      <td className="py-3 pr-4 text-right">
                        {g.classScore ?? "—"}
                        <span className="text-slate-500 text-xs">/{cw}</span>
                      </td>
                      <td className="py-3 pr-4 text-right">
                        {g.examScore ?? "—"}
                        <span className="text-slate-500 text-xs">/{ew}</span>
                      </td>
                      <td className="py-3 pr-4 text-right font-bold">
                        {g.totalScore ?? "—"}
                        <span className="text-slate-500 text-xs">/100</span>
                      </td>
                      <td className="py-3 pr-4">
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-semibold ${gradeBadgeColor(
                            g.grade
                          )}`}
                        >
                          {g.grade}
                        </span>
                      </td>
                      <td className="py-3 pr-4">{g.remarks || "—"}</td>
                      <td className="py-3 pr-4 text-slate-400 text-xs">
                        {g.term}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ---- Enter Grades Modal ---- */}
      <Modal
        isOpen={modal}
        onClose={() => setModal(false)}
        title="Enter Student Grades"
      >
        <form onSubmit={handleSubmit}>
          <div className="grid md:grid-cols-2 gap-4">
            {/* score weight selector — full width at top */}
            <div className="md:col-span-2">
              <label className="text-sm text-slate-300 font-semibold">
                Score Weight (Class : Exam)
              </label>
              <div className="flex gap-2 mt-2">
                {WEIGHT_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() =>
                      setForm({ ...form, scoreWeight: opt.value, classScore: "", examScore: "" })
                    }
                    className={`flex-1 py-3 rounded-xl text-sm font-semibold transition border ${
                      form.scoreWeight === opt.value
                        ? "bg-sky-500 border-sky-400 text-white"
                        : "bg-white/5 border-white/10 hover:bg-white/10 text-slate-300"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm text-slate-300">Student *</label>
              <select
                className="select mt-2"
                value={form.studentId}
                onChange={(e) => setForm({ ...form, studentId: e.target.value })}
                required
              >
                <option value="">Select Student</option>
                {students.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.firstName} {s.lastName} ({s.studentId})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm text-slate-300">Subject *</label>
              <select
                className="select mt-2"
                value={form.subjectId}
                onChange={(e) => setForm({ ...form, subjectId: e.target.value })}
                required
              >
                <option value="">Select Subject</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            {/* class score */}
            <div>
              <label className="text-sm text-slate-300">
                Class Score{" "}
                <span className="text-sky-400 font-semibold">
                  (max {classPct})
                </span>
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                max={classPct}
                className="input mt-2"
                placeholder={`0 – ${classPct}`}
                value={form.classScore}
                onChange={(e) =>
                  setForm({ ...form, classScore: e.target.value })
                }
                required
              />
            </div>

            {/* exam score */}
            <div>
              <label className="text-sm text-slate-300">
                Exam Score{" "}
                <span className="text-sky-400 font-semibold">
                  (max {examPct})
                </span>
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                max={examPct}
                className="input mt-2"
                placeholder={`0 – ${examPct}`}
                value={form.examScore}
                onChange={(e) =>
                  setForm({ ...form, examScore: e.target.value })
                }
                required
              />
            </div>

            {/* live preview */}
            {(form.classScore || form.examScore) && (
              <div className="md:col-span-2 p-4 rounded-xl bg-slate-900/60 border border-slate-700/40">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div>
                      <span className="text-slate-400 text-xs">Total</span>
                      <p className="text-2xl font-bold">{previewTotal}/100</p>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs">Grade</span>
                      <p className="mt-0.5">
                        <span
                          className={`px-3 py-1 rounded-full text-sm font-bold ${gradeBadgeColor(
                            previewGradeLetter
                          )}`}
                        >
                          {previewGradeLetter}
                        </span>
                      </p>
                    </div>
                  </div>
                  <div className="text-right text-xs text-slate-500">
                    Weight: {classPct}% class + {examPct}% exam
                  </div>
                </div>
              </div>
            )}

            <div>
              <label className="text-sm text-slate-300">Term</label>
              <select
                className="select mt-2"
                value={form.term}
                onChange={(e) => setForm({ ...form, term: e.target.value })}
              >
                <option>First Term</option>
                <option>Second Term</option>
                <option>Third Term</option>
              </select>
            </div>
            <div>
              <label className="text-sm text-slate-300">Academic Year</label>
              <select
                className="select mt-2"
                value={form.academicYear}
                onChange={(e) =>
                  setForm({ ...form, academicYear: e.target.value })
                }
              >
                <option>2025/2026</option>
                <option>2024/2025</option>
              </select>
            </div>
          </div>
          <div className="mt-6 flex gap-4">
            <button
              type="submit"
              disabled={busy}
              className="btn px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white disabled:opacity-50"
            >
              {busy ? "Saving…" : "Save Grade"}
            </button>
            <button
              type="button"
              onClick={() => setModal(false)}
              className="btn px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>
    </section>
  );
}
