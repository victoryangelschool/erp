import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Inter } from "next/font/google";
import "./globals.css";
import AuthProvider from "@/components/AuthProvider";
import SchoolProvider from "@/components/SchoolProvider";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "School ERP System",
  description: "Comprehensive School Administration Suite",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
      </head>
      <body className={`${inter.className} min-h-screen antialiased`}>
        <AuthProvider>
          <SchoolProvider>
            {children}
          </SchoolProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
