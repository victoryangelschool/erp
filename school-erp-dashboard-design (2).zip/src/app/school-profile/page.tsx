import { db } from "@/db";
import { schoolProfile } from "@/db/schema";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import SchoolProfileForm from "./SchoolProfileForm";

export const dynamic = "force-dynamic";

async function getSchoolProfile() {
  const [profile] = await db.select().from(schoolProfile).limit(1);

  if (!profile) {
    return {
      id: 0,
      name: "Starlight Academy",
      motto: "Excellence, Integrity, Growth",
      phone: "+233 20 000 0000",
      email: "admin@starlight.edu.gh",
      address: "Accra, Ghana",
      logoUrl: null,
      academicYear: "2025/2026",
      currentTerm: "First Term",
      currency: "GHS",
    };
  }

  return profile;
}

export default async function SchoolProfilePage() {
  const profile = await getSchoolProfile();

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6 space-y-6">
          <SchoolProfileForm initialProfile={profile} />
        </main>
      </div>
    </div>
  );
}
