"use client";

import { useState } from "react";

interface SchoolProfile {
  id: number; name: string | null; motto: string | null; phone: string | null;
  email: string | null; address: string | null; logoUrl: string | null;
  academicYear: string | null; currentTerm: string | null; currency: string | null;
}

function toBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader(); r.onload = () => resolve(r.result as string); r.onerror = reject; r.readAsDataURL(file);
  });
}

export default function SchoolProfileForm({ initialProfile }: { initialProfile: SchoolProfile }) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [saved, setSaved] = useState(false);
  const [formData, setFormData] = useState({
    name: initialProfile.name || "Starlight Academy",
    motto: initialProfile.motto || "Excellence, Integrity, Growth",
    phone: initialProfile.phone || "+233 20 000 0000",
    email: initialProfile.email || "admin@starlight.edu.gh",
    address: initialProfile.address || "Accra, Ghana",
    logoUrl: initialProfile.logoUrl || "",
    academicYear: initialProfile.academicYear || "2025/2026",
    currentTerm: initialProfile.currentTerm || "First Term",
    currency: initialProfile.currency || "GHS",
  });

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const base64 = await toBase64(file);
    setFormData({ ...formData, logoUrl: base64 });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true); setSaved(false);
    try {
      const res = await fetch("/api/school-profile", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      if (res.ok) { setSaved(true); setTimeout(() => setSaved(false), 3000); }
    } catch (error) { console.error(error); } finally { setIsSubmitting(false); }
  };

  return (
    <section className="fade-up">
      <div className="mb-6">
        <h2 className="text-3xl font-bold">School Profile</h2>
        <p className="text-slate-400">Manage school information, logo, and settings. This info appears on all printouts.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card rounded-3xl p-6 lg:col-span-2">
          <h3 className="text-2xl font-bold mb-5">School Information</h3>
          <form onSubmit={handleSubmit}>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-slate-300">School Name</label>
                <input className="input mt-2" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} />
              </div>
              <div>
                <label className="text-sm text-slate-300">Motto</label>
                <input className="input mt-2" value={formData.motto} onChange={e => setFormData({ ...formData, motto: e.target.value })} />
              </div>
              <div>
                <label className="text-sm text-slate-300">Phone</label>
                <input className="input mt-2" value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} />
              </div>
              <div>
                <label className="text-sm text-slate-300">Email</label>
                <input type="email" className="input mt-2" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} />
              </div>
              <div className="md:col-span-2">
                <label className="text-sm text-slate-300">Address</label>
                <input className="input mt-2" value={formData.address} onChange={e => setFormData({ ...formData, address: e.target.value })} />
              </div>
              <div className="md:col-span-2">
                <label className="text-sm text-slate-300">School Logo</label>
                <div className="flex items-center gap-4 mt-2">
                  {formData.logoUrl ? (
                    <img src={formData.logoUrl} alt="Logo" className="w-20 h-20 rounded-2xl object-cover border border-white/10" />
                  ) : (
                    <div className="w-20 h-20 rounded-2xl bg-white/10 flex items-center justify-center border border-white/10">
                      <i className="fas fa-school text-2xl text-slate-500"></i>
                    </div>
                  )}
                  <div className="flex-1">
                    <input type="file" accept="image/*" className="input" onChange={handleLogoUpload} />
                    <p className="text-xs text-slate-500 mt-1">This logo appears on all reports, receipts, payslips, and bill statements.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6">
              <h4 className="text-xl font-bold mb-4">Academic Configuration</h4>
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm text-slate-300">Academic Year</label>
                  <select className="select mt-2" value={formData.academicYear} onChange={e => setFormData({ ...formData, academicYear: e.target.value })}>
                    <option>2025/2026</option><option>2024/2025</option><option>2023/2024</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-slate-300">Term/Semester</label>
                  <select className="select mt-2" value={formData.currentTerm} onChange={e => setFormData({ ...formData, currentTerm: e.target.value })}>
                    <option>First Term</option><option>Second Term</option><option>Third Term</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-slate-300">Currency</label>
                  <select className="select mt-2" value={formData.currency} onChange={e => setFormData({ ...formData, currency: e.target.value })}>
                    <option value="GHS">Ghana Cedi (GHS)</option><option value="USD">US Dollar (USD)</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="mt-6 flex items-center gap-4">
              <button type="submit" disabled={isSubmitting} className="btn px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold disabled:opacity-50">
                {isSubmitting ? "Saving…" : "Save School Profile"}
              </button>
              {saved && <span className="text-emerald-400 text-sm font-semibold"><i className="fas fa-check-circle mr-1"></i>Saved successfully!</span>}
            </div>
          </form>
        </div>

        {/* Preview card */}
        <div className="card rounded-3xl p-6">
          <h4 className="font-bold text-xl mb-4">Identity Preview</h4>
          <div className="rounded-3xl bg-gradient-to-br from-sky-500/20 to-emerald-500/10 p-6 border border-white/10">
            <div className="flex items-center gap-4">
              {formData.logoUrl ? (
                <img src={formData.logoUrl} alt="Logo" className="w-16 h-16 rounded-2xl object-cover border border-white/10" />
              ) : (
                <div className="w-16 h-16 rounded-2xl bg-white/10 overflow-hidden border border-white/10 flex items-center justify-center">
                  <span className="text-2xl font-black text-sky-300">{formData.name.charAt(0)}</span>
                </div>
              )}
              <div>
                <p className="text-2xl font-black">{formData.name}</p>
                <p className="text-slate-200 text-sm">{formData.motto}</p>
              </div>
            </div>
          </div>

          {/* Printout preview */}
          <div className="mt-5 p-4 rounded-2xl bg-white text-black text-sm">
            <div className="text-center border-b pb-3 mb-3">
              {formData.logoUrl && <img src={formData.logoUrl} alt="" className="w-12 h-12 rounded-lg object-cover mx-auto mb-1" />}
              <p className="font-bold text-base">{formData.name}</p>
              <p className="text-gray-500 text-xs">{formData.motto}</p>
              <p className="text-gray-500 text-xs">{formData.address} | {formData.phone} | {formData.email}</p>
            </div>
            <p className="text-gray-400 text-xs text-center italic">This is how your school header will appear on printed documents.</p>
          </div>

          <div className="mt-5">
            <h4 className="font-bold text-xl mb-4">Contact</h4>
            <div className="space-y-3">
              <div className="flex items-center"><div className="p-2 rounded-lg bg-blue-500/20 text-blue-400"><i className="fas fa-map-marker-alt"></i></div><p className="ml-3">{formData.address}</p></div>
              <div className="flex items-center"><div className="p-2 rounded-lg bg-green-500/20 text-green-400"><i className="fas fa-phone"></i></div><p className="ml-3">{formData.phone}</p></div>
              <div className="flex items-center"><div className="p-2 rounded-lg bg-amber-500/20 text-amber-400"><i className="fas fa-envelope"></i></div><p className="ml-3">{formData.email}</p></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
