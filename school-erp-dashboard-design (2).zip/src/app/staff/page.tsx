import { db } from "@/db";
import { staff } from "@/db/schema";
import { desc } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import StaffList from "./StaffList";

export const dynamic = "force-dynamic";

export default async function StaffPage() {
  const staffList = await db.select().from(staff).orderBy(desc(staff.createdAt));

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6 space-y-6">
          <StaffList initialStaff={staffList} />
        </main>
      </div>
    </div>
  );
}
