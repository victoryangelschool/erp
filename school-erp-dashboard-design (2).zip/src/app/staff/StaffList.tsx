"use client";

import { useState } from "react";
import Modal from "@/components/Modal";
import { useSchool } from "@/components/SchoolProvider";
import { downloadStaffIdCard } from "@/lib/drawIdCard";

interface Staff {
  id: number; staffId: string; firstName: string; lastName: string;
  email: string | null; phone: string | null; position: string; department: string | null;
  qualification: string | null; yearsOfExperience: number | null; careerStatement: string | null;
  taxId: string | null; ssnitNumber: string | null;
  basicSalary: string | null; hireDate: string | null; photoUrl: string | null; status: string | null;
}

function toBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader(); r.onload = () => resolve(r.result as string); r.onerror = reject; r.readAsDataURL(file);
  });
}



export default function StaffList({ initialStaff }: { initialStaff: Staff[] }) {
  const [staffMembers, setStaffMembers] = useState<Staff[]>(initialStaff);
  const [search, setSearch] = useState("");
  const [addModal, setAddModal] = useState(false);
  const [profileModal, setProfileModal] = useState(false);
  const [idCardModal, setIdCardModal] = useState(false);
  const [selected, setSelected] = useState<Staff | null>(null);
  const [busy, setBusy] = useState(false);
  const [qrData, setQrData] = useState("");
  const school = useSchool();

  const [form, setForm] = useState({
    firstName: "", lastName: "", email: "", phone: "", position: "", department: "",
    qualification: "", yearsOfExperience: "", careerStatement: "",
    taxId: "", ssnitNumber: "",
    basicSalary: "", hireDate: "", photoUrl: "",
  });

  const filtered = staffMembers.filter(s => `${s.firstName} ${s.lastName} ${s.staffId}`.toLowerCase().includes(search.toLowerCase()));

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    setForm({ ...form, photoUrl: await toBase64(file) });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    try {
      const res = await fetch("/api/staff", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      if (res.ok) {
        const s = await res.json(); setStaffMembers([s, ...staffMembers]); setAddModal(false);
        setForm({ firstName: "", lastName: "", email: "", phone: "", position: "", department: "", qualification: "", yearsOfExperience: "", careerStatement: "", taxId: "", ssnitNumber: "", basicSalary: "", hireDate: "", photoUrl: "" });
      }
    } catch (err) { console.error(err); } finally { setBusy(false); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this staff member?")) return;
    const res = await fetch(`/api/staff/${id}`, { method: "DELETE" });
    if (res.ok) setStaffMembers(staffMembers.filter(s => s.id !== id));
  };

  const openProfile = (s: Staff) => { setSelected(s); setProfileModal(true); };

  const openIdCard = async (s: Staff) => {
    setSelected(s);
    const res = await fetch(`/api/id-card?code=${s.staffId}`);
    const data = await res.json();
    setQrData(data.qr || "");
    setIdCardModal(true);
  };

  const handleDownloadIdCard = () => {
    if (!selected) return;
    downloadStaffIdCard({
      staffId: selected.staffId,
      firstName: selected.firstName,
      lastName: selected.lastName,
      position: selected.position,
      department: selected.department || "—",
      qualification: selected.qualification || "—",
      phone: selected.phone || "—",
      photoUrl: selected.photoUrl,
      qrDataUrl: qrData,
      schoolName: school.name,
      schoolLogoUrl: school.logoUrl || undefined,
    });
  };

  return (
    <section className="fade-up space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold">Staff Management</h2>
          <p className="text-slate-400">Manage staff profiles, qualifications, and ID cards</p>
        </div>
        <div className="flex gap-3 self-start">
          <input className="input max-w-xs" placeholder="Search staff..." value={search} onChange={e => setSearch(e.target.value)} />
          <button onClick={() => setAddModal(true)} className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold whitespace-nowrap"><i className="fas fa-plus mr-2"></i>Add Staff</button>
        </div>
      </div>

      <div className="card rounded-3xl p-6">
        <div className="table-wrap overflow-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-300"><tr className="border-b border-slate-700">
              <th className="py-3 pr-4">Photo</th><th className="py-3 pr-4">ID</th><th className="py-3 pr-4">Name</th><th className="py-3 pr-4">Position</th><th className="py-3 pr-4">Department</th><th className="py-3 pr-4">Qualification</th><th className="py-3 pr-4">Status</th><th className="py-3 pr-4 text-right">Actions</th>
            </tr></thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={8} className="py-8 text-center text-slate-400">No staff found.</td></tr>
              ) : filtered.map(s => (
                <tr key={s.id} className="border-b border-slate-800/70">
                  <td className="py-3 pr-4">
                    {s.photoUrl ? <img src={s.photoUrl} alt="" className="w-10 h-10 rounded-full object-cover" /> : <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center"><i className="fas fa-user text-green-400"></i></div>}
                  </td>
                  <td className="py-3 pr-4 font-mono text-xs">{s.staffId}</td>
                  <td className="py-3 pr-4 font-semibold">{s.firstName} {s.lastName}</td>
                  <td className="py-3 pr-4">{s.position}</td>
                  <td className="py-3 pr-4">{s.department || "—"}</td>
                  <td className="py-3 pr-4 text-xs">{s.qualification || "—"}</td>
                  <td className="py-3 pr-4"><span className={`px-2 py-1 rounded-full text-xs ${s.status === "active" ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}>{s.status}</span></td>
                  <td className="py-3 pr-4 text-right space-x-2">
                    <button onClick={() => openProfile(s)} className="text-sky-400 hover:text-sky-300" title="Profile"><i className="fas fa-eye"></i></button>
                    <button onClick={() => openIdCard(s)} className="text-purple-400 hover:text-purple-300" title="ID Card"><i className="fas fa-id-card"></i></button>
                    <button onClick={() => handleDelete(s.id)} className="text-red-400 hover:text-red-300" title="Delete"><i className="fas fa-trash"></i></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD STAFF MODAL */}
      <Modal isOpen={addModal} onClose={() => setAddModal(false)} title="Add New Staff">
        <form onSubmit={handleSubmit}>
          <div className="grid md:grid-cols-2 gap-4">
            <div><label className="text-sm text-slate-300">First Name *</label><input className="input mt-2" value={form.firstName} onChange={e => setForm({ ...form, firstName: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Last Name *</label><input className="input mt-2" value={form.lastName} onChange={e => setForm({ ...form, lastName: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Email</label><input type="email" className="input mt-2" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Phone</label><input className="input mt-2" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Position *</label><input className="input mt-2" value={form.position} onChange={e => setForm({ ...form, position: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Department</label><select className="select mt-2" value={form.department} onChange={e => setForm({ ...form, department: e.target.value })}><option value="">Select</option><option>Academics</option><option>Administration</option><option>Finance</option><option>IT</option><option>Support</option></select></div>
            <div><label className="text-sm text-slate-300">Qualification</label><input className="input mt-2" placeholder="e.g. B.Ed Mathematics" value={form.qualification} onChange={e => setForm({ ...form, qualification: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Years of Experience</label><input type="number" className="input mt-2" value={form.yearsOfExperience} onChange={e => setForm({ ...form, yearsOfExperience: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Tax ID (TIN)</label><input className="input mt-2" placeholder="e.g. P00XXXXXXX" value={form.taxId} onChange={e => setForm({ ...form, taxId: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">SSNIT Number</label><input className="input mt-2" placeholder="e.g. C/XXX/XXXXXXXX" value={form.ssnitNumber} onChange={e => setForm({ ...form, ssnitNumber: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Basic Salary (GHS)</label><input type="number" className="input mt-2" value={form.basicSalary} onChange={e => setForm({ ...form, basicSalary: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Hire Date</label><input type="date" className="input mt-2" value={form.hireDate} onChange={e => setForm({ ...form, hireDate: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Photo</label><input type="file" accept="image/*" className="input mt-2" onChange={handlePhotoUpload} />{form.photoUrl && <img src={form.photoUrl} alt="" className="w-16 h-16 rounded-lg object-cover mt-2" />}</div>
            <div className="md:col-span-2"><label className="text-sm text-slate-300">Career Statement</label><textarea className="textarea mt-2" placeholder="Brief career objective or statement" value={form.careerStatement} onChange={e => setForm({ ...form, careerStatement: e.target.value })} /></div>
          </div>
          <div className="mt-6 flex gap-4">
            <button type="submit" disabled={busy} className="btn px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white disabled:opacity-50">{busy ? "Saving…" : "Add Staff"}</button>
            <button type="button" onClick={() => setAddModal(false)} className="btn px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button>
          </div>
        </form>
      </Modal>

      {/* PROFILE MODAL */}
      {selected && (
        <Modal isOpen={profileModal} onClose={() => setProfileModal(false)} title="Staff Profile">
          <div className="space-y-6">
            <div className="flex items-center gap-6">
              {selected.photoUrl ? <img src={selected.photoUrl} alt="" className="w-28 h-28 rounded-2xl object-cover border border-white/10" /> : <div className="w-28 h-28 rounded-2xl bg-green-500/20 flex items-center justify-center"><i className="fas fa-user text-4xl text-green-400"></i></div>}
              <div>
                <p className="text-2xl font-bold">{selected.firstName} {selected.lastName}</p>
                <p className="text-slate-400">{selected.position}</p>
                <p className="font-mono text-sm text-sky-300 mt-1">{selected.staffId}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><span className="text-xs text-slate-400">Department</span><p>{selected.department || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Qualification</span><p>{selected.qualification || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Years of Experience</span><p>{selected.yearsOfExperience ?? "—"}</p></div>
              <div><span className="text-xs text-slate-400">Hire Date</span><p>{selected.hireDate || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Email</span><p>{selected.email || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Phone</span><p>{selected.phone || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Tax ID (TIN)</span><p>{selected.taxId || "—"}</p></div>
              <div><span className="text-xs text-slate-400">SSNIT Number</span><p>{selected.ssnitNumber || "—"}</p></div>
            </div>
            {selected.careerStatement && (
              <div><span className="text-xs text-slate-400">Career Statement</span><p className="mt-1 p-3 rounded-xl bg-slate-900/60 border border-slate-700/40 text-sm">{selected.careerStatement}</p></div>
            )}
            <button onClick={() => { setProfileModal(false); openIdCard(selected); }} className="btn w-full py-3 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-semibold"><i className="fas fa-id-card mr-2"></i>View &amp; Download ID Card</button>
          </div>
        </Modal>
      )}

      {/* ID CARD MODAL */}
      {selected && (
        <Modal isOpen={idCardModal} onClose={() => setIdCardModal(false)} title="Staff ID Card">
          <div className="flex flex-col items-center gap-6">
            {/* visual preview */}
            <div className="w-[360px] rounded-2xl overflow-hidden shadow-lg" style={{ background: "linear-gradient(135deg, #0f172a, #1a3a2a)" }}>
              <div className="bg-emerald-600 p-3 text-center flex items-center justify-center gap-2">
                {school.logoUrl && <img src={school.logoUrl} alt="" className="w-8 h-8 rounded object-cover" />}
                <div>
                  <p className="text-white font-black text-lg">{school.name.toUpperCase()}</p>
                  <p className="text-emerald-100 text-xs">Staff Identification Card</p>
                </div>
              </div>
              <div className="p-5 flex gap-4 items-start">
                <div className="flex-shrink-0">
                  {selected.photoUrl ? <img src={selected.photoUrl} alt="" className="w-20 h-24 rounded-lg object-cover border-2 border-white/20" /> : <div className="w-20 h-24 rounded-lg bg-white/10 flex items-center justify-center"><i className="fas fa-user text-2xl text-white/50"></i></div>}
                </div>
                <div className="text-white space-y-1 text-sm min-w-0">
                  <p className="font-bold text-base">{selected.firstName} {selected.lastName}</p>
                  <p className="text-emerald-200"><span className="text-emerald-400 text-xs">ID:</span> {selected.staffId}</p>
                  <p className="text-emerald-200"><span className="text-emerald-400 text-xs">Position:</span> {selected.position}</p>
                  <p className="text-emerald-200"><span className="text-emerald-400 text-xs">Dept:</span> {selected.department || "—"}</p>
                </div>
              </div>
              <div className="px-5 pb-4 flex items-end justify-between">
                <div className="text-white text-xs space-y-0.5">
                  <p><span className="text-emerald-400">Qualification:</span> {selected.qualification || "—"}</p>
                  <p><span className="text-emerald-400">Phone:</span> {selected.phone || "—"}</p>
                </div>
                {qrData && <img src={qrData} alt="QR" className="w-16 h-16 rounded" />}
              </div>
            </div>
            <button onClick={handleDownloadIdCard} className="btn px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"><i className="fas fa-download mr-2"></i>Download as Image</button>
          </div>
        </Modal>
      )}
    </section>
  );
}
