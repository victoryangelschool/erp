import { db } from "@/db";
import { students, classes } from "@/db/schema";
import { desc } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import StudentList from "./StudentList";

export const dynamic = "force-dynamic";

export default async function StudentsPage() {
  const [studentsList, classesList] = await Promise.all([
    db.select().from(students).orderBy(desc(students.createdAt)),
    db.select().from(classes).orderBy(classes.name),
  ]);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6 space-y-6">
          <StudentList initialStudents={studentsList} classes={classesList} />
        </main>
      </div>
    </div>
  );
}
