"use client";

import { useState } from "react";
import Modal from "@/components/Modal";
import { useSchool } from "@/components/SchoolProvider";
import { downloadStudentIdCard } from "@/lib/drawIdCard";

interface Student {
  id: number; studentId: string; firstName: string; lastName: string;
  dateOfBirth: string | null; gender: string | null; classId: number | null;
  parentName: string | null; parentPhone: string | null; parentEmail: string | null;
  guardianPhotoUrl: string | null; address: string | null; gpsLocation: string | null;
  admissionDate: string | null; photoUrl: string | null; status: string | null;
}
interface Class { id: number; name: string; }

function toBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader(); r.onload = () => resolve(r.result as string); r.onerror = reject; r.readAsDataURL(file);
  });
}

export default function StudentList({ initialStudents, classes }: { initialStudents: Student[]; classes: Class[] }) {
  const [students, setStudents] = useState<Student[]>(initialStudents);
  const [search, setSearch] = useState("");
  const [addModal, setAddModal] = useState(false);
  const [profileModal, setProfileModal] = useState(false);
  const [idCardModal, setIdCardModal] = useState(false);
  const [selected, setSelected] = useState<Student | null>(null);
  const [busy, setBusy] = useState(false);
  const [qrData, setQrData] = useState("");
  const school = useSchool();

  const [form, setForm] = useState({
    firstName: "", lastName: "", dateOfBirth: "", gender: "male", classId: "",
    parentName: "", parentPhone: "", parentEmail: "", address: "", gpsLocation: "",
    admissionDate: new Date().toISOString().split("T")[0], photoUrl: "", guardianPhotoUrl: "",
  });

  const filtered = students.filter(s => `${s.firstName} ${s.lastName} ${s.studentId}`.toLowerCase().includes(search.toLowerCase()));
  const className = (id: number | null) => classes.find(c => c.id === id)?.name || "—";

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: "photoUrl" | "guardianPhotoUrl") => {
    const file = e.target.files?.[0]; if (!file) return;
    const base64 = await toBase64(file);
    setForm({ ...form, [field]: base64 });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    try {
      const res = await fetch("/api/students", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      if (res.ok) {
        const s = await res.json(); setStudents([s, ...students]); setAddModal(false);
        setForm({ firstName: "", lastName: "", dateOfBirth: "", gender: "male", classId: "", parentName: "", parentPhone: "", parentEmail: "", address: "", gpsLocation: "", admissionDate: new Date().toISOString().split("T")[0], photoUrl: "", guardianPhotoUrl: "" });
      }
    } catch (err) { console.error(err); } finally { setBusy(false); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this student?")) return;
    const res = await fetch(`/api/students/${id}`, { method: "DELETE" });
    if (res.ok) setStudents(students.filter(s => s.id !== id));
  };

  const openProfile = (s: Student) => { setSelected(s); setProfileModal(true); };

  const openIdCard = async (s: Student) => {
    setSelected(s);
    const res = await fetch(`/api/id-card?code=${s.studentId}`);
    const data = await res.json();
    setQrData(data.qr || "");
    setIdCardModal(true);
  };

  const handleDownloadIdCard = () => {
    if (!selected) return;
    downloadStudentIdCard({
      studentId: selected.studentId,
      firstName: selected.firstName,
      lastName: selected.lastName,
      className: className(selected.classId),
      dateOfBirth: selected.dateOfBirth || "—",
      parentName: selected.parentName || "—",
      parentPhone: selected.parentPhone || "—",
      photoUrl: selected.photoUrl,
      qrDataUrl: qrData,
      schoolName: school.name,
      schoolLogoUrl: school.logoUrl || undefined,
    });
  };

  return (
    <section className="fade-up space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold">Student Management</h2>
          <p className="text-slate-400">Manage student profiles, photos, and ID cards</p>
        </div>
        <div className="flex gap-3 self-start">
          <input className="input max-w-xs" placeholder="Search students..." value={search} onChange={e => setSearch(e.target.value)} />
          <button onClick={() => setAddModal(true)} className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold whitespace-nowrap"><i className="fas fa-plus mr-2"></i>Add Student</button>
        </div>
      </div>

      <div className="card rounded-3xl p-6">
        <div className="table-wrap overflow-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-300"><tr className="border-b border-slate-700">
              <th className="py-3 pr-4">Photo</th><th className="py-3 pr-4">ID</th><th className="py-3 pr-4">Name</th><th className="py-3 pr-4">Class</th><th className="py-3 pr-4">DOB</th><th className="py-3 pr-4">Admission</th><th className="py-3 pr-4">Status</th><th className="py-3 pr-4 text-right">Actions</th>
            </tr></thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={8} className="py-8 text-center text-slate-400">No students found.</td></tr>
              ) : filtered.map(s => (
                <tr key={s.id} className="border-b border-slate-800/70">
                  <td className="py-3 pr-4">
                    {s.photoUrl ? <img src={s.photoUrl} alt="" className="w-10 h-10 rounded-full object-cover" /> : <div className="w-10 h-10 rounded-full bg-sky-500/20 flex items-center justify-center"><i className="fas fa-user text-sky-400"></i></div>}
                  </td>
                  <td className="py-3 pr-4 font-mono text-xs">{s.studentId}</td>
                  <td className="py-3 pr-4 font-semibold">{s.firstName} {s.lastName}</td>
                  <td className="py-3 pr-4">{className(s.classId)}</td>
                  <td className="py-3 pr-4 text-xs">{s.dateOfBirth || "—"}</td>
                  <td className="py-3 pr-4 text-xs">{s.admissionDate || "—"}</td>
                  <td className="py-3 pr-4"><span className={`px-2 py-1 rounded-full text-xs ${s.status === "active" ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}>{s.status}</span></td>
                  <td className="py-3 pr-4 text-right space-x-2">
                    <button onClick={() => openProfile(s)} className="text-sky-400 hover:text-sky-300" title="View Profile"><i className="fas fa-eye"></i></button>
                    <button onClick={() => openIdCard(s)} className="text-purple-400 hover:text-purple-300" title="ID Card"><i className="fas fa-id-card"></i></button>
                    <button onClick={() => handleDelete(s.id)} className="text-red-400 hover:text-red-300" title="Delete"><i className="fas fa-trash"></i></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD STUDENT MODAL */}
      <Modal isOpen={addModal} onClose={() => setAddModal(false)} title="Register New Student">
        <form onSubmit={handleSubmit}>
          <div className="grid md:grid-cols-2 gap-4">
            <div><label className="text-sm text-slate-300">First Name *</label><input className="input mt-2" value={form.firstName} onChange={e => setForm({ ...form, firstName: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Last Name *</label><input className="input mt-2" value={form.lastName} onChange={e => setForm({ ...form, lastName: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Date of Birth</label><input type="date" className="input mt-2" value={form.dateOfBirth} onChange={e => setForm({ ...form, dateOfBirth: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Gender</label><select className="select mt-2" value={form.gender} onChange={e => setForm({ ...form, gender: e.target.value })}><option value="male">Male</option><option value="female">Female</option></select></div>
            <div><label className="text-sm text-slate-300">Class</label><select className="select mt-2" value={form.classId} onChange={e => setForm({ ...form, classId: e.target.value })}><option value="">Select</option>{classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
            <div><label className="text-sm text-slate-300">Date of Admission</label><input type="date" className="input mt-2" value={form.admissionDate} onChange={e => setForm({ ...form, admissionDate: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Student Photo</label><input type="file" accept="image/*" className="input mt-2" onChange={e => handlePhotoUpload(e, "photoUrl")} />{form.photoUrl && <img src={form.photoUrl} alt="" className="w-16 h-16 rounded-lg object-cover mt-2" />}</div>
            <div><label className="text-sm text-slate-300">Guardian Photo</label><input type="file" accept="image/*" className="input mt-2" onChange={e => handlePhotoUpload(e, "guardianPhotoUrl")} />{form.guardianPhotoUrl && <img src={form.guardianPhotoUrl} alt="" className="w-16 h-16 rounded-lg object-cover mt-2" />}</div>
            <div><label className="text-sm text-slate-300">Guardian Name</label><input className="input mt-2" value={form.parentName} onChange={e => setForm({ ...form, parentName: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Guardian Phone</label><input className="input mt-2" value={form.parentPhone} onChange={e => setForm({ ...form, parentPhone: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">Guardian Email</label><input type="email" className="input mt-2" value={form.parentEmail} onChange={e => setForm({ ...form, parentEmail: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">GPS Location</label><input className="input mt-2" placeholder="e.g. 5.6037,-0.1870" value={form.gpsLocation} onChange={e => setForm({ ...form, gpsLocation: e.target.value })} /></div>
            <div className="md:col-span-2"><label className="text-sm text-slate-300">Home Address</label><textarea className="textarea mt-2" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /></div>
          </div>
          <div className="mt-6 flex gap-4">
            <button type="submit" disabled={busy} className="btn px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white disabled:opacity-50">{busy ? "Saving…" : "Register Student"}</button>
            <button type="button" onClick={() => setAddModal(false)} className="btn px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button>
          </div>
        </form>
      </Modal>

      {/* PROFILE MODAL */}
      {selected && (
        <Modal isOpen={profileModal} onClose={() => setProfileModal(false)} title="Student Profile">
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row gap-6">
              <div className="flex flex-col items-center gap-3">
                {selected.photoUrl ? <img src={selected.photoUrl} alt="" className="w-28 h-28 rounded-2xl object-cover border border-white/10" /> : <div className="w-28 h-28 rounded-2xl bg-sky-500/20 flex items-center justify-center"><i className="fas fa-user text-4xl text-sky-400"></i></div>}
                <span className="text-sm text-slate-400">Student</span>
              </div>
              {selected.guardianPhotoUrl && (
                <div className="flex flex-col items-center gap-3">
                  <img src={selected.guardianPhotoUrl} alt="" className="w-28 h-28 rounded-2xl object-cover border border-white/10" />
                  <span className="text-sm text-slate-400">Guardian</span>
                </div>
              )}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><span className="text-xs text-slate-400">Student ID</span><p className="font-mono font-semibold">{selected.studentId}</p></div>
              <div><span className="text-xs text-slate-400">Name</span><p className="font-semibold">{selected.firstName} {selected.lastName}</p></div>
              <div><span className="text-xs text-slate-400">Date of Birth</span><p>{selected.dateOfBirth || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Gender</span><p className="capitalize">{selected.gender || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Class</span><p>{className(selected.classId)}</p></div>
              <div><span className="text-xs text-slate-400">Date of Admission</span><p>{selected.admissionDate || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Guardian</span><p>{selected.parentName || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Guardian Phone</span><p>{selected.parentPhone || "—"}</p></div>
              <div><span className="text-xs text-slate-400">Guardian Email</span><p>{selected.parentEmail || "—"}</p></div>
              <div><span className="text-xs text-slate-400">GPS Location</span><p>{selected.gpsLocation || "—"}</p></div>
              <div className="col-span-2"><span className="text-xs text-slate-400">Address</span><p>{selected.address || "—"}</p></div>
            </div>
            <button onClick={() => { setProfileModal(false); openIdCard(selected); }} className="btn w-full py-3 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-semibold"><i className="fas fa-id-card mr-2"></i>View &amp; Download ID Card</button>
          </div>
        </Modal>
      )}

      {/* ID CARD MODAL */}
      {selected && (
        <Modal isOpen={idCardModal} onClose={() => setIdCardModal(false)} title="Student ID Card">
          <div className="flex flex-col items-center gap-6">
            {/* visual preview */}
            <div className="w-[360px] rounded-2xl overflow-hidden shadow-lg" style={{ background: "linear-gradient(135deg, #0f172a, #1e3a5f)" }}>
              <div className="bg-sky-600 p-3 text-center flex items-center justify-center gap-2">
                {school.logoUrl && <img src={school.logoUrl} alt="" className="w-8 h-8 rounded object-cover" />}
                <div>
                  <p className="text-white font-black text-lg">{school.name.toUpperCase()}</p>
                  <p className="text-sky-100 text-xs">Student Identification Card</p>
                </div>
              </div>
              <div className="p-5 flex gap-4 items-start">
                <div className="flex-shrink-0">
                  {selected.photoUrl ? <img src={selected.photoUrl} alt="" className="w-20 h-24 rounded-lg object-cover border-2 border-white/20" /> : <div className="w-20 h-24 rounded-lg bg-white/10 flex items-center justify-center"><i className="fas fa-user text-2xl text-white/50"></i></div>}
                </div>
                <div className="text-white space-y-1 text-sm min-w-0">
                  <p className="font-bold text-base">{selected.firstName} {selected.lastName}</p>
                  <p className="text-sky-200"><span className="text-sky-400 text-xs">ID:</span> {selected.studentId}</p>
                  <p className="text-sky-200"><span className="text-sky-400 text-xs">Class:</span> {className(selected.classId)}</p>
                  <p className="text-sky-200"><span className="text-sky-400 text-xs">DOB:</span> {selected.dateOfBirth || "—"}</p>
                </div>
              </div>
              <div className="px-5 pb-4 flex items-end justify-between">
                <div className="text-white text-xs space-y-0.5">
                  <p><span className="text-sky-400">Guardian:</span> {selected.parentName || "—"}</p>
                  <p><span className="text-sky-400">Phone:</span> {selected.parentPhone || "—"}</p>
                </div>
                {qrData && <img src={qrData} alt="QR" className="w-16 h-16 rounded" />}
              </div>
            </div>
            <button onClick={handleDownloadIdCard} className="btn px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"><i className="fas fa-download mr-2"></i>Download as Image</button>
          </div>
        </Modal>
      )}
    </section>
  );
}
