"use client";

import { useState, useRef } from "react";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import { useSchool } from "@/components/SchoolProvider";
import { schoolHeaderHtml } from "@/lib/printHeader";

function toBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader(); r.onload = () => resolve(r.result as string); r.onerror = reject; r.readAsDataURL(file);
  });
}

export default function LettersPage() {
  const school = useSchool();
  const [recipient, setRecipient] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [date, setDate] = useState(new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" }));
  const [signatureUrl, setSignatureUrl] = useState("");
  const [signerName, setSignerName] = useState("");
  const [signerTitle, setSignerTitle] = useState("");
  const previewRef = useRef<HTMLDivElement>(null);

  const handleSignatureUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    setSignatureUrl(await toBase64(file));
  };

  const fullHtml = () => {
    const sig = signatureUrl ? `<img src="${signatureUrl}" alt="Signature" style="height:60px;margin:8px 0" />` : "";
    return `
      ${schoolHeaderHtml(school)}
      <p style="text-align:right;color:#555;margin-bottom:20px">${date}</p>
      <p style="margin-bottom:20px"><strong>${recipient}</strong></p>
      ${subject ? `<p style="margin-bottom:16px"><strong>Re: ${subject}</strong></p>` : ""}
      <div style="white-space:pre-wrap;line-height:1.8;margin-bottom:30px">${body}</div>
      <div style="margin-top:40px">
        ${sig}
        ${signerName ? `<p style="margin:0;font-weight:bold">${signerName}</p>` : ""}
        ${signerTitle ? `<p style="margin:0;color:#666;font-size:13px">${signerTitle}</p>` : ""}
      </div>
    `;
  };

  const handlePrint = () => {
    const w = window.open("", "_blank"); if (!w) return;
    w.document.write(`<html><head><title>${subject || "Letter"}</title><style>body{font-family:Arial,sans-serif;padding:40px 50px;color:#111;max-width:750px;margin:auto;font-size:14px}img{max-width:100%}</style></head><body>${fullHtml()}</body></html>`);
    w.document.close(); w.print();
  };

  const handleShareWhatsApp = () => {
    const text = `${school.name}\n${subject ? "Re: " + subject : ""}\n\nDear ${recipient},\n\n${body}\n\n${signerName}\n${signerTitle}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  };

  const handleShareEmail = () => {
    const emailBody = `Dear ${recipient},\n\n${body}\n\n${signerName}\n${signerTitle}\n\n${school.name}\n${school.address}\n${school.phone}`;
    window.open(`mailto:?subject=${encodeURIComponent(subject || "Letter from " + school.name)}&body=${encodeURIComponent(emailBody)}`, "_blank");
  };

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6 space-y-6">
          <section className="fade-up">
            <div className="mb-6">
              <h2 className="text-3xl font-bold">Letter Writing Pad</h2>
              <p className="text-slate-400">Compose official letters with school letterhead, signature, and share via email or WhatsApp</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Editor */}
              <div className="card rounded-3xl p-6 space-y-4">
                <h3 className="text-xl font-bold">Compose Letter</h3>

                <div>
                  <label className="text-sm text-slate-300">Date</label>
                  <input className="input mt-2" value={date} onChange={e => setDate(e.target.value)} />
                </div>

                <div>
                  <label className="text-sm text-slate-300">Recipient / Addressee</label>
                  <textarea className="textarea mt-2" rows={2} placeholder="e.g. The Parent/Guardian of Ama Mensah&#10;P.O. Box 123, Accra" value={recipient} onChange={e => setRecipient(e.target.value)} />
                </div>

                <div>
                  <label className="text-sm text-slate-300">Subject</label>
                  <input className="input mt-2" placeholder="e.g. Notice of School Reopening" value={subject} onChange={e => setSubject(e.target.value)} />
                </div>

                <div>
                  <label className="text-sm text-slate-300">Body</label>
                  <textarea className="textarea mt-2" rows={10} placeholder="Dear Parent/Guardian,&#10;&#10;We write to inform you that..." value={body} onChange={e => setBody(e.target.value)} />
                </div>

                <div className="border-t border-slate-700 pt-4">
                  <h4 className="font-semibold text-sm text-slate-300 mb-3">Signature Block</h4>
                  <div className="grid md:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-slate-400">Signer Name</label>
                      <input className="input mt-1" placeholder="e.g. Mr. John Mensah" value={signerName} onChange={e => setSignerName(e.target.value)} />
                    </div>
                    <div>
                      <label className="text-xs text-slate-400">Title / Position</label>
                      <input className="input mt-1" placeholder="e.g. Headmaster" value={signerTitle} onChange={e => setSignerTitle(e.target.value)} />
                    </div>
                  </div>
                  <div className="mt-3">
                    <label className="text-xs text-slate-400">Upload Signature Image</label>
                    <div className="flex items-center gap-3 mt-1">
                      <input type="file" accept="image/*" className="input flex-1" onChange={handleSignatureUpload} />
                      {signatureUrl && <img src={signatureUrl} alt="Sig" className="h-12 rounded border border-white/10" />}
                    </div>
                  </div>
                </div>

                {/* Action buttons */}
                <div className="flex flex-wrap gap-3 pt-2">
                  <button onClick={handlePrint} className="btn flex-1 py-3 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-semibold">
                    <i className="fas fa-print mr-2"></i>Print / Save PDF
                  </button>
                  <button onClick={handleShareEmail} className="btn px-4 py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold">
                    <i className="fas fa-envelope mr-2"></i>Email
                  </button>
                  <button onClick={handleShareWhatsApp} className="btn px-4 py-3 rounded-xl bg-green-500 hover:bg-green-400 text-white font-semibold">
                    <i className="fab fa-whatsapp mr-2"></i>WhatsApp
                  </button>
                </div>
              </div>

              {/* Live Preview */}
              <div className="card rounded-3xl p-6">
                <h3 className="text-xl font-bold mb-4">Live Preview</h3>
                <div ref={previewRef} className="bg-white text-black rounded-2xl p-8 min-h-[500px]" style={{ fontFamily: "Arial, sans-serif", fontSize: 13, lineHeight: 1.6 }}>
                  {/* Letterhead */}
                  <div style={{ textAlign: "center", borderBottom: "2px solid #333", paddingBottom: 12, marginBottom: 16 }}>
                    {school.logoUrl && <img src={school.logoUrl} alt="" style={{ width: 50, height: 50, borderRadius: 8, objectFit: "cover", margin: "0 auto 4px", display: "block" }} />}
                    <p style={{ margin: 0, fontSize: 20, fontWeight: 800 }}>{school.name}</p>
                    <p style={{ margin: "2px 0", color: "#555", fontSize: 11, fontStyle: "italic" }}>{school.motto}</p>
                    <p style={{ margin: "2px 0", color: "#666", fontSize: 10 }}>{school.address} | {school.phone} | {school.email}</p>
                  </div>

                  <p style={{ textAlign: "right", color: "#555", marginBottom: 16 }}>{date}</p>
                  {recipient && <p style={{ whiteSpace: "pre-wrap", marginBottom: 16 }}><strong>{recipient}</strong></p>}
                  {subject && <p style={{ marginBottom: 12 }}><strong>Re: {subject}</strong></p>}
                  {body ? <div style={{ whiteSpace: "pre-wrap", marginBottom: 30 }}>{body}</div> : <p style={{ color: "#999", fontStyle: "italic" }}>Start typing the letter body on the left...</p>}

                  {(signerName || signatureUrl) && (
                    <div style={{ marginTop: 40 }}>
                      {signatureUrl && <img src={signatureUrl} alt="Signature" style={{ height: 60, marginBottom: 4 }} />}
                      {signerName && <p style={{ margin: 0, fontWeight: "bold" }}>{signerName}</p>}
                      {signerTitle && <p style={{ margin: 0, color: "#666", fontSize: 12 }}>{signerTitle}</p>}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
