"use client";

import { useState, useRef } from "react";
import Modal from "@/components/Modal";
import { useSchool } from "@/components/SchoolProvider";
import { printWithHeader } from "@/lib/printHeader";

interface BillItem { id: number; billId: number; description: string; amount: string; }
interface Payment { id: number; billId: number; amount: string; paymentDate: string | null; paymentMethod: string | null; receiptNumber: string | null; receivedBy: string | null; }
interface Bill { id: number; billNumber: string; studentId: number; term: string; academicYear: string; totalAmount: string; amountPaid: string | null; balance: string; status: string | null; items: BillItem[]; payments: Payment[]; }
interface Student { id: number; studentId: string; firstName: string; lastName: string; classId: number | null; }
interface Class { id: number; name: string; }
interface FeeItem { id: number; name: string; amount: string; classId: number | null; term: string | null; academicYear: string | null; }
interface Props { bills: Bill[]; students: Student[]; classes: Class[]; feeItems: FeeItem[]; }

const p = (v: string | null) => parseFloat(v || "0");
const f = (n: number) => `GHS ${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
interface DraftLine { description: string; amount: string; }

export default function BillingContent({ bills: initBills, students, classes: cls, feeItems }: Props) {
  const school = useSchool();
  const [bills, setBills] = useState<Bill[]>(initBills);
  const [tab, setTab] = useState<"bills" | "create">("bills");
  const [filterTerm, setFilterTerm] = useState("First Term");
  const [filterYear, setFilterYear] = useState("2025/2026");
  const [search, setSearch] = useState("");

  // Create bill
  const [scope, setScope] = useState<"school" | "class" | "student">("school");
  const [createClassId, setCreateClassId] = useState("");
  const [createStudentId, setCreateStudentId] = useState("");
  const [draftLines, setDraftLines] = useState<DraftLine[]>([{ description: "", amount: "" }]);
  const [createBusy, setCreateBusy] = useState(false);
  const [createResult, setCreateResult] = useState<string | null>(null);

  // Pay modal
  const [payModal, setPayModal] = useState(false);
  const [payBill, setPayBill] = useState<Bill | null>(null);
  const [payAmount, setPayAmount] = useState("");
  const [payMethod, setPayMethod] = useState("cash");
  const [payBusy, setPayBusy] = useState(false);

  // Detail / print
  const [detailBill, setDetailBill] = useState<Bill | null>(null);
  const printRef = useRef<HTMLDivElement>(null);

  const sName = (id: number) => { const s = students.find(s => s.id === id); return s ? `${s.firstName} ${s.lastName}` : "—"; };
  const sCode = (id: number) => students.find(s => s.id === id)?.studentId || "";
  const cName = (id: number | null) => cls.find(c => c.id === id)?.name || "—";
  const sClass = (id: number) => { const s = students.find(s => s.id === id); return s ? cName(s.classId) : "—"; };

  const filtered = bills.filter(b => {
    if (b.term !== filterTerm || b.academicYear !== filterYear) return false;
    if (search) {
      const name = sName(b.studentId).toLowerCase();
      const code = sCode(b.studentId).toLowerCase();
      if (!name.includes(search.toLowerCase()) && !code.includes(search.toLowerCase())) return false;
    }
    return true;
  });

  const totalBilled = filtered.reduce((s, b) => s + p(b.totalAmount), 0);
  const totalPaid = filtered.reduce((s, b) => s + p(b.amountPaid), 0);
  const totalBalance = filtered.reduce((s, b) => s + p(b.balance), 0);

  // Line helpers
  const addLine = () => setDraftLines([...draftLines, { description: "", amount: "" }]);
  const removeLine = (i: number) => { if (draftLines.length <= 1) return; setDraftLines(draftLines.filter((_, idx) => idx !== i)); };
  const updateLine = (i: number, field: keyof DraftLine, v: string) => setDraftLines(draftLines.map((l, idx) => idx === i ? { ...l, [field]: v } : l));
  const validLines = draftLines.filter(l => l.description.trim() && parseFloat(l.amount) > 0);
  const draftTotal = validLines.reduce((s, l) => s + parseFloat(l.amount), 0);

  // Students filtered by scope
  const studentsInScope = scope === "class" && createClassId
    ? students.filter(s => String(s.classId) === createClassId)
    : students;
  const scopeCount = scope === "student" ? 1 : scope === "class" ? studentsInScope.length : students.length;

  const handleCreateBill = async (e: React.FormEvent) => {
    e.preventDefault(); if (validLines.length === 0) { alert("Add at least one bill item with a description and amount."); return; }
    setCreateBusy(true); setCreateResult(null);
    try {
      const res = await fetch("/api/billing", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scope, studentId: scope === "student" ? createStudentId : null, classId: scope === "class" ? createClassId : null, term: filterTerm, academicYear: filterYear, items: validLines }) });
      const data = await res.json();
      if (res.ok) {
        setCreateResult(`✓ ${data.message}`);
        // reload bills
        const billsRes = await fetch(`/api/billing?term=${filterTerm}&academicYear=${filterYear}`);
        if (billsRes.ok) setBills(await billsRes.json());
      } else {
        setCreateResult(`✗ ${data.error}`);
      }
    } catch (err) { console.error(err); setCreateResult("✗ Network error"); } finally { setCreateBusy(false); }
  };

  const openPay = (b: Bill) => { setPayBill(b); setPayAmount(""); setPayMethod("cash"); setPayModal(true); };
  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault(); if (!payBill) return; setPayBusy(true);
    try {
      const res = await fetch(`/api/billing/${payBill.id}/pay`, { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: payAmount, paymentMethod: payMethod }) });
      if (res.ok) { window.location.reload(); }
    } catch (err) { console.error(err); } finally { setPayBusy(false); }
  };

  const handlePrint = () => {
    if (!printRef.current) return;
    printWithHeader(school, printRef.current.innerHTML, "Bill Statement");
  };

  const statusBadge = (s: string | null) => {
    const m: Record<string, string> = { unpaid: "bg-red-500/20 text-red-400", partial: "bg-amber-500/20 text-amber-400", paid: "bg-emerald-500/20 text-emerald-400" };
    return <span className={`px-2 py-1 rounded-full text-xs font-semibold ${m[s || ""] || "bg-slate-500/20 text-slate-400"}`}>{(s || "unpaid").charAt(0).toUpperCase() + (s || "unpaid").slice(1)}</span>;
  };

  return (
    <section className="fade-up space-y-6">
      <div className="mb-6"><h2 className="text-3xl font-bold">Student Billing</h2><p className="text-slate-400">Create term bills for the school, a class, or individual students. Track installment payments and print balance statements.</p></div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="stat-card card rounded-2xl p-6"><div className="flex items-center"><div className="p-3 rounded-xl bg-blue-500/20 text-blue-400"><i className="fas fa-file-invoice-dollar text-2xl"></i></div><div className="ml-4"><p className="text-slate-400">Total Billed</p><p className="text-2xl font-bold">{f(totalBilled)}</p></div></div></div>
        <div className="stat-card card rounded-2xl p-6"><div className="flex items-center"><div className="p-3 rounded-xl bg-emerald-500/20 text-emerald-400"><i className="fas fa-check-circle text-2xl"></i></div><div className="ml-4"><p className="text-slate-400">Total Paid</p><p className="text-2xl font-bold">{f(totalPaid)}</p></div></div></div>
        <div className="stat-card card rounded-2xl p-6"><div className="flex items-center"><div className="p-3 rounded-xl bg-red-500/20 text-red-400"><i className="fas fa-exclamation-circle text-2xl"></i></div><div className="ml-4"><p className="text-slate-400">Outstanding</p><p className="text-2xl font-bold">{f(totalBalance)}</p></div></div></div>
      </div>

      {/* Tabs + filters */}
      <div className="flex flex-wrap gap-2 items-center">
        <button onClick={() => setTab("bills")} className={`btn px-5 py-3 rounded-xl font-semibold ${tab === "bills" ? "bg-sky-500 text-white" : "bg-white/5 border border-white/10 hover:bg-white/10"}`}><i className="fas fa-list mr-2"></i>All Bills ({filtered.length})</button>
        <button onClick={() => { setTab("create"); setCreateResult(null); }} className={`btn px-5 py-3 rounded-xl font-semibold ${tab === "create" ? "bg-sky-500 text-white" : "bg-white/5 border border-white/10 hover:bg-white/10"}`}><i className="fas fa-plus mr-2"></i>Create Bill</button>
        <select className="select w-36 ml-auto" value={filterTerm} onChange={e => setFilterTerm(e.target.value)}><option>First Term</option><option>Second Term</option><option>Third Term</option></select>
        <select className="select w-36" value={filterYear} onChange={e => setFilterYear(e.target.value)}><option>2025/2026</option><option>2024/2025</option></select>
        {tab === "bills" && <input className="input w-48" placeholder="Search student..." value={search} onChange={e => setSearch(e.target.value)} />}
      </div>

      {/* ═══ BILLS LIST ═══ */}
      {tab === "bills" && (
        <div className="card rounded-3xl p-6">
          {filtered.length === 0 ? (
            <div className="text-center py-16"><i className="fas fa-file-invoice text-4xl text-slate-600 mb-4"></i><p className="text-slate-400">No bills for {filterTerm} {filterYear}. Switch to &quot;Create Bill&quot; to generate them.</p></div>
          ) : (
            <div className="table-wrap overflow-auto"><table className="min-w-full text-left text-sm"><thead className="text-slate-300"><tr className="border-b border-slate-700">
              <th className="py-3 pr-3">Bill #</th><th className="py-3 pr-3">Student</th><th className="py-3 pr-3">Class</th>
              <th className="py-3 pr-3 text-right">Total</th><th className="py-3 pr-3 text-right">Paid</th><th className="py-3 pr-3 text-right">Balance</th>
              <th className="py-3 pr-3">Status</th><th className="py-3 pr-3 text-right">Actions</th>
            </tr></thead><tbody>
              {filtered.map(b => (
                <tr key={b.id} className="border-b border-slate-800/70">
                  <td className="py-3 pr-3 font-mono text-xs">{b.billNumber}</td>
                  <td className="py-3 pr-3"><p className="font-semibold">{sName(b.studentId)}</p><p className="text-xs text-slate-500">{sCode(b.studentId)}</p></td>
                  <td className="py-3 pr-3 text-xs">{sClass(b.studentId)}</td>
                  <td className="py-3 pr-3 text-right">{f(p(b.totalAmount))}</td>
                  <td className="py-3 pr-3 text-right text-emerald-400">{f(p(b.amountPaid))}</td>
                  <td className="py-3 pr-3 text-right font-bold text-amber-400">{f(p(b.balance))}</td>
                  <td className="py-3 pr-3">{statusBadge(b.status)}</td>
                  <td className="py-3 pr-3 text-right space-x-2">
                    <button onClick={() => setDetailBill(b)} className="text-sky-400 hover:text-sky-300" title="View / Print"><i className="fas fa-eye"></i></button>
                    {b.status !== "paid" && <button onClick={() => openPay(b)} className="text-emerald-400 hover:text-emerald-300" title="Record Payment"><i className="fas fa-money-bill-wave"></i></button>}
                  </td>
                </tr>
              ))}
            </tbody></table></div>
          )}
        </div>
      )}

      {/* ═══ CREATE BILL ═══ */}
      {tab === "create" && (
        <div className="card rounded-3xl p-6">
          <h3 className="text-xl font-bold mb-5">Create Term Bill</h3>
          <form onSubmit={handleCreateBill}>
            {/* Scope selector */}
            <div className="mb-5">
              <label className="text-sm font-semibold text-slate-300 block mb-2">Bill Scope — Who should be billed?</label>
              <div className="flex gap-2">
                {([
                  { value: "school" as const, label: "Whole School", icon: "fa-school", desc: `All ${students.length} active students` },
                  { value: "class" as const, label: "Specific Class", icon: "fa-chalkboard", desc: "All students in a class" },
                  { value: "student" as const, label: "Single Student", icon: "fa-user-graduate", desc: "One individual student" },
                ]).map(opt => (
                  <button key={opt.value} type="button" onClick={() => { setScope(opt.value); setCreateClassId(""); setCreateStudentId(""); }}
                    className={`flex-1 p-4 rounded-xl text-left transition border ${scope === opt.value ? "bg-sky-500/10 border-sky-500/50" : "bg-white/5 border-white/10 hover:bg-white/10"}`}>
                    <div className="flex items-center gap-3">
                      <i className={`fas ${opt.icon} text-lg ${scope === opt.value ? "text-sky-400" : "text-slate-500"}`}></i>
                      <div>
                        <p className={`font-semibold text-sm ${scope === opt.value ? "text-white" : "text-slate-300"}`}>{opt.label}</p>
                        <p className="text-xs text-slate-500">{opt.desc}</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Class / Student selector based on scope */}
            {scope === "class" && (
              <div className="mb-5">
                <label className="text-sm text-slate-300">Select Class *</label>
                <select className="select mt-2" value={createClassId} onChange={e => setCreateClassId(e.target.value)} required>
                  <option value="">Choose a class</option>
                  {cls.map(c => {
                    const count = students.filter(s => s.classId === c.id).length;
                    return <option key={c.id} value={c.id}>{c.name} ({count} students)</option>;
                  })}
                </select>
                {createClassId && (
                  <p className="text-sm text-sky-300 mt-2"><i className="fas fa-users mr-1"></i>{studentsInScope.length} student{studentsInScope.length !== 1 && "s"} will be billed</p>
                )}
              </div>
            )}
            {scope === "student" && (
              <div className="mb-5">
                <label className="text-sm text-slate-300">Select Student *</label>
                <select className="select mt-2" value={createStudentId} onChange={e => setCreateStudentId(e.target.value)} required>
                  <option value="">Choose a student</option>
                  {students.map(s => <option key={s.id} value={s.id}>{s.firstName} {s.lastName} ({s.studentId}) — {cName(s.classId)}</option>)}
                </select>
              </div>
            )}

            {/* Term info */}
            <div className="mb-5 p-3 rounded-xl bg-slate-900/60 border border-slate-700/40 flex gap-6 text-sm">
              <div><span className="text-slate-400">Term:</span> <strong>{filterTerm}</strong></div>
              <div><span className="text-slate-400">Year:</span> <strong>{filterYear}</strong></div>
              <div><span className="text-slate-400">Students:</span> <strong>{scopeCount}</strong></div>
            </div>

            {/* Bill items */}
            <div className="border-t border-slate-700 pt-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-bold text-sky-300"><i className="fas fa-list mr-2"></i>Bill Items</h4>
                <button type="button" onClick={addLine} className="text-sm text-sky-400 hover:text-sky-300 font-semibold"><i className="fas fa-plus mr-1"></i>Add Item</button>
              </div>
              <div className="space-y-2">
                {draftLines.map((line, i) => (
                  <div key={i} className="flex gap-2 items-center">
                    <input className="input flex-1" placeholder="Item description (e.g. Tuition Fee, ICT Levy, Feeding Fee, PTA Dues)" value={line.description} onChange={e => updateLine(i, "description", e.target.value)} />
                    <div className="relative w-40">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm">GHS</span>
                      <input type="number" step="0.01" min="0.01" className="input pl-12 text-right" placeholder="0.00" value={line.amount} onChange={e => updateLine(i, "amount", e.target.value)} />
                    </div>
                    {draftLines.length > 1 && <button type="button" onClick={() => removeLine(i)} className="text-red-400 hover:text-red-300 p-2"><i className="fas fa-times"></i></button>}
                  </div>
                ))}
              </div>

              {/* Summary */}
              {validLines.length > 0 && (
                <div className="mt-4 p-4 rounded-xl bg-slate-900/60 border border-slate-700/40">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-slate-400 text-sm">{validLines.length} item{validLines.length !== 1 && "s"}</span>
                    <span className="font-bold text-xl">{f(draftTotal)}</span>
                  </div>
                  <div className="space-y-1">
                    {validLines.map((l, i) => (
                      <div key={i} className="flex justify-between text-sm">
                        <span className="text-slate-300">{l.description}</span>
                        <span className="text-slate-200">{f(parseFloat(l.amount))}</span>
                      </div>
                    ))}
                  </div>
                  {scope !== "student" && (
                    <div className="mt-3 pt-3 border-t border-slate-700 text-sm text-slate-400">
                      <i className="fas fa-info-circle mr-1"></i>
                      This bill ({f(draftTotal)}) will be created for each of the <strong>{scopeCount}</strong> student{scopeCount !== 1 && "s"}. Students who already have a bill for {filterTerm} {filterYear} will be skipped.
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Result feedback */}
            {createResult && (
              <div className={`mt-4 p-4 rounded-xl border font-semibold ${createResult.startsWith("✓") ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400" : "bg-red-500/10 border-red-500/30 text-red-400"}`}>
                {createResult}
              </div>
            )}

            <div className="mt-5 flex gap-4">
              <button type="submit" disabled={createBusy || validLines.length === 0}
                className="btn flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold disabled:opacity-50">
                {createBusy ? "Creating bills…" : `Create Bill${scopeCount > 1 ? `s (${scopeCount} students)` : ""}`}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ═══ PAY MODAL ═══ */}
      <Modal isOpen={payModal} onClose={() => setPayModal(false)} title={`Record Payment — ${payBill?.billNumber || ""}`}>
        {payBill && (
          <form onSubmit={handlePay}>
            <div className="mb-4 text-sm"><strong>{sName(payBill.studentId)}</strong> ({sCode(payBill.studentId)}) — {sClass(payBill.studentId)}</div>
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-700/40 mb-4 grid grid-cols-3 gap-4 text-center text-sm">
              <div><span className="text-slate-400">Total</span><p className="font-bold">{f(p(payBill.totalAmount))}</p></div>
              <div><span className="text-slate-400">Paid</span><p className="font-bold text-emerald-400">{f(p(payBill.amountPaid))}</p></div>
              <div><span className="text-slate-400">Balance</span><p className="font-bold text-amber-400">{f(p(payBill.balance))}</p></div>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div><label className="text-sm text-slate-300">Amount (GHS) *</label><input type="number" step="0.01" max={p(payBill.balance)} className="input mt-2" value={payAmount} onChange={e => setPayAmount(e.target.value)} required /></div>
              <div><label className="text-sm text-slate-300">Method</label><select className="select mt-2" value={payMethod} onChange={e => setPayMethod(e.target.value)}><option value="cash">Cash</option><option value="mobile_money">Mobile Money</option><option value="bank_transfer">Bank Transfer</option><option value="cheque">Cheque</option></select></div>
            </div>
            <div className="mt-5 flex gap-4">
              <button type="submit" disabled={payBusy} className="btn flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold disabled:opacity-50">{payBusy ? "Processing…" : "Record Payment"}</button>
              <button type="button" onClick={() => setPayModal(false)} className="btn px-5 py-3 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button>
            </div>
          </form>
        )}
      </Modal>

      {/* ═══ DETAIL / PRINT ═══ */}
      {detailBill && (
        <Modal isOpen={!!detailBill} onClose={() => setDetailBill(null)} title={`Bill — ${detailBill.billNumber}`}>
          <div ref={printRef}>
            <p style={{ textAlign: "center", margin: "0 0 12px", fontWeight: "bold" }}>Student Bill / Balance Statement — {detailBill.term} {detailBill.academicYear}</p>
            <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: 8 }}><tbody>
              <tr><td style={{ padding: "4px 8px", color: "#666" }}>Student</td><td style={{ padding: "4px 8px", fontWeight: "bold" }}>{sName(detailBill.studentId)}</td><td style={{ padding: "4px 8px", color: "#666" }}>ID</td><td style={{ padding: "4px 8px" }}>{sCode(detailBill.studentId)}</td></tr>
              <tr><td style={{ padding: "4px 8px", color: "#666" }}>Class</td><td style={{ padding: "4px 8px" }}>{sClass(detailBill.studentId)}</td><td style={{ padding: "4px 8px", color: "#666" }}>Bill #</td><td style={{ padding: "4px 8px" }}>{detailBill.billNumber}</td></tr>
            </tbody></table>
            <h4 style={{ margin: "14px 0 4px" }}>Bill Items</h4>
            <table style={{ width: "100%", borderCollapse: "collapse" }}><thead><tr style={{ background: "#f5f5f5" }}><th style={{ padding: "6px 10px", textAlign: "left", borderBottom: "1px solid #ddd" }}>Description</th><th style={{ padding: "6px 10px", textAlign: "right", borderBottom: "1px solid #ddd" }}>Amount (GHS)</th></tr></thead><tbody>
              {detailBill.items.map(i => <tr key={i.id}><td style={{ padding: "6px 10px", borderBottom: "1px solid #eee" }}>{i.description}</td><td style={{ padding: "6px 10px", textAlign: "right", borderBottom: "1px solid #eee" }}>{p(i.amount).toFixed(2)}</td></tr>)}
              <tr style={{ fontWeight: "bold", borderTop: "2px solid #333" }}><td style={{ padding: "6px 10px" }}>Total</td><td style={{ padding: "6px 10px", textAlign: "right" }}>{p(detailBill.totalAmount).toFixed(2)}</td></tr>
            </tbody></table>
            {detailBill.payments.length > 0 && (<><h4 style={{ margin: "14px 0 4px" }}>Payments Received</h4><table style={{ width: "100%", borderCollapse: "collapse" }}><thead><tr style={{ background: "#f5f5f5" }}><th style={{ padding: "6px 10px", textAlign: "left", borderBottom: "1px solid #ddd" }}>Date</th><th style={{ padding: "6px 10px", textAlign: "left", borderBottom: "1px solid #ddd" }}>Receipt</th><th style={{ padding: "6px 10px", textAlign: "left", borderBottom: "1px solid #ddd" }}>Method</th><th style={{ padding: "6px 10px", textAlign: "right", borderBottom: "1px solid #ddd" }}>Amount</th></tr></thead><tbody>
              {detailBill.payments.map(py => <tr key={py.id}><td style={{ padding: "6px 10px", borderBottom: "1px solid #eee" }}>{py.paymentDate}</td><td style={{ padding: "6px 10px", borderBottom: "1px solid #eee" }}>{py.receiptNumber}</td><td style={{ padding: "6px 10px", borderBottom: "1px solid #eee", textTransform: "capitalize" }}>{py.paymentMethod?.replace("_", " ")}</td><td style={{ padding: "6px 10px", textAlign: "right", borderBottom: "1px solid #eee" }}>{p(py.amount).toFixed(2)}</td></tr>)}
              <tr style={{ fontWeight: "bold", borderTop: "2px solid #333" }}><td colSpan={3} style={{ padding: "6px 10px" }}>Total Paid</td><td style={{ padding: "6px 10px", textAlign: "right" }}>{p(detailBill.amountPaid).toFixed(2)}</td></tr>
            </tbody></table></>)}
            <div style={{ fontSize: 20, padding: 14, borderRadius: 8, textAlign: "center", marginTop: 16, fontWeight: "bold", background: p(detailBill.balance) > 0 ? "#fef3c7" : "#f0fdf4", color: "#111" }}>
              {p(detailBill.balance) > 0 ? `Outstanding Balance: GHS ${p(detailBill.balance).toFixed(2)}` : "FULLY PAID ✓"}
            </div>
          </div>
          <div className="mt-5 flex gap-3">
            <button onClick={handlePrint} className="btn flex-1 py-3 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-semibold"><i className="fas fa-print mr-2"></i>Print Statement</button>
            {detailBill.status !== "paid" && <button onClick={() => { setDetailBill(null); openPay(detailBill); }} className="btn px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"><i className="fas fa-money-bill-wave mr-2"></i>Pay</button>}
            <button onClick={() => setDetailBill(null)} className="btn px-5 py-3 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Close</button>
          </div>
        </Modal>
      )}
    </section>
  );
}
