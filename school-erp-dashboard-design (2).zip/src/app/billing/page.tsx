import { db } from "@/db";
import { studentBills, studentBillItems, studentBillPayments, students, classes, feeStructure } from "@/db/schema";
import { desc, eq, asc } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import BillingContent from "./BillingContent";

export const dynamic = "force-dynamic";

export default async function BillingPage() {
  const [billsList, studentsList, classesList, feeItems] = await Promise.all([
    (async () => {
      const bills = await db.select().from(studentBills).orderBy(desc(studentBills.createdAt)).limit(200);
      const result = [];
      for (const bill of bills) {
        const items = await db.select().from(studentBillItems).where(eq(studentBillItems.billId, bill.id));
        const payments = await db.select().from(studentBillPayments).where(eq(studentBillPayments.billId, bill.id)).orderBy(desc(studentBillPayments.createdAt));
        result.push({ ...bill, items, payments });
      }
      return result;
    })(),
    db.select({ id: students.id, studentId: students.studentId, firstName: students.firstName, lastName: students.lastName, classId: students.classId })
      .from(students).where(eq(students.status, "active")).orderBy(asc(students.firstName)),
    db.select().from(classes).orderBy(asc(classes.name)),
    db.select().from(feeStructure).orderBy(asc(feeStructure.name)),
  ]);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6">
          <BillingContent bills={billsList} students={studentsList} classes={classesList} feeItems={feeItems} />
        </main>
      </div>
    </div>
  );
}
