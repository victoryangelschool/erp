import { NextResponse } from "next/server";
import { db } from "@/db";
import { classes } from "@/db/schema";
import { asc } from "drizzle-orm";

export async function GET() {
  try {
    const allClasses = await db.select().from(classes).orderBy(asc(classes.name));
    return NextResponse.json(allClasses);
  } catch (error) {
    console.error("Error fetching classes:", error);
    return NextResponse.json(
      { error: "Failed to fetch classes" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, level, capacity } = body;

    if (!name || !name.trim()) {
      return NextResponse.json(
        { error: "Class name is required" },
        { status: 400 }
      );
    }

    const [newClass] = await db
      .insert(classes)
      .values({
        name: name.trim(),
        level: level?.trim() || null,
        capacity: capacity ? parseInt(capacity) : 40,
      })
      .returning();

    return NextResponse.json(newClass, { status: 201 });
  } catch (error) {
    console.error("Error creating class:", error);
    return NextResponse.json(
      { error: "Failed to create class" },
      { status: 500 }
    );
  }
}
