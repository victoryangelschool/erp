import { NextResponse } from "next/server";
import { db } from "@/db";
import { classes } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { name, level, capacity } = body;

    const [updated] = await db
      .update(classes)
      .set({
        name: name?.trim(),
        level: level?.trim() || null,
        capacity: capacity ? parseInt(capacity) : 40,
      })
      .where(eq(classes.id, parseInt(id)))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Class not found" }, { status: 404 });
    }

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Error updating class:", error);
    return NextResponse.json(
      { error: "Failed to update class" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const [deleted] = await db
      .delete(classes)
      .where(eq(classes.id, parseInt(id)))
      .returning();

    if (!deleted) {
      return NextResponse.json({ error: "Class not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting class:", error);
    return NextResponse.json(
      { error: "Failed to delete class. It may be referenced by students." },
      { status: 500 }
    );
  }
}
