import { NextResponse } from "next/server";
import { db } from "@/db";
import { staffLoans } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const loans = await db.select().from(staffLoans).orderBy(desc(staffLoans.createdAt));
    return NextResponse.json(loans);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { staffId, type, amount, monthlyDeduction, startDate, description } = body;
    const amt = parseFloat(amount);
    const [created] = await db.insert(staffLoans).values({
      staffId: parseInt(staffId),
      type: type || "loan",
      amount: amt.toString(),
      monthlyDeduction: (parseFloat(monthlyDeduction) || 0).toString(),
      totalRepaid: "0",
      balance: amt.toString(),
      startDate: startDate || null,
      description: description || null,
      isActive: true,
    }).returning();
    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
