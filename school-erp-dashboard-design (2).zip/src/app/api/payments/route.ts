import { NextResponse } from "next/server";
import { db } from "@/db";
import { feePayments, activities } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function GET() {
  try {
    const allPayments = await db.select().from(feePayments);
    return NextResponse.json(allPayments);
  } catch (error) {
    console.error("Error fetching payments:", error);
    return NextResponse.json(
      { error: "Failed to fetch payments" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { studentId, amount, paymentMethod, term, academicYear, notes } = body;

    // Generate receipt number
    const [countResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(feePayments);
    const receiptNumber = `RCP${Date.now().toString().slice(-6)}${String(
      (countResult.count || 0) + 1
    ).padStart(3, "0")}`;

    const [newPayment] = await db
      .insert(feePayments)
      .values({
        studentId: parseInt(studentId),
        amount: amount.toString(),
        paymentMethod,
        receiptNumber,
        term,
        academicYear,
        status: "paid",
        notes: notes || null,
      })
      .returning();

    // Log activity
    await db.insert(activities).values({
      type: "payment",
      title: "Fee payment received",
      description: `GHS ${parseFloat(amount).toLocaleString()} received`,
      entityType: "payment",
      entityId: newPayment.id,
    });

    return NextResponse.json(newPayment, { status: 201 });
  } catch (error) {
    console.error("Error creating payment:", error);
    return NextResponse.json(
      { error: "Failed to create payment" },
      { status: 500 }
    );
  }
}
