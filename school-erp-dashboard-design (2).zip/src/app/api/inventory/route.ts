import { NextResponse } from "next/server";
import { db } from "@/db";
import { inventory } from "@/db/schema";

export async function GET() {
  try {
    const allItems = await db.select().from(inventory);
    return NextResponse.json(allItems);
  } catch (error) {
    console.error("Error fetching inventory:", error);
    return NextResponse.json(
      { error: "Failed to fetch inventory" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, category, quantity, unitPrice, reorderLevel, supplier, location } =
      body;

    // Determine status based on quantity and reorder level
    const qty = parseInt(quantity) || 0;
    const reorder = parseInt(reorderLevel) || 10;
    let status: "in_stock" | "low_stock" | "out_of_stock" = "in_stock";
    
    if (qty <= 0) {
      status = "out_of_stock";
    } else if (qty <= reorder) {
      status = "low_stock";
    }

    const [newItem] = await db
      .insert(inventory)
      .values({
        name,
        category: category || null,
        quantity: qty,
        unitPrice: unitPrice ? unitPrice.toString() : "0",
        reorderLevel: reorder,
        supplier: supplier || null,
        location: location || null,
        status,
      })
      .returning();

    return NextResponse.json(newItem, { status: 201 });
  } catch (error) {
    console.error("Error creating inventory item:", error);
    return NextResponse.json(
      { error: "Failed to create inventory item" },
      { status: 500 }
    );
  }
}
