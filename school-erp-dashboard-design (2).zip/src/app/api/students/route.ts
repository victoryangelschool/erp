import { NextResponse } from "next/server";
import { db } from "@/db";
import { students, activities } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function GET() {
  try {
    const allStudents = await db.select().from(students);
    return NextResponse.json(allStudents);
  } catch (error) {
    console.error("Error fetching students:", error);
    return NextResponse.json({ error: "Failed to fetch students" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      firstName, lastName, dateOfBirth, gender, classId,
      parentName, parentPhone, parentEmail, guardianPhotoUrl,
      address, gpsLocation, admissionDate, photoUrl,
    } = body;

    const [countResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(students);
    const studentNumber = (countResult.count || 0) + 1;
    const studentId = `STU${String(studentNumber).padStart(3, "0")}`;

    const [newStudent] = await db
      .insert(students)
      .values({
        studentId,
        firstName,
        lastName,
        dateOfBirth: dateOfBirth || null,
        gender: gender || null,
        classId: classId ? parseInt(classId) : null,
        parentName: parentName || null,
        parentPhone: parentPhone || null,
        parentEmail: parentEmail || null,
        guardianPhotoUrl: guardianPhotoUrl || null,
        address: address || null,
        gpsLocation: gpsLocation || null,
        admissionDate: admissionDate || null,
        photoUrl: photoUrl || null,
        status: "active",
      })
      .returning();

    await db.insert(activities).values({
      type: "registration",
      title: "New student registration",
      description: `${firstName} ${lastName} has been enrolled`,
      entityType: "student",
      entityId: newStudent.id,
    });

    return NextResponse.json(newStudent, { status: 201 });
  } catch (error) {
    console.error("Error creating student:", error);
    return NextResponse.json({ error: "Failed to create student" }, { status: 500 });
  }
}
