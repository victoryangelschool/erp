import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  students,
  staff,
  attendance,
  transactions,
  payroll,
  feePayments,
  classes,
  grades,
  subjects,
  assets,
  inventory,
} from "@/db/schema";
import { sql, eq, and, gte, lte, desc } from "drizzle-orm";

/* ---- helper: compute date range from period key ---- */
function getDateRange(period: string, term?: string): { start: string; end: string } {
  const now = new Date();
  const y = now.getFullYear();

  switch (period) {
    case "this_month": {
      const s = new Date(y, now.getMonth(), 1);
      const e = new Date(y, now.getMonth() + 1, 0);
      return { start: fmt(s), end: fmt(e) };
    }
    case "last_month": {
      const s = new Date(y, now.getMonth() - 1, 1);
      const e = new Date(y, now.getMonth(), 0);
      return { start: fmt(s), end: fmt(e) };
    }
    case "this_term": {
      // approximate terms for Ghana school calendar
      const t = term || "First Term";
      if (t === "First Term") return { start: `${y}-09-01`, end: `${y}-12-20` };
      if (t === "Second Term") return { start: `${y}-01-06`, end: `${y}-04-10` };
      return { start: `${y}-04-28`, end: `${y}-07-31` }; // Third Term
    }
    case "last_quarter": {
      const qMonth = Math.floor(now.getMonth() / 3) * 3;
      const s = new Date(y, qMonth - 3, 1);
      const e = new Date(y, qMonth, 0);
      return { start: fmt(s), end: fmt(e) };
    }
    case "this_year":
      return { start: `${y}-01-01`, end: `${y}-12-31` };
    case "all_time":
      return { start: "2000-01-01", end: `${y + 1}-12-31` };
    default:
      return { start: `${y}-01-01`, end: `${y}-12-31` };
  }
}
function fmt(d: Date) {
  return d.toISOString().split("T")[0];
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const reportType = searchParams.get("type") || "financial_summary";
    const period = searchParams.get("period") || "this_year";
    const term = searchParams.get("term") || "First Term";

    const { start, end } = getDateRange(period, term);

    let reportData: Record<string, unknown> = {};

    switch (reportType) {
      /* =============== FINANCIAL =============== */
      case "income_statement": {
        const incomeRows = await db
          .select({
            category: transactions.categoryName,
            total: sql<string>`SUM(amount)`,
            count: sql<number>`count(*)::int`,
          })
          .from(transactions)
          .where(
            and(
              eq(transactions.type, "income"),
              gte(transactions.transactionDate, start),
              lte(transactions.transactionDate, end)
            )
          )
          .groupBy(transactions.categoryName);

        const expenseRows = await db
          .select({
            category: transactions.categoryName,
            total: sql<string>`SUM(amount)`,
            count: sql<number>`count(*)::int`,
          })
          .from(transactions)
          .where(
            and(
              eq(transactions.type, "expense"),
              gte(transactions.transactionDate, start),
              lte(transactions.transactionDate, end)
            )
          )
          .groupBy(transactions.categoryName);

        const totalIncome = incomeRows.reduce((s, r) => s + parseFloat(r.total || "0"), 0);
        const totalExpense = expenseRows.reduce((s, r) => s + parseFloat(r.total || "0"), 0);

        reportData = {
          title: "Income Statement",
          period: `${start} to ${end}`,
          sections: [
            {
              heading: "Revenue / Income",
              rows: incomeRows.map((r) => ({
                label: r.category,
                amount: parseFloat(r.total || "0"),
                count: r.count,
              })),
              total: totalIncome,
            },
            {
              heading: "Expenses",
              rows: expenseRows.map((r) => ({
                label: r.category,
                amount: parseFloat(r.total || "0"),
                count: r.count,
              })),
              total: totalExpense,
            },
          ],
          netIncome: totalIncome - totalExpense,
        };
        break;
      }

      case "balance_sheet": {
        const [assetVal] = await db
          .select({ total: sql<string>`COALESCE(SUM(current_value),0)` })
          .from(assets);
        const [invVal] = await db
          .select({ total: sql<string>`COALESCE(SUM(quantity * unit_price),0)` })
          .from(inventory);
        const [totalInc] = await db
          .select({ total: sql<string>`COALESCE(SUM(amount),0)` })
          .from(transactions)
          .where(eq(transactions.type, "income"));
        const [totalExp] = await db
          .select({ total: sql<string>`COALESCE(SUM(amount),0)` })
          .from(transactions)
          .where(eq(transactions.type, "expense"));

        const cashBalance = parseFloat(totalInc.total) - parseFloat(totalExp.total);

        reportData = {
          title: "Balance Sheet",
          period: `As at ${end}`,
          sections: [
            {
              heading: "Assets",
              rows: [
                { label: "Cash & Bank Balance", amount: cashBalance },
                { label: "Fixed Assets (Net)", amount: parseFloat(assetVal.total) },
                { label: "Inventory", amount: parseFloat(invVal.total) },
              ],
              total: cashBalance + parseFloat(assetVal.total) + parseFloat(invVal.total),
            },
            {
              heading: "Equity",
              rows: [
                {
                  label: "Retained Surplus",
                  amount: cashBalance + parseFloat(assetVal.total) + parseFloat(invVal.total),
                },
              ],
              total: cashBalance + parseFloat(assetVal.total) + parseFloat(invVal.total),
            },
          ],
          netIncome: null,
        };
        break;
      }

      case "cash_flow": {
        const inflows = await db
          .select({
            category: transactions.categoryName,
            total: sql<string>`SUM(amount)`,
          })
          .from(transactions)
          .where(
            and(
              eq(transactions.type, "income"),
              gte(transactions.transactionDate, start),
              lte(transactions.transactionDate, end)
            )
          )
          .groupBy(transactions.categoryName);

        const outflows = await db
          .select({
            category: transactions.categoryName,
            total: sql<string>`SUM(amount)`,
          })
          .from(transactions)
          .where(
            and(
              eq(transactions.type, "expense"),
              gte(transactions.transactionDate, start),
              lte(transactions.transactionDate, end)
            )
          )
          .groupBy(transactions.categoryName);

        const totalIn = inflows.reduce((s, r) => s + parseFloat(r.total || "0"), 0);
        const totalOut = outflows.reduce((s, r) => s + parseFloat(r.total || "0"), 0);

        reportData = {
          title: "Cash Flow Statement",
          period: `${start} to ${end}`,
          sections: [
            {
              heading: "Cash Inflows",
              rows: inflows.map((r) => ({ label: r.category, amount: parseFloat(r.total || "0") })),
              total: totalIn,
            },
            {
              heading: "Cash Outflows",
              rows: outflows.map((r) => ({ label: r.category, amount: parseFloat(r.total || "0") })),
              total: totalOut,
            },
          ],
          netIncome: totalIn - totalOut,
        };
        break;
      }

      case "budget_vs_actual": {
        const expByCat = await db
          .select({
            category: transactions.categoryName,
            total: sql<string>`SUM(amount)`,
            count: sql<number>`count(*)::int`,
          })
          .from(transactions)
          .where(
            and(
              eq(transactions.type, "expense"),
              gte(transactions.transactionDate, start),
              lte(transactions.transactionDate, end)
            )
          )
          .groupBy(transactions.categoryName);

        reportData = {
          title: "Budget vs Actual",
          period: `${start} to ${end}`,
          sections: [
            {
              heading: "Expense Categories (Actual Spend)",
              rows: expByCat.map((r) => ({
                label: r.category,
                amount: parseFloat(r.total || "0"),
                count: r.count,
              })),
              total: expByCat.reduce((s, r) => s + parseFloat(r.total || "0"), 0),
            },
          ],
          netIncome: null,
        };
        break;
      }

      /* =============== ACADEMIC =============== */
      case "student_performance": {
        const results = await db
          .select({
            studentId: students.studentId,
            firstName: students.firstName,
            lastName: students.lastName,
            avgScore: sql<string>`COALESCE(AVG(${grades.totalScore}),0)`,
            subjectCount: sql<number>`count(${grades.id})::int`,
          })
          .from(students)
          .leftJoin(grades, eq(students.id, grades.studentId))
          .groupBy(students.id, students.studentId, students.firstName, students.lastName)
          .orderBy(sql`AVG(${grades.totalScore}) DESC NULLS LAST`)
          .limit(50);

        reportData = {
          title: "Student Performance",
          period: `${start} to ${end}`,
          sections: [
            {
              heading: "Student Average Scores",
              rows: results.map((r) => ({
                label: `${r.firstName} ${r.lastName} (${r.studentId})`,
                amount: parseFloat(parseFloat(r.avgScore).toFixed(1)),
                count: r.subjectCount,
                extra: r.subjectCount > 0 ? `${r.subjectCount} subjects` : "No grades yet",
              })),
              total: null,
            },
          ],
          netIncome: null,
        };
        break;
      }

      case "class_reports": {
        const classData = await db
          .select({
            className: classes.name,
            studentCount: sql<number>`count(DISTINCT ${students.id})::int`,
          })
          .from(classes)
          .leftJoin(students, eq(classes.id, students.classId))
          .groupBy(classes.id, classes.name)
          .orderBy(classes.name);

        reportData = {
          title: "Class Reports",
          period: `${start} to ${end}`,
          sections: [
            {
              heading: "Class Enrollment Summary",
              rows: classData.map((r) => ({
                label: r.className,
                amount: r.studentCount,
                extra: `${r.studentCount} students`,
              })),
              total: classData.reduce((s, r) => s + r.studentCount, 0),
            },
          ],
          netIncome: null,
        };
        break;
      }

      case "attendance_analysis": {
        const attData = await db
          .select({
            status: attendance.status,
            count: sql<number>`count(*)::int`,
          })
          .from(attendance)
          .where(
            and(
              gte(attendance.date, start),
              lte(attendance.date, end)
            )
          )
          .groupBy(attendance.status);

        const totalAtt = attData.reduce((s, r) => s + r.count, 0);

        reportData = {
          title: "Attendance Analysis",
          period: `${start} to ${end}`,
          sections: [
            {
              heading: "Attendance Breakdown",
              rows: attData.map((r) => ({
                label: r.status.charAt(0).toUpperCase() + r.status.slice(1),
                amount: r.count,
                extra: totalAtt > 0 ? `${((r.count / totalAtt) * 100).toFixed(1)}%` : "0%",
              })),
              total: totalAtt,
            },
          ],
          netIncome: null,
        };
        break;
      }

      case "enrollment_trends": {
        const [totalActive] = await db
          .select({ count: sql<number>`count(*)::int` })
          .from(students)
          .where(eq(students.status, "active"));
        const [totalInactive] = await db
          .select({ count: sql<number>`count(*)::int` })
          .from(students)
          .where(eq(students.status, "inactive"));
        const [totalSuspended] = await db
          .select({ count: sql<number>`count(*)::int` })
          .from(students)
          .where(eq(students.status, "suspended"));

        const byClass = await db
          .select({
            className: classes.name,
            count: sql<number>`count(${students.id})::int`,
          })
          .from(classes)
          .leftJoin(students, and(eq(classes.id, students.classId), eq(students.status, "active")))
          .groupBy(classes.id, classes.name)
          .orderBy(classes.name);

        reportData = {
          title: "Enrollment Trends",
          period: `As at ${end}`,
          sections: [
            {
              heading: "Enrollment by Status",
              rows: [
                { label: "Active Students", amount: totalActive.count },
                { label: "Inactive Students", amount: totalInactive.count },
                { label: "Suspended Students", amount: totalSuspended.count },
              ],
              total: totalActive.count + totalInactive.count + totalSuspended.count,
            },
            {
              heading: "Active Students by Class",
              rows: byClass.map((r) => ({ label: r.className, amount: r.count })),
              total: totalActive.count,
            },
          ],
          netIncome: null,
        };
        break;
      }

      case "payroll_summary": {
        const payrollData = await db
          .select({
            payPeriod: payroll.payPeriod,
            totalBasic: sql<string>`SUM(basic_salary)`,
            totalAllowances: sql<string>`SUM(allowances)`,
            totalSsnit: sql<string>`SUM(ssnit_deduction)`,
            totalPaye: sql<string>`SUM(paye_deduction)`,
            totalNet: sql<string>`SUM(net_pay)`,
            staffCount: sql<number>`count(*)::int`,
          })
          .from(payroll)
          .groupBy(payroll.payPeriod)
          .orderBy(desc(payroll.payPeriod))
          .limit(12);

        const [staffTotal] = await db
          .select({ count: sql<number>`count(*)::int` })
          .from(staff)
          .where(eq(staff.status, "active"));

        reportData = {
          title: "Payroll Summary",
          period: `${start} to ${end}`,
          sections: [
            {
              heading: `Payroll by Period (${staffTotal.count} active staff)`,
              rows: payrollData.length > 0
                ? payrollData.map((r) => ({
                    label: r.payPeriod,
                    amount: parseFloat(r.totalNet || "0"),
                    extra: `${r.staffCount} staff | Basic: GHS ${parseFloat(r.totalBasic || "0").toLocaleString()} | Deductions: GHS ${(parseFloat(r.totalSsnit || "0") + parseFloat(r.totalPaye || "0")).toLocaleString()}`,
                  }))
                : [{ label: "No payroll records found", amount: 0 }],
              total: payrollData.reduce((s, r) => s + parseFloat(r.totalNet || "0"), 0),
            },
          ],
          netIncome: null,
        };
        break;
      }

      /* ---- fallback ---- */
      default: {
        // financial_summary (original)
        const [inc] = await db
          .select({ total: sql<string>`COALESCE(SUM(amount),0)` })
          .from(transactions)
          .where(
            and(
              eq(transactions.type, "income"),
              gte(transactions.transactionDate, start),
              lte(transactions.transactionDate, end)
            )
          );
        const [exp] = await db
          .select({ total: sql<string>`COALESCE(SUM(amount),0)` })
          .from(transactions)
          .where(
            and(
              eq(transactions.type, "expense"),
              gte(transactions.transactionDate, start),
              lte(transactions.transactionDate, end)
            )
          );
        const [stuCount] = await db
          .select({ count: sql<number>`count(*)::int` })
          .from(students);
        const [staCount] = await db
          .select({ count: sql<number>`count(*)::int` })
          .from(staff);

        const totalI = parseFloat(inc.total);
        const totalE = parseFloat(exp.total);

        reportData = {
          title: "Financial Summary",
          period: `${start} to ${end}`,
          sections: [
            {
              heading: "Overview",
              rows: [
                { label: "Total Income", amount: totalI },
                { label: "Total Expenses", amount: totalE },
                { label: "Net Balance", amount: totalI - totalE },
                { label: "Total Students", amount: stuCount.count },
                { label: "Total Staff", amount: staCount.count },
              ],
              total: null,
            },
          ],
          netIncome: totalI - totalE,
        };
        break;
      }
    }

    return NextResponse.json(reportData);
  } catch (error) {
    console.error("Error generating report:", error);
    return NextResponse.json({ error: "Failed to generate report" }, { status: 500 });
  }
}
