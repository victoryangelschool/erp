import { NextResponse } from "next/server";
import QRCode from "qrcode";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const code = searchParams.get("code") || "";
    const qrDataUrl = await QRCode.toDataURL(code, {
      width: 200,
      margin: 1,
      color: { dark: "#000000", light: "#ffffff" },
    });
    return NextResponse.json({ qr: qrDataUrl });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to generate QR" }, { status: 500 });
  }
}
