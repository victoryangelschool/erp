import { NextResponse } from "next/server";
import { db } from "@/db";
import { signLog, students, staff } from "@/db/schema";
import { desc, and, eq, sql } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const dateFilter = searchParams.get("date") || new Date().toISOString().split("T")[0];
    const logs = await db
      .select()
      .from(signLog)
      .where(eq(signLog.date, dateFilter))
      .orderBy(desc(signLog.createdAt))
      .limit(200);
    return NextResponse.json(logs);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to fetch" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { code, action, method } = body;
    // code is a student ID (STU...) or staff ID (STF...)
    const now = new Date();
    const date = now.toISOString().split("T")[0];
    const time = now.toTimeString().slice(0, 5);

    let personType: string;
    let personId: number;
    let personCode: string = code;

    if (code.startsWith("STU")) {
      const [stu] = await db
        .select({ id: students.id, studentId: students.studentId })
        .from(students)
        .where(eq(students.studentId, code))
        .limit(1);
      if (!stu) return NextResponse.json({ error: "Student not found" }, { status: 404 });
      personType = "student";
      personId = stu.id;
      personCode = stu.studentId;
    } else if (code.startsWith("STF")) {
      const [stf] = await db
        .select({ id: staff.id, staffId: staff.staffId })
        .from(staff)
        .where(eq(staff.staffId, code))
        .limit(1);
      if (!stf) return NextResponse.json({ error: "Staff not found" }, { status: 404 });
      personType = "staff";
      personId = stf.id;
      personCode = stf.staffId;
    } else {
      return NextResponse.json({ error: "Invalid ID format" }, { status: 400 });
    }

    const [created] = await db
      .insert(signLog)
      .values({
        personType,
        personId,
        personCode,
        action,
        method: method || "id",
        date,
        time,
      })
      .returning();

    // Look up name for the response
    let name = "";
    if (personType === "student") {
      const [s] = await db.select({ firstName: students.firstName, lastName: students.lastName }).from(students).where(eq(students.id, personId));
      name = s ? `${s.firstName} ${s.lastName}` : "";
    } else {
      const [s] = await db.select({ firstName: staff.firstName, lastName: staff.lastName }).from(staff).where(eq(staff.id, personId));
      name = s ? `${s.firstName} ${s.lastName}` : "";
    }

    return NextResponse.json({ ...created, name }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to log" }, { status: 500 });
  }
}
