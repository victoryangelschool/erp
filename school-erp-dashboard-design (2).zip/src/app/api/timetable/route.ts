import { NextResponse } from "next/server";
import { db } from "@/db";
import { timetableEntries } from "@/db/schema";
import { asc } from "drizzle-orm";

export async function GET() {
  try {
    const all = await db
      .select()
      .from(timetableEntries)
      .orderBy(asc(timetableEntries.dayOfWeek), asc(timetableEntries.startTime));
    return NextResponse.json(all);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to fetch" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { classId, subjectId, teacherId, dayOfWeek, startTime, endTime, room, term, academicYear } = body;
    const [created] = await db
      .insert(timetableEntries)
      .values({
        classId: classId ? parseInt(classId) : null,
        subjectId: subjectId ? parseInt(subjectId) : null,
        teacherId: teacherId ? parseInt(teacherId) : null,
        dayOfWeek,
        startTime,
        endTime,
        room: room || null,
        term: term || null,
        academicYear: academicYear || null,
      })
      .returning();
    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to create" }, { status: 500 });
  }
}
