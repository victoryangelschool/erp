import { NextResponse } from "next/server";
import { db } from "@/db";
import { transactions, activities } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get("type");

    let allTransactions;

    if (type === "income" || type === "expense") {
      allTransactions = await db
        .select()
        .from(transactions)
        .where(eq(transactions.type, type))
        .orderBy(desc(transactions.createdAt))
        .limit(100);
    } else {
      allTransactions = await db
        .select()
        .from(transactions)
        .orderBy(desc(transactions.createdAt))
        .limit(100);
    }

    return NextResponse.json(allTransactions);
  } catch (error) {
    console.error("Error fetching transactions:", error);
    return NextResponse.json({ error: "Failed to fetch" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      type,
      categoryId,
      categoryName,
      amount,
      description,
      paymentMethod,
      paidTo,
      receivedFrom,
      transactionDate,
      term,
      academicYear,
      notes,
    } = body;

    if (!type || !categoryId || !amount) {
      return NextResponse.json(
        { error: "Type, category and amount are required" },
        { status: 400 }
      );
    }

    // Generate reference
    const prefix = type === "income" ? "INC" : "EXP";
    const ref = `${prefix}-${Date.now().toString().slice(-8)}`;

    const [txn] = await db
      .insert(transactions)
      .values({
        type,
        categoryId: parseInt(categoryId),
        categoryName,
        amount: amount.toString(),
        description: description || null,
        reference: ref,
        paymentMethod: paymentMethod || null,
        paidTo: paidTo || null,
        receivedFrom: receivedFrom || null,
        transactionDate: transactionDate || new Date().toISOString().split("T")[0],
        term: term || null,
        academicYear: academicYear || null,
        notes: notes || null,
      })
      .returning();

    // Log activity
    const actTitle =
      type === "income"
        ? `Income received: GHS ${parseFloat(amount).toLocaleString()}`
        : `Expense paid: GHS ${parseFloat(amount).toLocaleString()}`;

    await db.insert(activities).values({
      type: "payment",
      title: actTitle,
      description: `${categoryName} – ${description || ""}`.trim(),
      entityType: "transaction",
      entityId: txn.id,
    });

    return NextResponse.json(txn, { status: 201 });
  } catch (error) {
    console.error("Error creating transaction:", error);
    return NextResponse.json({ error: "Failed to create" }, { status: 500 });
  }
}
