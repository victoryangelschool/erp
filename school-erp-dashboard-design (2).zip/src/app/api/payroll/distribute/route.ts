import { NextResponse } from "next/server";
import { db } from "@/db";
import { payroll, staffLoans, activities } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { payPeriod } = body;

    // Get all pending payroll for this period
    const pending = await db.select().from(payroll)
      .where(and(eq(payroll.payPeriod, payPeriod), eq(payroll.status, "pending")));

    if (pending.length === 0) {
      return NextResponse.json({ error: "No pending payroll for this period" }, { status: 400 });
    }

    const today = new Date().toISOString().split("T")[0];
    let count = 0;

    for (const record of pending) {
      // Mark as paid
      await db.update(payroll).set({
        status: "paid",
        paymentDate: today,
      }).where(eq(payroll.id, record.id));

      // Update loan balances
      const loanDed = parseFloat(record.loanDeduction || "0");
      if (loanDed > 0) {
        const activeLoans = await db.select().from(staffLoans)
          .where(and(eq(staffLoans.staffId, record.staffId), eq(staffLoans.isActive, true)));

        let remaining = loanDed;
        for (const loan of activeLoans) {
          if (remaining <= 0) break;
          const balance = parseFloat(loan.balance);
          const monthly = parseFloat(loan.monthlyDeduction);
          const ded = Math.min(monthly, balance, remaining);

          const newBalance = Math.round((balance - ded) * 100) / 100;
          const newRepaid = Math.round((parseFloat(loan.totalRepaid || "0") + ded) * 100) / 100;

          await db.update(staffLoans).set({
            balance: newBalance.toString(),
            totalRepaid: newRepaid.toString(),
            isActive: newBalance > 0,
          }).where(eq(staffLoans.id, loan.id));

          remaining -= ded;
        }
      }
      count++;
    }

    await db.insert(activities).values({
      type: "payroll",
      title: "Payments distributed",
      description: `${count} staff payments for ${payPeriod} distributed`,
      entityType: "payroll",
    });

    return NextResponse.json({ message: `${count} payments distributed`, count });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
