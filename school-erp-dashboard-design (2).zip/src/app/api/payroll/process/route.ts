import { NextResponse } from "next/server";
import { db } from "@/db";
import { payroll, staff, staffLoans, activities } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { payPeriod } = body;

    const activeStaff = await db.select().from(staff).where(eq(staff.status, "active"));
    let count = 0;

    for (const m of activeStaff) {
      const basic = parseFloat(m.basicSalary || "0");

      // Default allowances: 0 (can be edited individually later)
      const transport = 0, health = 0, rent = 0, responsibility = 0, overtime = 0, feeding = 0;
      const totalAllowances = transport + health + rent + responsibility + overtime + feeding;
      const gross = basic + totalAllowances;

      // SSNIT: 5.5% employee
      const ssnit = Math.round(basic * 0.055 * 100) / 100;

      // PAYE (Ghana simplified monthly)
      let paye = 0;
      const taxable = gross - ssnit;
      if (taxable > 4380) paye = (taxable - 4380) * 0.25 + (4380 - 2190) * 0.15 + (2190 - 1095) * 0.05;
      else if (taxable > 2190) paye = (taxable - 2190) * 0.15 + (2190 - 1095) * 0.05;
      else if (taxable > 1095) paye = (taxable - 1095) * 0.05;
      paye = Math.round(paye * 100) / 100;

      // Loan deduction
      const activeLoans = await db.select().from(staffLoans)
        .where(and(eq(staffLoans.staffId, m.id), eq(staffLoans.isActive, true)));
      let loanDed = 0;
      for (const loan of activeLoans) {
        const balance = parseFloat(loan.balance);
        const monthly = parseFloat(loan.monthlyDeduction);
        if (balance > 0) {
          const ded = Math.min(monthly, balance);
          loanDed += ded;
        }
      }
      loanDed = Math.round(loanDed * 100) / 100;

      const totalDeductions = ssnit + paye + loanDed;
      const net = Math.round((gross - totalDeductions) * 100) / 100;

      await db.insert(payroll).values({
        staffId: m.id,
        payPeriod,
        basicSalary: basic.toString(),
        transportAllowance: transport.toString(),
        healthAllowance: health.toString(),
        rentAllowance: rent.toString(),
        responsibilityAllowance: responsibility.toString(),
        overtimeAllowance: overtime.toString(),
        feedingAllowance: feeding.toString(),
        totalAllowances: totalAllowances.toString(),
        grossPay: gross.toString(),
        ssnitDeduction: ssnit.toString(),
        payeDeduction: paye.toString(),
        loanDeduction: loanDed.toString(),
        otherDeductions: "0",
        totalDeductions: totalDeductions.toString(),
        netPay: net.toString(),
        status: "pending",
      });
      count++;
    }

    await db.insert(activities).values({
      type: "payroll",
      title: "Payroll processed",
      description: `${payPeriod} processed for ${count} staff`,
      entityType: "payroll",
    });

    return NextResponse.json({ message: "Payroll processed", count }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
