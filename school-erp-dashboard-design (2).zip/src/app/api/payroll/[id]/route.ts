import { NextResponse } from "next/server";
import { db } from "@/db";
import { payroll } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const transport = parseFloat(body.transportAllowance) || 0;
    const health = parseFloat(body.healthAllowance) || 0;
    const rent = parseFloat(body.rentAllowance) || 0;
    const responsibility = parseFloat(body.responsibilityAllowance) || 0;
    const overtime = parseFloat(body.overtimeAllowance) || 0;
    const feeding = parseFloat(body.feedingAllowance) || 0;
    const totalAllowances = transport + health + rent + responsibility + overtime + feeding;

    const basic = parseFloat(body.basicSalary) || 0;
    const gross = basic + totalAllowances;

    const ssnit = parseFloat(body.ssnitDeduction) || 0;
    const paye = parseFloat(body.payeDeduction) || 0;
    const loan = parseFloat(body.loanDeduction) || 0;
    const other = parseFloat(body.otherDeductions) || 0;
    const totalDeductions = ssnit + paye + loan + other;
    const net = Math.round((gross - totalDeductions) * 100) / 100;

    const [updated] = await db.update(payroll).set({
      basicSalary: basic.toString(),
      transportAllowance: transport.toString(),
      healthAllowance: health.toString(),
      rentAllowance: rent.toString(),
      responsibilityAllowance: responsibility.toString(),
      overtimeAllowance: overtime.toString(),
      feedingAllowance: feeding.toString(),
      totalAllowances: totalAllowances.toString(),
      grossPay: gross.toString(),
      ssnitDeduction: ssnit.toString(),
      payeDeduction: paye.toString(),
      loanDeduction: loan.toString(),
      otherDeductions: other.toString(),
      totalDeductions: totalDeductions.toString(),
      netPay: net.toString(),
      status: body.status || "pending",
    }).where(eq(payroll.id, parseInt(id))).returning();

    if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json(updated);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
