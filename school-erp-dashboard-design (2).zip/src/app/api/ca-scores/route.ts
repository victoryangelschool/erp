import { NextResponse } from "next/server";
import { db } from "@/db";
import { caScores } from "@/db/schema";
import { desc, and, eq } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const term = searchParams.get("term");
    const academicYear = searchParams.get("academicYear");
    const classId = searchParams.get("classId");
    const subjectId = searchParams.get("subjectId");

    const conditions = [];
    if (term) conditions.push(eq(caScores.term, term));
    if (academicYear) conditions.push(eq(caScores.academicYear, academicYear));
    if (classId) conditions.push(eq(caScores.classId, parseInt(classId)));
    if (subjectId) conditions.push(eq(caScores.subjectId, parseInt(subjectId)));

    let results;
    if (conditions.length > 0) {
      results = await db
        .select()
        .from(caScores)
        .where(and(...conditions))
        .orderBy(desc(caScores.createdAt));
    } else {
      results = await db.select().from(caScores).orderBy(desc(caScores.createdAt)).limit(200);
    }

    return NextResponse.json(results);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to fetch" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      studentId,
      subjectId,
      classId,
      assessmentTitle,
      assessmentType,
      scoreObtained,
      totalMarks,
      date,
      term,
      academicYear,
      notes,
    } = body;

    const [created] = await db
      .insert(caScores)
      .values({
        studentId: parseInt(studentId),
        subjectId: parseInt(subjectId),
        classId: classId ? parseInt(classId) : null,
        assessmentTitle,
        assessmentType,
        scoreObtained: scoreObtained.toString(),
        totalMarks: totalMarks.toString(),
        date: date || null,
        term,
        academicYear,
        notes: notes || null,
      })
      .returning();

    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to create" }, { status: 500 });
  }
}
