import { NextResponse } from "next/server";
import { db } from "@/db";
import { caScores, grades } from "@/db/schema";
import { sql, and, eq } from "drizzle-orm";

// GET — return aggregated CA summaries per student+subject
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const term = searchParams.get("term") || "First Term";
    const academicYear = searchParams.get("academicYear") || "2025/2026";
    const classId = searchParams.get("classId");

    const conditions = [
      eq(caScores.term, term),
      eq(caScores.academicYear, academicYear),
    ];
    if (classId) conditions.push(eq(caScores.classId, parseInt(classId)));

    const summaries = await db
      .select({
        studentId: caScores.studentId,
        subjectId: caScores.subjectId,
        totalObtained: sql<string>`SUM(${caScores.scoreObtained})`,
        totalPossible: sql<string>`SUM(${caScores.totalMarks})`,
        assessmentCount: sql<number>`count(*)::int`,
      })
      .from(caScores)
      .where(and(...conditions))
      .groupBy(caScores.studentId, caScores.subjectId);

    return NextResponse.json(summaries);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to fetch" }, { status: 500 });
  }
}

// POST — import CA totals as class score into the grades table
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { term, academicYear, scoreWeight, classId } = body;

    const weight = scoreWeight || "30:70";
    const classWeightPct = parseInt(weight.split(":")[0]); // e.g. 30

    const conditions = [
      eq(caScores.term, term),
      eq(caScores.academicYear, academicYear),
    ];
    if (classId) conditions.push(eq(caScores.classId, parseInt(classId)));

    // Aggregate CA scores
    const summaries = await db
      .select({
        studentId: caScores.studentId,
        subjectId: caScores.subjectId,
        totalObtained: sql<string>`SUM(${caScores.scoreObtained})`,
        totalPossible: sql<string>`SUM(${caScores.totalMarks})`,
      })
      .from(caScores)
      .where(and(...conditions))
      .groupBy(caScores.studentId, caScores.subjectId);

    if (summaries.length === 0) {
      return NextResponse.json(
        { error: "No CA scores found for this term/year" },
        { status: 400 }
      );
    }

    let imported = 0;
    let skipped = 0;

    for (const row of summaries) {
      const obtained = parseFloat(row.totalObtained);
      const possible = parseFloat(row.totalPossible);
      // Scale to classWeightPct (e.g. 30)
      const scaledClassScore =
        possible > 0
          ? Math.round((obtained / possible) * classWeightPct * 100) / 100
          : 0;

      // Check if a grade already exists for this student+subject+term+year
      const [existing] = await db
        .select({ id: grades.id })
        .from(grades)
        .where(
          and(
            eq(grades.studentId, row.studentId),
            eq(grades.subjectId, row.subjectId),
            eq(grades.term, term),
            eq(grades.academicYear, academicYear)
          )
        )
        .limit(1);

      if (existing) {
        // Update existing grade's classScore
        await db
          .update(grades)
          .set({
            classScore: scaledClassScore.toString(),
            scoreWeight: weight,
            // Recalculate total if examScore exists
            totalScore: sql`${scaledClassScore} + COALESCE(${grades.examScore}, 0)`,
          })
          .where(eq(grades.id, existing.id));
        imported++;
      } else {
        // Insert new grade record with only classScore (exam score to be filled later)
        await db.insert(grades).values({
          studentId: row.studentId,
          subjectId: row.subjectId,
          term,
          academicYear,
          classScore: scaledClassScore.toString(),
          examScore: "0",
          totalScore: scaledClassScore.toString(),
          grade: computeGrade(scaledClassScore).grade,
          remarks: computeGrade(scaledClassScore).remarks,
          scoreWeight: weight,
        });
        imported++;
      }
    }

    return NextResponse.json({
      message: `Imported ${imported} class scores, ${skipped} skipped`,
      imported,
      skipped,
    });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to import" }, { status: 500 });
  }
}

function computeGrade(score: number): { grade: string; remarks: string } {
  if (score >= 80) return { grade: "A1", remarks: "Excellent" };
  if (score >= 70) return { grade: "B2", remarks: "Very Good" };
  if (score >= 65) return { grade: "B3", remarks: "Good" };
  if (score >= 60) return { grade: "C4", remarks: "Credit" };
  if (score >= 55) return { grade: "C5", remarks: "Credit" };
  if (score >= 50) return { grade: "C6", remarks: "Credit" };
  if (score >= 45) return { grade: "D7", remarks: "Pass" };
  if (score >= 40) return { grade: "E8", remarks: "Pass" };
  return { grade: "F9", remarks: "Fail" };
}
