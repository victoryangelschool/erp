import { NextResponse } from "next/server";
import { db } from "@/db";
import { assets } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { name, category, photoUrl, purchaseDate, purchaseCost, depreciation, currentValue, location, status } = body;

    const [updated] = await db.update(assets).set({
      name,
      category: category || null,
      photoUrl: photoUrl !== undefined ? photoUrl : undefined,
      purchaseDate: purchaseDate || null,
      purchaseCost: purchaseCost ? purchaseCost.toString() : null,
      depreciation: depreciation ? depreciation.toString() : "0",
      currentValue: currentValue ? currentValue.toString() : null,
      location: location || null,
      status: status || "operational",
      updatedAt: new Date(),
    }).where(eq(assets.id, parseInt(id))).returning();

    if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json(updated);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to update" }, { status: 500 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const [deleted] = await db.delete(assets).where(eq(assets.id, parseInt(id))).returning();
    if (!deleted) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to delete" }, { status: 500 });
  }
}
