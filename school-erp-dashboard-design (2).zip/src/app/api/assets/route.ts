import { NextResponse } from "next/server";
import { db } from "@/db";
import { assets } from "@/db/schema";
import { desc, sql } from "drizzle-orm";

export async function GET() {
  try {
    const all = await db.select().from(assets).orderBy(desc(assets.createdAt));
    return NextResponse.json(all);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to fetch" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, category, photoUrl, purchaseDate, purchaseCost, depreciation, currentValue, location, status } = body;

    const [countResult] = await db.select({ count: sql<number>`count(*)::int` }).from(assets);
    const num = (countResult.count || 0) + 1;
    const assetId = `AST${String(num).padStart(3, "0")}`;

    const [created] = await db.insert(assets).values({
      assetId,
      name,
      category: category || null,
      photoUrl: photoUrl || null,
      purchaseDate: purchaseDate || null,
      purchaseCost: purchaseCost ? purchaseCost.toString() : null,
      depreciation: depreciation ? depreciation.toString() : "0",
      currentValue: currentValue ? currentValue.toString() : null,
      location: location || null,
      status: status || "operational",
    }).returning();

    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to create" }, { status: 500 });
  }
}
