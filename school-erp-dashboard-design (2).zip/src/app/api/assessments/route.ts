import { NextResponse } from "next/server";
import { db } from "@/db";
import { assessments } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const all = await db.select().from(assessments).orderBy(desc(assessments.createdAt));
    return NextResponse.json(all);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to fetch" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { title, type, subjectId, classId, totalMarks, date, term, academicYear, description } = body;
    const [created] = await db
      .insert(assessments)
      .values({
        title,
        type,
        subjectId: subjectId ? parseInt(subjectId) : null,
        classId: classId ? parseInt(classId) : null,
        totalMarks: totalMarks ? parseInt(totalMarks) : 100,
        date: date || null,
        term: term || null,
        academicYear: academicYear || null,
        description: description || null,
      })
      .returning();
    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to create" }, { status: 500 });
  }
}
