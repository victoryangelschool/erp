import { NextResponse } from "next/server";
import { db } from "@/db";
import { studentBills, studentBillItems, studentBillPayments, students } from "@/db/schema";
import { desc, eq, and, sql } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const term = searchParams.get("term");
    const year = searchParams.get("academicYear");
    const studentId = searchParams.get("studentId");

    const conditions = [];
    if (term) conditions.push(eq(studentBills.term, term));
    if (year) conditions.push(eq(studentBills.academicYear, year));
    if (studentId) conditions.push(eq(studentBills.studentId, parseInt(studentId)));

    let bills;
    if (conditions.length > 0) {
      bills = await db.select().from(studentBills).where(and(...conditions)).orderBy(desc(studentBills.createdAt));
    } else {
      bills = await db.select().from(studentBills).orderBy(desc(studentBills.createdAt)).limit(300);
    }

    const result = [];
    for (const bill of bills) {
      const items = await db.select().from(studentBillItems).where(eq(studentBillItems.billId, bill.id));
      const payments = await db.select().from(studentBillPayments).where(eq(studentBillPayments.billId, bill.id)).orderBy(desc(studentBillPayments.createdAt));
      result.push({ ...bill, items, payments });
    }

    return NextResponse.json(result);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { scope, studentId, classId, term, academicYear, items } = body;
    // scope: "student" | "class" | "school"
    // items: Array<{ description: string, amount: string }>

    if (!items || items.length === 0) return NextResponse.json({ error: "At least one bill item is required" }, { status: 400 });

    const totalAmount = items.reduce((s: number, i: { amount: string }) => s + parseFloat(i.amount), 0);

    // Determine which students to bill
    let targetStudents: { id: number }[];

    if (scope === "student") {
      if (!studentId) return NextResponse.json({ error: "Student is required" }, { status: 400 });
      targetStudents = [{ id: parseInt(studentId) }];
    } else if (scope === "class") {
      if (!classId) return NextResponse.json({ error: "Class is required" }, { status: 400 });
      targetStudents = await db.select({ id: students.id }).from(students)
        .where(and(eq(students.classId, parseInt(classId)), eq(students.status, "active")));
    } else {
      // whole school
      targetStudents = await db.select({ id: students.id }).from(students).where(eq(students.status, "active"));
    }

    if (targetStudents.length === 0) return NextResponse.json({ error: "No students found in this scope" }, { status: 400 });

    let created = 0;
    const timestamp = Date.now().toString().slice(-6);

    for (const target of targetStudents) {
      // Check if bill already exists for this student + term + year
      const [existing] = await db.select({ id: studentBills.id }).from(studentBills)
        .where(and(
          eq(studentBills.studentId, target.id),
          eq(studentBills.term, term),
          eq(studentBills.academicYear, academicYear)
        )).limit(1);

      if (existing) continue; // skip — already billed

      const billNumber = `BILL-${timestamp}${String(created + 1).padStart(3, "0")}`;

      const [bill] = await db.insert(studentBills).values({
        billNumber, studentId: target.id, term, academicYear,
        totalAmount: totalAmount.toString(), amountPaid: "0",
        balance: totalAmount.toString(), status: "unpaid",
      }).returning();

      for (const item of items) {
        await db.insert(studentBillItems).values({
          billId: bill.id, description: item.description, amount: item.amount.toString(),
        });
      }

      created++;
    }

    return NextResponse.json({
      message: `${created} bill(s) created. ${targetStudents.length - created} skipped (already billed).`,
      created,
      skipped: targetStudents.length - created,
    }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
