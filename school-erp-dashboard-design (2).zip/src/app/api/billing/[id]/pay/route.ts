import { NextResponse } from "next/server";
import { db } from "@/db";
import { studentBills, studentBillPayments } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { amount, paymentMethod, receivedBy } = body;

    const [bill] = await db.select().from(studentBills).where(eq(studentBills.id, parseInt(id)));
    if (!bill) return NextResponse.json({ error: "Bill not found" }, { status: 404 });

    const payAmt = parseFloat(amount);
    const newPaid = parseFloat(bill.amountPaid || "0") + payAmt;
    const newBalance = parseFloat(bill.totalAmount) - newPaid;
    const receiptNumber = `RCP-${Date.now().toString().slice(-8)}`;

    const [payment] = await db.insert(studentBillPayments).values({
      billId: bill.id, amount: payAmt.toString(), paymentMethod: paymentMethod || "cash",
      receiptNumber, receivedBy: receivedBy || null,
    }).returning();

    const status = newBalance <= 0 ? "paid" : newPaid > 0 ? "partial" : "unpaid";
    await db.update(studentBills).set({
      amountPaid: newPaid.toString(), balance: Math.max(0, newBalance).toString(), status,
    }).where(eq(studentBills.id, bill.id));

    return NextResponse.json({ payment, billStatus: status, amountPaid: newPaid, balance: Math.max(0, newBalance) });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
