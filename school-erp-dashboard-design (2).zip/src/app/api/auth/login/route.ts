import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { createHash } from "crypto";

function hashPassword(password: string) {
  return createHash("sha256").update(password).digest("hex");
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { username, password } = body;

    const [user] = await db.select().from(users).where(
      and(eq(users.username, username), eq(users.isActive, true))
    );

    if (!user || user.passwordHash !== hashPassword(password)) {
      return NextResponse.json({ error: "Invalid username or password" }, { status: 401 });
    }

    // Return user info (no JWT — using simple session via cookie)
    const res = NextResponse.json({
      id: user.id, username: user.username, role: user.role,
      fullName: user.fullName, staffId: user.staffId, classId: user.classId,
    });

    // Set a simple session cookie
    res.cookies.set("erp_user", JSON.stringify({
      id: user.id, username: user.username, role: user.role,
      fullName: user.fullName, staffId: user.staffId, classId: user.classId,
    }), { httpOnly: false, path: "/", maxAge: 86400 });

    return res;
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Login failed" }, { status: 500 });
  }
}
