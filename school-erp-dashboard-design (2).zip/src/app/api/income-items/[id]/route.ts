import { NextResponse } from "next/server";
import { db } from "@/db";
import { incomeItems } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const [deleted] = await db
      .delete(incomeItems)
      .where(eq(incomeItems.id, parseInt(id)))
      .returning();

    if (!deleted) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting income item:", error);
    return NextResponse.json({ error: "Failed to delete" }, { status: 500 });
  }
}
