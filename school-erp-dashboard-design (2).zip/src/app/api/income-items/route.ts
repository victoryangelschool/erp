import { NextResponse } from "next/server";
import { db } from "@/db";
import { incomeItems } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const items = await db
      .select()
      .from(incomeItems)
      .where(eq(incomeItems.isActive, true))
      .orderBy(asc(incomeItems.name));
    return NextResponse.json(items);
  } catch (error) {
    console.error("Error fetching income items:", error);
    return NextResponse.json({ error: "Failed to fetch" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, description } = body;

    if (!name?.trim()) {
      return NextResponse.json({ error: "Name is required" }, { status: 400 });
    }

    const [item] = await db
      .insert(incomeItems)
      .values({ name: name.trim(), description: description?.trim() || null })
      .returning();

    return NextResponse.json(item, { status: 201 });
  } catch (error) {
    console.error("Error creating income item:", error);
    return NextResponse.json({ error: "Failed to create" }, { status: 500 });
  }
}
