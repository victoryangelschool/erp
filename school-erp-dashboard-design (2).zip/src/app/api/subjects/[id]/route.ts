import { NextResponse } from "next/server";
import { db } from "@/db";
import { subjects } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { name, code, description, classId } = body;

    const [updated] = await db
      .update(subjects)
      .set({
        name: name?.trim(),
        code: code?.trim() || null,
        description: description?.trim() || null,
        classId: classId ? parseInt(classId) : null,
      })
      .where(eq(subjects.id, parseInt(id)))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Subject not found" }, { status: 404 });
    }

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Error updating subject:", error);
    return NextResponse.json(
      { error: "Failed to update subject" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const [deleted] = await db
      .delete(subjects)
      .where(eq(subjects.id, parseInt(id)))
      .returning();

    if (!deleted) {
      return NextResponse.json({ error: "Subject not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting subject:", error);
    return NextResponse.json(
      { error: "Failed to delete subject. It may be referenced by grades." },
      { status: 500 }
    );
  }
}
