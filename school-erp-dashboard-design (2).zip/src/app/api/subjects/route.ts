import { NextResponse } from "next/server";
import { db } from "@/db";
import { subjects } from "@/db/schema";
import { asc } from "drizzle-orm";

export async function GET() {
  try {
    const allSubjects = await db
      .select()
      .from(subjects)
      .orderBy(asc(subjects.name));
    return NextResponse.json(allSubjects);
  } catch (error) {
    console.error("Error fetching subjects:", error);
    return NextResponse.json(
      { error: "Failed to fetch subjects" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, code, description, classId } = body;

    if (!name || !name.trim()) {
      return NextResponse.json(
        { error: "Subject name is required" },
        { status: 400 }
      );
    }

    const [newSubject] = await db
      .insert(subjects)
      .values({
        name: name.trim(),
        code: code?.trim() || null,
        description: description?.trim() || null,
        classId: classId ? parseInt(classId) : null,
      })
      .returning();

    return NextResponse.json(newSubject, { status: 201 });
  } catch (error) {
    console.error("Error creating subject:", error);
    return NextResponse.json(
      { error: "Failed to create subject" },
      { status: 500 }
    );
  }
}
