import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { asc } from "drizzle-orm";
import { createHash } from "crypto";

function hashPassword(password: string) {
  return createHash("sha256").update(password).digest("hex");
}

export async function GET() {
  try {
    const all = await db.select({
      id: users.id, username: users.username, role: users.role,
      fullName: users.fullName, staffId: users.staffId, classId: users.classId,
      isActive: users.isActive, createdAt: users.createdAt,
    }).from(users).orderBy(asc(users.username));
    return NextResponse.json(all);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { username, password, role, fullName, staffId, classId } = body;
    const [created] = await db.insert(users).values({
      username, passwordHash: hashPassword(password), role,
      fullName, staffId: staffId ? parseInt(staffId) : null,
      classId: classId ? parseInt(classId) : null, isActive: true,
    }).returning({
      id: users.id, username: users.username, role: users.role,
      fullName: users.fullName, staffId: users.staffId, classId: users.classId,
      isActive: users.isActive, createdAt: users.createdAt,
    });
    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed — username may already exist" }, { status: 500 });
  }
}
