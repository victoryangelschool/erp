import { NextResponse } from "next/server";
import { db } from "@/db";
import { grades } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const all = await db.select().from(grades).orderBy(desc(grades.createdAt)).limit(200);
    return NextResponse.json(all);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to fetch" }, { status: 500 });
  }
}

function computeGrade(score: number): { grade: string; remarks: string } {
  if (score >= 80) return { grade: "A1", remarks: "Excellent" };
  if (score >= 70) return { grade: "B2", remarks: "Very Good" };
  if (score >= 65) return { grade: "B3", remarks: "Good" };
  if (score >= 60) return { grade: "C4", remarks: "Credit" };
  if (score >= 55) return { grade: "C5", remarks: "Credit" };
  if (score >= 50) return { grade: "C6", remarks: "Credit" };
  if (score >= 45) return { grade: "D7", remarks: "Pass" };
  if (score >= 40) return { grade: "E8", remarks: "Pass" };
  return { grade: "F9", remarks: "Fail" };
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { studentId, subjectId, classScore, examScore, term, academicYear, scoreWeight } = body;

    const weight = scoreWeight || "30:70";
    const [classWeightPct, examWeightPct] = weight.split(":").map(Number); // e.g. 30, 70

    const rawClass = parseFloat(classScore) || 0;
    const rawExam = parseFloat(examScore) || 0;

    // The user enters the raw score out of the weight's max
    // e.g. for 30:70, classScore is out of 30, examScore is out of 70
    // Total is always out of 100
    const total = rawClass + rawExam;
    const { grade, remarks } = computeGrade(total);

    const [created] = await db
      .insert(grades)
      .values({
        studentId: parseInt(studentId),
        subjectId: parseInt(subjectId),
        classScore: rawClass.toString(),
        examScore: rawExam.toString(),
        totalScore: total.toString(),
        grade,
        remarks,
        term: term || null,
        academicYear: academicYear || null,
        scoreWeight: weight,
      })
      .returning();
    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to create" }, { status: 500 });
  }
}
