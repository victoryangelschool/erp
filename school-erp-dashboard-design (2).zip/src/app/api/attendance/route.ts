import { NextResponse } from "next/server";
import { db } from "@/db";
import { attendance } from "@/db/schema";

export async function GET() {
  try {
    const allAttendance = await db.select().from(attendance);
    return NextResponse.json(allAttendance);
  } catch (error) {
    console.error("Error fetching attendance:", error);
    return NextResponse.json(
      { error: "Failed to fetch attendance" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { date, studentId, status, timeIn } = body;

    const [newAttendance] = await db
      .insert(attendance)
      .values({
        date,
        studentId: studentId ? parseInt(studentId) : null,
        status,
        timeIn: timeIn || null,
      })
      .returning();

    return NextResponse.json(newAttendance, { status: 201 });
  } catch (error) {
    console.error("Error creating attendance:", error);
    return NextResponse.json(
      { error: "Failed to create attendance" },
      { status: 500 }
    );
  }
}
