import { NextResponse } from "next/server";
import { db } from "@/db";
import { schoolProfile } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function GET() {
  try {
    const [profile] = await db.select().from(schoolProfile).limit(1);
    return NextResponse.json(profile || {});
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, motto, phone, email, address, logoUrl, academicYear, currentTerm, currency } = body;

    const [existing] = await db.select().from(schoolProfile).limit(1);

    const data: Record<string, unknown> = {
      name, motto, phone, email, address, academicYear, currentTerm, currency, updatedAt: new Date(),
    };
    // Only update logoUrl if it was provided (not undefined)
    if (logoUrl !== undefined) data.logoUrl = logoUrl;

    if (existing) {
      const [updated] = await db.update(schoolProfile).set(data).where(sql`id = ${existing.id}`).returning();
      return NextResponse.json(updated);
    } else {
      const [created] = await db.insert(schoolProfile).values({
        name, motto, phone, email, address, logoUrl: logoUrl || null,
        academicYear, currentTerm, currency,
      }).returning();
      return NextResponse.json(created, { status: 201 });
    }
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
