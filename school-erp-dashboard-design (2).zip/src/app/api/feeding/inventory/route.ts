import { NextResponse } from "next/server";
import { db } from "@/db";
import { kitchenInventory } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const items = await db.select().from(kitchenInventory).orderBy(asc(kitchenInventory.itemName));
    return NextResponse.json(items);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { itemName, quantity, unit, reorderLevel } = body;
    const qty = parseFloat(quantity) || 0;
    const reorder = parseFloat(reorderLevel) || 5;
    let status: "in_stock" | "low_stock" | "out_of_stock" = "in_stock";
    if (qty <= 0) status = "out_of_stock";
    else if (qty <= reorder) status = "low_stock";

    const [created] = await db.insert(kitchenInventory).values({
      itemName, quantity: qty.toString(), unit: unit || null,
      reorderLevel: reorder.toString(), status,
    }).returning();
    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
