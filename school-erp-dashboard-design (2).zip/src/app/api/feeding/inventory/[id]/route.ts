import { NextResponse } from "next/server";
import { db } from "@/db";
import { kitchenInventory } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { itemName, quantity, unit, reorderLevel } = body;
    const qty = parseFloat(quantity) || 0;
    const reorder = parseFloat(reorderLevel) || 5;
    let status: "in_stock" | "low_stock" | "out_of_stock" = "in_stock";
    if (qty <= 0) status = "out_of_stock";
    else if (qty <= reorder) status = "low_stock";

    const [updated] = await db.update(kitchenInventory).set({
      itemName, quantity: qty.toString(), unit: unit || null,
      reorderLevel: reorder.toString(), status, updatedAt: new Date(),
    }).where(eq(kitchenInventory.id, parseInt(id))).returning();
    if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json(updated);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await db.delete(kitchenInventory).where(eq(kitchenInventory.id, parseInt(id)));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
