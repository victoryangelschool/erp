import { NextResponse } from "next/server";
import { db } from "@/db";
import { dailyRequestBatches, dailyRequestItems } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const date = searchParams.get("date");

    const batches = date
      ? await db.select().from(dailyRequestBatches).where(eq(dailyRequestBatches.date, date)).orderBy(desc(dailyRequestBatches.createdAt))
      : await db.select().from(dailyRequestBatches).orderBy(desc(dailyRequestBatches.createdAt)).limit(50);

    // Fetch items for each batch
    const result = [];
    for (const batch of batches) {
      const items = await db.select().from(dailyRequestItems).where(eq(dailyRequestItems.batchId, batch.id));
      result.push({ ...batch, items });
    }

    return NextResponse.json(result);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { date, requestedBy, purpose, items } = body;
    // items: Array<{ inventoryItemId, itemName, quantityRequested, unit }>

    if (!items || items.length === 0) {
      return NextResponse.json({ error: "At least one item is required" }, { status: 400 });
    }

    const [batch] = await db.insert(dailyRequestBatches).values({
      date, requestedBy: requestedBy || null, purpose: purpose || null, status: "pending",
    }).returning();

    const createdItems = [];
    for (const item of items) {
      const [created] = await db.insert(dailyRequestItems).values({
        batchId: batch.id,
        inventoryItemId: item.inventoryItemId ? parseInt(item.inventoryItemId) : null,
        itemName: item.itemName,
        quantityRequested: item.quantityRequested.toString(),
        unit: item.unit || null,
      }).returning();
      createdItems.push(created);
    }

    return NextResponse.json({ ...batch, items: createdItems }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
