import { NextResponse } from "next/server";
import { db } from "@/db";
import { dailyRequestBatches, dailyRequestItems, kitchenInventory } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { status } = body; // "approved" | "issued"

    const [batch] = await db.select().from(dailyRequestBatches).where(eq(dailyRequestBatches.id, parseInt(id)));
    if (!batch) return NextResponse.json({ error: "Not found" }, { status: 404 });

    // If issuing, deduct all items from kitchen inventory
    if (status === "issued" && batch.status !== "issued") {
      const items = await db.select().from(dailyRequestItems).where(eq(dailyRequestItems.batchId, batch.id));
      for (const item of items) {
        if (!item.inventoryItemId) continue;
        const [inv] = await db.select().from(kitchenInventory).where(eq(kitchenInventory.id, item.inventoryItemId));
        if (!inv) continue;
        const newQty = Math.max(0, parseFloat(inv.quantity) - parseFloat(item.quantityRequested));
        const reorder = parseFloat(inv.reorderLevel || "5");
        let invStatus: "in_stock" | "low_stock" | "out_of_stock" = "in_stock";
        if (newQty <= 0) invStatus = "out_of_stock";
        else if (newQty <= reorder) invStatus = "low_stock";
        await db.update(kitchenInventory).set({
          quantity: newQty.toString(), status: invStatus, updatedAt: new Date(),
        }).where(eq(kitchenInventory.id, inv.id));
      }
    }

    const [updated] = await db.update(dailyRequestBatches).set({ status }).where(eq(dailyRequestBatches.id, parseInt(id))).returning();
    const items = await db.select().from(dailyRequestItems).where(eq(dailyRequestItems.batchId, updated.id));
    return NextResponse.json({ ...updated, items });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await db.delete(dailyRequestItems).where(eq(dailyRequestItems.batchId, parseInt(id)));
    await db.delete(dailyRequestBatches).where(eq(dailyRequestBatches.id, parseInt(id)));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
