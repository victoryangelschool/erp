import { NextResponse } from "next/server";
import { db } from "@/db";
import { feedingMenu } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const date = searchParams.get("date");
    const items = date
      ? await db.select().from(feedingMenu).where(eq(feedingMenu.date, date)).orderBy(feedingMenu.mealType)
      : await db.select().from(feedingMenu).orderBy(desc(feedingMenu.date)).limit(50);
    return NextResponse.json(items);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { date, mealType, description, startTime, endTime } = body;
    const [created] = await db.insert(feedingMenu).values({
      date, mealType, description: description || null,
      startTime: startTime || null, endTime: endTime || null,
    }).returning();
    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
