import { NextResponse } from "next/server";
import { db } from "@/db";
import { classes, schoolProfile, users } from "@/db/schema";
import { sql } from "drizzle-orm";
import { createHash } from "crypto";

function hashPassword(password: string) {
  return createHash("sha256").update(password).digest("hex");
}

export async function POST() {
  try {
    // Check if already seeded
    const [existingClasses] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(classes);

    if (existingClasses.count > 0) {
      // Still ensure admin user exists
      const [existingAdmin] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(users);
      if (existingAdmin.count === 0) {
        await db.insert(users).values({
          username: "admin",
          passwordHash: hashPassword("admin123"),
          role: "admin",
          fullName: "System Administrator",
          isActive: true,
        });
        return NextResponse.json({ message: "Admin user created" });
      }
      return NextResponse.json({ message: "Already seeded" });
    }

    // Seed classes
    await db.insert(classes).values([
      { name: "JHS 1A", level: "Junior High School", capacity: 40 },
      { name: "JHS 1B", level: "Junior High School", capacity: 40 },
      { name: "JHS 2A", level: "Junior High School", capacity: 40 },
      { name: "JHS 2B", level: "Junior High School", capacity: 40 },
      { name: "JHS 3A", level: "Junior High School", capacity: 40 },
      { name: "JHS 3B", level: "Junior High School", capacity: 40 },
      { name: "Primary 1", level: "Primary", capacity: 35 },
      { name: "Primary 2", level: "Primary", capacity: 35 },
      { name: "Primary 3", level: "Primary", capacity: 35 },
      { name: "Primary 4", level: "Primary", capacity: 35 },
      { name: "Primary 5", level: "Primary", capacity: 35 },
      { name: "Primary 6", level: "Primary", capacity: 35 },
    ]);

    // Seed school profile
    const [existingProfile] = await db.select().from(schoolProfile).limit(1);
    if (!existingProfile) {
      await db.insert(schoolProfile).values({
        name: "Starlight Academy",
        motto: "Excellence, Integrity, Growth",
        phone: "+233 20 000 0000",
        email: "admin@starlight.edu.gh",
        address: "Accra, Ghana",
        academicYear: "2025/2026",
        currentTerm: "First Term",
        currency: "GHS",
      });
    }

    // Seed default admin user
    await db.insert(users).values({
      username: "admin",
      passwordHash: hashPassword("admin123"),
      role: "admin",
      fullName: "System Administrator",
      isActive: true,
    });

    return NextResponse.json({ message: "Seeded successfully with admin user (admin / admin123)" }, { status: 201 });
  } catch (error) {
    console.error("Error seeding database:", error);
    return NextResponse.json({ error: "Failed to seed database" }, { status: 500 });
  }
}
