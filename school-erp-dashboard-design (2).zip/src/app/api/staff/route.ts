import { NextResponse } from "next/server";
import { db } from "@/db";
import { staff, activities } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function GET() {
  try {
    const allStaff = await db.select().from(staff);
    return NextResponse.json(allStaff);
  } catch (error) {
    console.error("Error fetching staff:", error);
    return NextResponse.json({ error: "Failed to fetch staff" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      firstName, lastName, email, phone, position, department,
      qualification, yearsOfExperience, careerStatement,
      basicSalary, hireDate, photoUrl, taxId, ssnitNumber,
    } = body;

    const [countResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(staff);
    const staffNumber = (countResult.count || 0) + 1;
    const staffId = `STF${String(staffNumber).padStart(3, "0")}`;

    const [newStaff] = await db
      .insert(staff)
      .values({
        staffId,
        firstName,
        lastName,
        email: email || null,
        phone: phone || null,
        position,
        department: department || null,
        qualification: qualification || null,
        yearsOfExperience: yearsOfExperience ? parseInt(yearsOfExperience) : null,
        careerStatement: careerStatement || null,
        taxId: taxId || null,
        ssnitNumber: ssnitNumber || null,
        basicSalary: basicSalary ? basicSalary.toString() : "0",
        hireDate: hireDate || null,
        photoUrl: photoUrl || null,
        status: "active",
      })
      .returning();

    await db.insert(activities).values({
      type: "registration",
      title: "New staff member added",
      description: `${firstName} ${lastName} joined as ${position}`,
      entityType: "staff",
      entityId: newStaff.id,
    });

    return NextResponse.json(newStaff, { status: 201 });
  } catch (error) {
    console.error("Error creating staff:", error);
    return NextResponse.json({ error: "Failed to create staff" }, { status: 500 });
  }
}
