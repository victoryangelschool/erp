"use client";

import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";

export default function TrainingPage() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6 space-y-6">
          <section className="fade-up">
            <div className="mb-6">
              <h2 className="text-3xl font-bold">Training &amp; Documentation</h2>
              <p className="text-slate-400">Access the training manual and presentation for the School ERP System</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Training Manual */}
              <div className="module-card card rounded-3xl p-8 text-center">
                <div className="p-4 rounded-2xl bg-blue-500/20 text-blue-400 w-20 h-20 flex items-center justify-center mx-auto mb-5">
                  <i className="fas fa-book text-4xl"></i>
                </div>
                <h3 className="text-2xl font-bold">Training Manual</h3>
                <p className="text-slate-400 mt-2 mb-6">Comprehensive PDF document covering all modules, workflows, user roles, and best practices.</p>
                <p className="text-sm text-slate-500 mb-4">19 sections • Printable • Save as PDF</p>
                <a
                  href="/training-manual.html"
                  target="_blank"
                  className="btn inline-block px-6 py-3 rounded-xl bg-blue-500 hover:bg-blue-400 text-white font-semibold"
                >
                  <i className="fas fa-file-pdf mr-2"></i>Open Manual (PDF)
                </a>
                <p className="text-xs text-slate-500 mt-3">Opens in a new tab. Use Ctrl+P → "Save as PDF" to download.</p>
              </div>

              {/* Presentation */}
              <div className="module-card card rounded-3xl p-8 text-center">
                <div className="p-4 rounded-2xl bg-purple-500/20 text-purple-400 w-20 h-20 flex items-center justify-center mx-auto mb-5">
                  <i className="fas fa-presentation text-4xl"></i>
                </div>
                <h3 className="text-2xl font-bold">Training Presentation</h3>
                <p className="text-slate-400 mt-2 mb-6">11-slide interactive presentation for staff training sessions. Navigate with arrow keys or buttons.</p>
                <p className="text-sm text-slate-500 mb-4">11 slides • Interactive • Printable</p>
                <a
                  href="/training-presentation.html"
                  target="_blank"
                  className="btn inline-block px-6 py-3 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-semibold"
                >
                  <i className="fas fa-desktop mr-2"></i>Open Presentation (PPT)
                </a>
                <p className="text-xs text-slate-500 mt-3">Use arrow keys to navigate. Click "Print All" for handouts.</p>
              </div>
            </div>

            {/* Quick Reference */}
            <div className="card rounded-3xl p-6 mt-6">
              <h3 className="text-xl font-bold mb-4">Quick Reference — Getting Started</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <span className="w-7 h-7 rounded-full bg-sky-500 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">1</span>
                    <div><p className="font-semibold">Set up School Profile</p><p className="text-sm text-slate-400">Name, logo, motto, contact → School Profile</p></div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="w-7 h-7 rounded-full bg-sky-500 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">2</span>
                    <div><p className="font-semibold">Create Classes &amp; Subjects</p><p className="text-sm text-slate-400">Settings → Classes tab and Subjects tab</p></div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="w-7 h-7 rounded-full bg-sky-500 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">3</span>
                    <div><p className="font-semibold">Set up Income &amp; Expense Items</p><p className="text-sm text-slate-400">Settings → Income Items &amp; Expense Items tabs</p></div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="w-7 h-7 rounded-full bg-sky-500 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">4</span>
                    <div><p className="font-semibold">Register Staff &amp; Create User Accounts</p><p className="text-sm text-slate-400">Staff → Add Staff, then Settings → User Accounts</p></div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <span className="w-7 h-7 rounded-full bg-sky-500 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">5</span>
                    <div><p className="font-semibold">Register Students</p><p className="text-sm text-slate-400">Students → Add Student (with photos)</p></div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="w-7 h-7 rounded-full bg-sky-500 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">6</span>
                    <div><p className="font-semibold">Create Term Bills</p><p className="text-sm text-slate-400">Student Billing → Create Bill (school/class/student)</p></div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="w-7 h-7 rounded-full bg-sky-500 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">7</span>
                    <div><p className="font-semibold">Begin Daily Operations</p><p className="text-sm text-slate-400">Mark attendance, record CA scores, receive payments</p></div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="w-7 h-7 rounded-full bg-emerald-500 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">✓</span>
                    <div><p className="font-semibold text-emerald-400">You&apos;re all set!</p><p className="text-sm text-slate-400">Default login: admin / admin123</p></div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
