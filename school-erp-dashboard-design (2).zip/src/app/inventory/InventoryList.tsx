"use client";

import { useState } from "react";
import Modal from "@/components/Modal";

interface InventoryItem {
  id: number;
  name: string;
  category: string | null;
  quantity: number;
  unitPrice: string | null;
  reorderLevel: number | null;
  supplier: string | null;
  location: string | null;
  status: string | null;
}

interface InventoryListProps {
  initialItems: InventoryItem[];
}

const defaultItems: InventoryItem[] = [
  {
    id: 1,
    name: "Mathematics Textbooks",
    category: "Books",
    quantity: 120,
    unitPrice: "45.00",
    reorderLevel: 50,
    supplier: "EduBooks Ltd",
    location: "Store A",
    status: "in_stock",
  },
  {
    id: 2,
    name: "Science Lab Kits",
    category: "Teaching Materials",
    quantity: 25,
    unitPrice: "180.00",
    reorderLevel: 15,
    supplier: "ScienceWorld",
    location: "Lab Store",
    status: "low_stock",
  },
  {
    id: 3,
    name: "Laptops",
    category: "ICT Equipment",
    quantity: 45,
    unitPrice: "2500.00",
    reorderLevel: 20,
    supplier: "TechGhana",
    location: "ICT Room",
    status: "in_stock",
  },
  {
    id: 4,
    name: "Footballs",
    category: "Sports Equipment",
    quantity: 8,
    unitPrice: "65.00",
    reorderLevel: 15,
    supplier: "SportsPlus",
    location: "Sports Store",
    status: "out_of_stock",
  },
];

export default function InventoryList({ initialItems }: InventoryListProps) {
  const [items, setItems] = useState<InventoryItem[]>(
    initialItems.length > 0 ? initialItems : defaultItems
  );
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    category: "",
    quantity: "",
    unitPrice: "",
    reorderLevel: "",
    supplier: "",
    location: "",
  });

  const filteredItems = items.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !categoryFilter || item.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const categories = [...new Set(items.map((item) => item.category).filter(Boolean))];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch("/api/inventory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const newItem = await response.json();
        setItems([newItem, ...items]);
        setIsModalOpen(false);
        setFormData({
          name: "",
          category: "",
          quantity: "",
          unitPrice: "",
          reorderLevel: "",
          supplier: "",
          location: "",
        });
      }
    } catch (error) {
      console.error("Error adding item:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getStatusBadge = (status: string | null) => {
    switch (status) {
      case "in_stock":
        return (
          <span className="px-2 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs">
            In Stock
          </span>
        );
      case "low_stock":
        return (
          <span className="px-2 py-1 rounded-full bg-amber-500/20 text-amber-400 text-xs">
            Low Stock
          </span>
        );
      case "out_of_stock":
        return (
          <span className="px-2 py-1 rounded-full bg-red-500/20 text-red-400 text-xs">
            Reorder Needed
          </span>
        );
      default:
        return (
          <span className="px-2 py-1 rounded-full bg-slate-500/20 text-slate-400 text-xs">
            Unknown
          </span>
        );
    }
  };

  return (
    <>
      <div className="card rounded-3xl p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-5">
          <h3 className="text-2xl font-bold">Inventory Items</h3>
          <div className="flex flex-wrap gap-3">
            <select
              className="select w-48"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
            >
              <option value="">All Categories</option>
              {categories.map((cat) => (
                <option key={cat} value={cat || ""}>
                  {cat}
                </option>
              ))}
            </select>
            <input
              className="input max-w-xs"
              placeholder="Search items..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button
              onClick={() => setIsModalOpen(true)}
              className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"
            >
              <i className="fas fa-plus mr-2"></i> Add Item
            </button>
          </div>
        </div>

        <div className="table-wrap overflow-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-300">
              <tr className="border-b border-slate-700">
                <th className="py-3 pr-4">Item</th>
                <th className="py-3 pr-4">Category</th>
                <th className="py-3 pr-4">Quantity</th>
                <th className="py-3 pr-4">Unit Price</th>
                <th className="py-3 pr-4">Total Value</th>
                <th className="py-3 pr-4">Reorder Level</th>
                <th className="py-3 pr-4">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    No inventory items found
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => (
                  <tr key={item.id} className="border-b border-slate-800/70">
                    <td className="py-3 pr-4 font-semibold">{item.name}</td>
                    <td className="py-3 pr-4">{item.category || "N/A"}</td>
                    <td className="py-3 pr-4">{item.quantity}</td>
                    <td className="py-3 pr-4">
                      GHS {parseFloat(item.unitPrice || "0").toFixed(2)}
                    </td>
                    <td className="py-3 pr-4">
                      GHS{" "}
                      {(
                        item.quantity * parseFloat(item.unitPrice || "0")
                      ).toLocaleString()}
                    </td>
                    <td className="py-3 pr-4">{item.reorderLevel || "N/A"}</td>
                    <td className="py-3 pr-4">{getStatusBadge(item.status)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Add Inventory Item"
      >
        <form onSubmit={handleSubmit}>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="text-sm text-slate-300">Item Name</label>
              <input
                className="input mt-2"
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                required
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">Category</label>
              <select
                className="select mt-2"
                value={formData.category}
                onChange={(e) =>
                  setFormData({ ...formData, category: e.target.value })
                }
              >
                <option value="">Select Category</option>
                <option value="Books">Books</option>
                <option value="Stationery">Stationery</option>
                <option value="ICT Equipment">ICT Equipment</option>
                <option value="Sports Equipment">Sports Equipment</option>
                <option value="Teaching Materials">Teaching Materials</option>
                <option value="Furniture">Furniture</option>
              </select>
            </div>
            <div>
              <label className="text-sm text-slate-300">Quantity</label>
              <input
                type="number"
                className="input mt-2"
                value={formData.quantity}
                onChange={(e) =>
                  setFormData({ ...formData, quantity: e.target.value })
                }
                required
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">Unit Price (GHS)</label>
              <input
                type="number"
                step="0.01"
                className="input mt-2"
                value={formData.unitPrice}
                onChange={(e) =>
                  setFormData({ ...formData, unitPrice: e.target.value })
                }
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">Reorder Level</label>
              <input
                type="number"
                className="input mt-2"
                value={formData.reorderLevel}
                onChange={(e) =>
                  setFormData({ ...formData, reorderLevel: e.target.value })
                }
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">Supplier</label>
              <input
                className="input mt-2"
                value={formData.supplier}
                onChange={(e) =>
                  setFormData({ ...formData, supplier: e.target.value })
                }
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">Location</label>
              <input
                className="input mt-2"
                value={formData.location}
                onChange={(e) =>
                  setFormData({ ...formData, location: e.target.value })
                }
              />
            </div>
          </div>
          <div className="mt-6 flex gap-4">
            <button
              type="submit"
              disabled={isSubmitting}
              className="btn px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white disabled:opacity-50"
            >
              {isSubmitting ? "Saving..." : "Add Item"}
            </button>
            <button
              type="button"
              className="btn px-4 py-2 rounded-xl bg-slate-500 hover:bg-slate-400 text-white"
              onClick={() => setIsModalOpen(false)}
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>
    </>
  );
}
