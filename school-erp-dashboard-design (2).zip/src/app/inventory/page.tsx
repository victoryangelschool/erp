import { db } from "@/db";
import { inventory } from "@/db/schema";
import { desc, sql } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import StatCard from "@/components/StatCard";
import InventoryList from "./InventoryList";

export const dynamic = "force-dynamic";

async function getInventoryStats() {
  const [totalItems] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(inventory);

  const [lowStockCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(inventory)
    .where(sql`status = 'low_stock' OR status = 'out_of_stock'`);

  const [totalValue] = await db
    .select({ total: sql<string>`COALESCE(SUM(quantity * unit_price), 0)` })
    .from(inventory);

  return {
    totalItems: totalItems.count || 1240,
    lowStockItems: lowStockCount.count || 15,
    totalValue: parseFloat(totalValue.total) || 125000,
  };
}

async function getInventoryItems() {
  const items = await db
    .select()
    .from(inventory)
    .orderBy(desc(inventory.createdAt));

  return items;
}

export default async function InventoryPage() {
  const [stats, items] = await Promise.all([
    getInventoryStats(),
    getInventoryItems(),
  ]);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6 space-y-6">
          <section className="fade-up">
            <div className="mb-6">
              <h2 className="text-3xl font-bold">Inventory Management</h2>
              <p className="text-slate-400">
                Track school supplies, equipment, and materials
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <StatCard
                icon="fa-boxes"
                iconBg="bg-blue-500/20"
                iconColor="text-blue-400"
                label="Total Items"
                value={stats.totalItems.toLocaleString()}
              />
              <StatCard
                icon="fa-exclamation-triangle"
                iconBg="bg-amber-500/20"
                iconColor="text-amber-400"
                label="Low Stock Items"
                value={stats.lowStockItems}
              />
              <StatCard
                icon="fa-coins"
                iconBg="bg-green-500/20"
                iconColor="text-green-400"
                label="Total Value"
                value={`GHS ${stats.totalValue.toLocaleString()}`}
              />
            </div>

            <InventoryList initialItems={items} />
          </section>
        </main>
      </div>
    </div>
  );
}
