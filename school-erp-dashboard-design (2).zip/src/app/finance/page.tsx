import { db } from "@/db";
import {
  transactions,
  incomeItems,
  expenseItems,
  students,
} from "@/db/schema";
import { desc, sql, eq } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import StatCard from "@/components/StatCard";
import FinanceContent from "./FinanceContent";

export const dynamic = "force-dynamic";

async function getFinanceStats() {
  const [totalIncome] = await db
    .select({ total: sql<string>`COALESCE(SUM(amount), 0)` })
    .from(transactions)
    .where(eq(transactions.type, "income"));

  const [totalExpense] = await db
    .select({ total: sql<string>`COALESCE(SUM(amount), 0)` })
    .from(transactions)
    .where(eq(transactions.type, "expense"));

  const [txnCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(transactions);

  const income = parseFloat(totalIncome.total) || 0;
  const expense = parseFloat(totalExpense.total) || 0;

  return {
    totalIncome: income,
    totalExpense: expense,
    netBalance: income - expense,
    totalTransactions: txnCount.count || 0,
  };
}

async function getTransactions() {
  const txns = await db
    .select()
    .from(transactions)
    .orderBy(desc(transactions.createdAt))
    .limit(50);
  return txns;
}

async function getIncomeItemsList() {
  return db
    .select()
    .from(incomeItems)
    .where(eq(incomeItems.isActive, true))
    .orderBy(incomeItems.name);
}

async function getExpenseItemsList() {
  return db
    .select()
    .from(expenseItems)
    .where(eq(expenseItems.isActive, true))
    .orderBy(expenseItems.name);
}

async function getStudentsList() {
  return db
    .select({
      id: students.id,
      studentId: students.studentId,
      firstName: students.firstName,
      lastName: students.lastName,
    })
    .from(students);
}

function fmtCurrency(n: number) {
  return `GHS ${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export default async function FinancePage() {
  const [stats, txns, incItems, expItems, studentsList] = await Promise.all([
    getFinanceStats(),
    getTransactions(),
    getIncomeItemsList(),
    getExpenseItemsList(),
    getStudentsList(),
  ]);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6 space-y-6">
          <section className="fade-up">
            <div className="mb-6">
              <h2 className="text-3xl font-bold">Finance & Accounting</h2>
              <p className="text-slate-400">
                Receive payments, make payments, and track all transactions
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <StatCard
                icon="fa-arrow-down"
                iconBg="bg-emerald-500/20"
                iconColor="text-emerald-400"
                label="Total Income"
                value={fmtCurrency(stats.totalIncome)}
              />
              <StatCard
                icon="fa-arrow-up"
                iconBg="bg-red-500/20"
                iconColor="text-red-400"
                label="Total Expenses"
                value={fmtCurrency(stats.totalExpense)}
              />
              <StatCard
                icon="fa-wallet"
                iconBg="bg-sky-500/20"
                iconColor="text-sky-400"
                label="Net Balance"
                value={fmtCurrency(stats.netBalance)}
              />
              <StatCard
                icon="fa-exchange-alt"
                iconBg="bg-purple-500/20"
                iconColor="text-purple-400"
                label="Transactions"
                value={stats.totalTransactions}
              />
            </div>

            <FinanceContent
              initialTransactions={txns}
              incomeItems={incItems}
              expenseItems={expItems}
              students={studentsList}
            />
          </section>
        </main>
      </div>
    </div>
  );
}
