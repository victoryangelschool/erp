"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import Modal from "@/components/Modal";
import jsQR from "jsqr";

/* ---------- types ---------- */
interface Transaction {
  id: number; type: "income" | "expense"; categoryId: number; categoryName: string;
  amount: string; description: string | null; reference: string | null;
  paymentMethod: string | null; paidTo: string | null; receivedFrom: string | null;
  transactionDate: string | null; term: string | null; academicYear: string | null;
  notes: string | null; createdAt: Date | null;
}
interface CategoryItem { id: number; name: string; description: string | null; }
interface Student { id: number; studentId: string; firstName: string; lastName: string; }

interface FinanceContentProps {
  initialTransactions: Transaction[]; incomeItems: CategoryItem[];
  expenseItems: CategoryItem[]; students: Student[];
}

export default function FinanceContent({ initialTransactions, incomeItems, expenseItems, students }: FinanceContentProps) {
  const [txns, setTxns] = useState<Transaction[]>(initialTransactions);
  const [activeTab, setActiveTab] = useState<"all" | "income" | "expense">("all");
  const [incomeModal, setIncomeModal] = useState(false);
  const [expenseModal, setExpenseModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  /* ── income form ── */
  const [incomeForm, setIncomeForm] = useState({
    categoryId: "", amount: "", description: "", paymentMethod: "cash",
    receivedFrom: "", transactionDate: new Date().toISOString().split("T")[0],
    term: "First Term", academicYear: "2025/2026", notes: "",
  });

  /* ── student lookup state ── */
  const [lookupMode, setLookupMode] = useState<"id" | "qr">("id");
  const [studentIdInput, setStudentIdInput] = useState("");
  const [matchedStudent, setMatchedStudent] = useState<Student | null>(null);
  const [lookupError, setLookupError] = useState("");

  /* ── QR camera ── */
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState("");
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanRef = useRef<ReturnType<typeof setInterval> | null>(null);

  /* ── expense form ── */
  const [expenseForm, setExpenseForm] = useState({
    categoryId: "", amount: "", description: "", paymentMethod: "cash",
    paidTo: "", transactionDate: new Date().toISOString().split("T")[0],
    term: "First Term", academicYear: "2025/2026", notes: "",
  });

  const filteredTxns = activeTab === "all" ? txns : txns.filter(t => t.type === activeTab);

  /* ── student lookup by ID ── */
  const lookupStudent = useCallback((code: string) => {
    const trimmed = code.trim().toUpperCase();
    setStudentIdInput(trimmed);
    setLookupError("");
    setMatchedStudent(null);
    if (!trimmed) return;
    const found = students.find(s => s.studentId === trimmed);
    if (found) {
      setMatchedStudent(found);
      setIncomeForm(f => ({ ...f, receivedFrom: `${found.firstName} ${found.lastName} (${found.studentId})` }));
    } else {
      setLookupError("No student found with that ID");
    }
  }, [students]);

  /* ── camera helpers ── */
  const stopCamera = useCallback(() => {
    if (scanRef.current) { clearInterval(scanRef.current); scanRef.current = null; }
    if (streamRef.current) { streamRef.current.getTracks().forEach(t => t.stop()); streamRef.current = null; }
    setCameraActive(false);
  }, []);

  const startCamera = useCallback(async () => {
    setCameraError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 480 }, height: { ideal: 360 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute("playsinline", "true");
        await videoRef.current.play();
      }
      setCameraActive(true);
      scanRef.current = setInterval(() => {
        if (!videoRef.current || !canvasRef.current) return;
        const v = videoRef.current;
        if (v.readyState !== v.HAVE_ENOUGH_DATA) return;
        const c = canvasRef.current;
        c.width = v.videoWidth; c.height = v.videoHeight;
        const ctx = c.getContext("2d"); if (!ctx) return;
        ctx.drawImage(v, 0, 0, c.width, c.height);
        const img = ctx.getImageData(0, 0, c.width, c.height);
        const qr = jsQR(img.data, img.width, img.height, { inversionAttempts: "dontInvert" });
        if (qr && qr.data) {
          stopCamera();
          setStudentIdInput(qr.data);
          lookupStudent(qr.data);
        }
      }, 250);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Unknown error";
      setCameraError(msg.includes("NotAllowed") || msg.includes("Permission")
        ? "Camera permission denied. Please allow camera access."
        : msg.includes("NotFound") ? "No camera found." : `Camera error: ${msg}`);
    }
  }, [stopCamera, lookupStudent]);

  useEffect(() => { return () => { stopCamera(); }; }, [stopCamera]);

  // Start/stop camera when mode changes inside the income modal
  useEffect(() => {
    if (incomeModal && lookupMode === "qr") startCamera();
    else stopCamera();
  }, [lookupMode, incomeModal, startCamera, stopCamera]);

  // Reset student lookup when modal closes
  useEffect(() => {
    if (!incomeModal) {
      setMatchedStudent(null); setStudentIdInput(""); setLookupError("");
      setLookupMode("id"); stopCamera();
    }
  }, [incomeModal, stopCamera]);

  /* ── submit income ── */
  const handleReceivePayment = async (e: React.FormEvent) => {
    e.preventDefault(); setSubmitting(true);
    try {
      const cat = incomeItems.find(c => c.id === parseInt(incomeForm.categoryId));
      const res = await fetch("/api/transactions", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "income", categoryId: incomeForm.categoryId, categoryName: cat?.name || "",
          amount: incomeForm.amount, description: incomeForm.description,
          paymentMethod: incomeForm.paymentMethod, receivedFrom: incomeForm.receivedFrom,
          transactionDate: incomeForm.transactionDate, term: incomeForm.term,
          academicYear: incomeForm.academicYear, notes: incomeForm.notes,
        }),
      });
      if (res.ok) {
        const newTxn = await res.json(); setTxns([newTxn, ...txns]); setIncomeModal(false);
        setIncomeForm({ categoryId: "", amount: "", description: "", paymentMethod: "cash", receivedFrom: "", transactionDate: new Date().toISOString().split("T")[0], term: "First Term", academicYear: "2025/2026", notes: "" });
      }
    } catch (err) { console.error(err); } finally { setSubmitting(false); }
  };

  /* ── submit expense ── */
  const handleMakePayment = async (e: React.FormEvent) => {
    e.preventDefault(); setSubmitting(true);
    try {
      const cat = expenseItems.find(c => c.id === parseInt(expenseForm.categoryId));
      const res = await fetch("/api/transactions", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "expense", categoryId: expenseForm.categoryId, categoryName: cat?.name || "",
          amount: expenseForm.amount, description: expenseForm.description,
          paymentMethod: expenseForm.paymentMethod, paidTo: expenseForm.paidTo,
          transactionDate: expenseForm.transactionDate, term: expenseForm.term,
          academicYear: expenseForm.academicYear, notes: expenseForm.notes,
        }),
      });
      if (res.ok) {
        const newTxn = await res.json(); setTxns([newTxn, ...txns]); setExpenseModal(false);
        setExpenseForm({ categoryId: "", amount: "", description: "", paymentMethod: "cash", paidTo: "", transactionDate: new Date().toISOString().split("T")[0], term: "First Term", academicYear: "2025/2026", notes: "" });
      }
    } catch (err) { console.error(err); } finally { setSubmitting(false); }
  };

  /* ============ RENDER ============ */
  return (
    <>
      {/* action buttons */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <button onClick={() => setIncomeModal(true)} className="module-card card rounded-3xl p-6 text-left">
          <div className="flex items-center gap-4">
            <div className="p-4 rounded-2xl bg-emerald-500/20 text-emerald-400"><i className="fas fa-arrow-down text-3xl"></i></div>
            <div><h3 className="text-xl font-bold">Receive Payment</h3><p className="text-slate-400 text-sm mt-1">Record income — fees, donations, sales, etc.</p></div>
          </div>
        </button>
        <button onClick={() => setExpenseModal(true)} className="module-card card rounded-3xl p-6 text-left">
          <div className="flex items-center gap-4">
            <div className="p-4 rounded-2xl bg-red-500/20 text-red-400"><i className="fas fa-arrow-up text-3xl"></i></div>
            <div><h3 className="text-xl font-bold">Make Payment</h3><p className="text-slate-400 text-sm mt-1">Record expense — supplies, utilities, services, etc.</p></div>
          </div>
        </button>
      </div>

      {/* transaction listing */}
      <div className="card rounded-3xl p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-5">
          <h3 className="text-2xl font-bold">Transaction History</h3>
          <div className="flex gap-2">
            {(["all", "income", "expense"] as const).map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab)} className={`btn px-4 py-2 rounded-xl text-sm font-semibold transition ${activeTab === tab ? (tab === "income" ? "bg-emerald-500 text-white" : tab === "expense" ? "bg-red-500 text-white" : "bg-sky-500 text-white") : "bg-white/5 border border-white/10 hover:bg-white/10"}`}>
                {tab === "all" ? "All" : tab === "income" ? "Income" : "Expenses"}
              </button>
            ))}
          </div>
        </div>
        {filteredTxns.length === 0 ? (
          <div className="text-center py-16"><i className="fas fa-receipt text-4xl text-slate-600 mb-4"></i><p className="text-slate-400">No transactions recorded yet.</p></div>
        ) : (
          <div className="table-wrap overflow-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-300"><tr className="border-b border-slate-700">
                <th className="py-3 pr-4">Date</th><th className="py-3 pr-4">Ref</th><th className="py-3 pr-4">Type</th>
                <th className="py-3 pr-4">Category</th><th className="py-3 pr-4">Description</th>
                <th className="py-3 pr-4">From / To</th><th className="py-3 pr-4">Method</th><th className="py-3 pr-4 text-right">Amount</th>
              </tr></thead>
              <tbody>
                {filteredTxns.map(txn => (
                  <tr key={txn.id} className="border-b border-slate-800/70">
                    <td className="py-3 pr-4 whitespace-nowrap">{txn.transactionDate}</td>
                    <td className="py-3 pr-4 font-mono text-xs">{txn.reference}</td>
                    <td className="py-3 pr-4">{txn.type === "income" ? <span className="px-2 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-semibold">Income</span> : <span className="px-2 py-1 rounded-full bg-red-500/20 text-red-400 text-xs font-semibold">Expense</span>}</td>
                    <td className="py-3 pr-4 font-semibold">{txn.categoryName}</td>
                    <td className="py-3 pr-4 max-w-[180px] truncate">{txn.description || "—"}</td>
                    <td className="py-3 pr-4">{txn.type === "income" ? txn.receivedFrom || "—" : txn.paidTo || "—"}</td>
                    <td className="py-3 pr-4 capitalize">{txn.paymentMethod?.replace("_", " ") || "—"}</td>
                    <td className={`py-3 pr-4 text-right font-bold whitespace-nowrap ${txn.type === "income" ? "text-emerald-400" : "text-red-400"}`}>
                      {txn.type === "income" ? "+" : "−"} GHS {parseFloat(txn.amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ═══════ RECEIVE PAYMENT MODAL ═══════ */}
      <Modal isOpen={incomeModal} onClose={() => setIncomeModal(false)} title="Receive Payment (Income)">
        {incomeItems.length === 0 ? (
          <div className="text-center py-8">
            <i className="fas fa-exclamation-triangle text-3xl text-amber-400 mb-3"></i>
            <p className="text-slate-300 mb-2">No income items configured yet.</p>
            <p className="text-sm text-slate-400">Go to <b>Settings → Income Items</b> first.</p>
            <button onClick={() => setIncomeModal(false)} className="btn mt-4 px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Close</button>
          </div>
        ) : (
          <form onSubmit={handleReceivePayment}>
            {/* ── Student lookup section ── */}
            <div className="p-4 rounded-2xl bg-sky-500/5 border border-sky-500/20 mb-5">
              <label className="text-sm font-semibold text-sky-300 block mb-2">
                <i className="fas fa-user-graduate mr-2"></i>Identify Payer (Student)
              </label>
              <div className="flex gap-2 mb-3">
                <button type="button" onClick={() => setLookupMode("id")} className={`flex-1 py-2 rounded-xl text-sm font-semibold transition border ${lookupMode === "id" ? "bg-sky-500 border-sky-400 text-white" : "bg-white/5 border-white/10 hover:bg-white/10 text-slate-300"}`}>
                  <i className="fas fa-keyboard mr-2"></i>Type Student ID
                </button>
                <button type="button" onClick={() => setLookupMode("qr")} className={`flex-1 py-2 rounded-xl text-sm font-semibold transition border ${lookupMode === "qr" ? "bg-sky-500 border-sky-400 text-white" : "bg-white/5 border-white/10 hover:bg-white/10 text-slate-300"}`}>
                  <i className="fas fa-camera mr-2"></i>Scan QR Code
                </button>
              </div>

              {lookupMode === "id" && (
                <div className="flex gap-2">
                  <input className="input flex-1 font-mono text-center tracking-wider" placeholder="e.g. STU001" value={studentIdInput} onChange={e => { setStudentIdInput(e.target.value); setLookupError(""); setMatchedStudent(null); }} />
                  <button type="button" onClick={() => lookupStudent(studentIdInput)} className="btn px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold">
                    <i className="fas fa-search"></i>
                  </button>
                </div>
              )}

              {lookupMode === "qr" && (
                <div className="space-y-3">
                  {cameraError && (
                    <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
                      <i className="fas fa-exclamation-triangle mr-2"></i>{cameraError}
                      <button type="button" onClick={startCamera} className="ml-2 underline hover:text-red-300">Retry</button>
                    </div>
                  )}
                  <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center">
                    <video ref={videoRef} className="w-full h-full object-cover" muted playsInline />
                    <canvas ref={canvasRef} className="hidden" />
                    {cameraActive && (
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <div className="w-36 h-36 border-2 border-sky-400 rounded-xl">
                          <div className="absolute top-0 left-0 w-5 h-5 border-t-4 border-l-4 border-sky-400 rounded-tl-lg"></div>
                          <div className="absolute top-0 right-0 w-5 h-5 border-t-4 border-r-4 border-sky-400 rounded-tr-lg"></div>
                          <div className="absolute bottom-0 left-0 w-5 h-5 border-b-4 border-l-4 border-sky-400 rounded-bl-lg"></div>
                          <div className="absolute bottom-0 right-0 w-5 h-5 border-b-4 border-r-4 border-sky-400 rounded-br-lg"></div>
                        </div>
                      </div>
                    )}
                    {!cameraActive && !cameraError && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400">
                        <i className="fas fa-camera text-3xl mb-2"></i><p className="text-xs">Starting camera...</p>
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 text-center">Point at the QR code on the student&apos;s ID card</p>
                </div>
              )}

              {/* result */}
              {matchedStudent && (
                <div className="mt-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400"><i className="fas fa-check-circle text-lg"></i></div>
                  <div>
                    <p className="font-bold text-emerald-300">{matchedStudent.firstName} {matchedStudent.lastName}</p>
                    <p className="text-xs text-emerald-400/70">{matchedStudent.studentId}</p>
                  </div>
                </div>
              )}
              {lookupError && (
                <div className="mt-3 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
                  <i className="fas fa-exclamation-circle mr-2"></i>{lookupError}
                </div>
              )}
              <p className="text-xs text-slate-500 mt-2">Or type a name/org directly in the &quot;Received From&quot; field below for non-student payments.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="text-sm text-slate-300">Income Category *</label>
                <select className="select mt-2" value={incomeForm.categoryId} onChange={e => setIncomeForm({ ...incomeForm, categoryId: e.target.value })} required>
                  <option value="">Select income item</option>
                  {incomeItems.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm text-slate-300">Amount (GHS) *</label>
                <input type="number" step="0.01" className="input mt-2" placeholder="0.00" value={incomeForm.amount} onChange={e => setIncomeForm({ ...incomeForm, amount: e.target.value })} required />
              </div>
              <div>
                <label className="text-sm text-slate-300">Payment Method</label>
                <select className="select mt-2" value={incomeForm.paymentMethod} onChange={e => setIncomeForm({ ...incomeForm, paymentMethod: e.target.value })}>
                  <option value="cash">Cash</option><option value="bank_transfer">Bank Transfer</option>
                  <option value="mobile_money">Mobile Money</option><option value="cheque">Cheque</option>
                </select>
              </div>
              <div>
                <label className="text-sm text-slate-300">Received From</label>
                <input className="input mt-2" placeholder="Auto-filled from student lookup or type manually" value={incomeForm.receivedFrom} onChange={e => setIncomeForm({ ...incomeForm, receivedFrom: e.target.value })} />
              </div>
              <div>
                <label className="text-sm text-slate-300">Date</label>
                <input type="date" className="input mt-2" value={incomeForm.transactionDate} onChange={e => setIncomeForm({ ...incomeForm, transactionDate: e.target.value })} />
              </div>
              <div className="md:col-span-2">
                <label className="text-sm text-slate-300">Description</label>
                <input className="input mt-2" placeholder="Brief description" value={incomeForm.description} onChange={e => setIncomeForm({ ...incomeForm, description: e.target.value })} />
              </div>
              <div className="md:col-span-2">
                <label className="text-sm text-slate-300">Notes</label>
                <textarea className="textarea mt-2" placeholder="Additional notes" value={incomeForm.notes} onChange={e => setIncomeForm({ ...incomeForm, notes: e.target.value })} />
              </div>
            </div>
            <div className="mt-6 flex gap-4">
              <button type="submit" disabled={submitting} className="btn px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white disabled:opacity-50">{submitting ? "Processing…" : "Receive Payment"}</button>
              <button type="button" onClick={() => setIncomeModal(false)} className="btn px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button>
            </div>
          </form>
        )}
      </Modal>

      {/* ═══════ MAKE PAYMENT MODAL ═══════ */}
      <Modal isOpen={expenseModal} onClose={() => setExpenseModal(false)} title="Make Payment (Expense)">
        {expenseItems.length === 0 ? (
          <div className="text-center py-8">
            <i className="fas fa-exclamation-triangle text-3xl text-amber-400 mb-3"></i>
            <p className="text-slate-300 mb-2">No expense items configured yet.</p>
            <p className="text-sm text-slate-400">Go to <b>Settings → Expense Items</b> first.</p>
            <button onClick={() => setExpenseModal(false)} className="btn mt-4 px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Close</button>
          </div>
        ) : (
          <form onSubmit={handleMakePayment}>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="text-sm text-slate-300">Expense Category *</label>
                <select className="select mt-2" value={expenseForm.categoryId} onChange={e => setExpenseForm({ ...expenseForm, categoryId: e.target.value })} required>
                  <option value="">Select expense item</option>
                  {expenseItems.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm text-slate-300">Amount (GHS) *</label>
                <input type="number" step="0.01" className="input mt-2" placeholder="0.00" value={expenseForm.amount} onChange={e => setExpenseForm({ ...expenseForm, amount: e.target.value })} required />
              </div>
              <div>
                <label className="text-sm text-slate-300">Payment Method</label>
                <select className="select mt-2" value={expenseForm.paymentMethod} onChange={e => setExpenseForm({ ...expenseForm, paymentMethod: e.target.value })}>
                  <option value="cash">Cash</option><option value="bank_transfer">Bank Transfer</option>
                  <option value="mobile_money">Mobile Money</option><option value="cheque">Cheque</option>
                </select>
              </div>
              <div>
                <label className="text-sm text-slate-300">Paid To</label>
                <input className="input mt-2" placeholder="Vendor, person, or company" value={expenseForm.paidTo} onChange={e => setExpenseForm({ ...expenseForm, paidTo: e.target.value })} />
              </div>
              <div>
                <label className="text-sm text-slate-300">Date</label>
                <input type="date" className="input mt-2" value={expenseForm.transactionDate} onChange={e => setExpenseForm({ ...expenseForm, transactionDate: e.target.value })} />
              </div>
              <div className="md:col-span-2">
                <label className="text-sm text-slate-300">Description</label>
                <input className="input mt-2" placeholder="Brief description" value={expenseForm.description} onChange={e => setExpenseForm({ ...expenseForm, description: e.target.value })} />
              </div>
              <div className="md:col-span-2">
                <label className="text-sm text-slate-300">Notes</label>
                <textarea className="textarea mt-2" placeholder="Additional notes" value={expenseForm.notes} onChange={e => setExpenseForm({ ...expenseForm, notes: e.target.value })} />
              </div>
            </div>
            <div className="mt-6 flex gap-4">
              <button type="submit" disabled={submitting} className="btn px-5 py-2 rounded-xl bg-red-500 hover:bg-red-400 text-white disabled:opacity-50">{submitting ? "Processing…" : "Make Payment"}</button>
              <button type="button" onClick={() => setExpenseModal(false)} className="btn px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button>
            </div>
          </form>
        )}
      </Modal>
    </>
  );
}
