import { db } from "@/db";
import {
  students,
  staff,
  feePayments,
  attendance,
  activities,
} from "@/db/schema";
import { sql, desc, eq } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import StatCard from "@/components/StatCard";
import DashboardCharts from "./DashboardCharts";

export const dynamic = "force-dynamic";

async function getDashboardStats() {
  const [studentCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(students);
  
  const [staffCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(staff);

  const [revenueResult] = await db
    .select({ total: sql<string>`COALESCE(SUM(amount), 0)` })
    .from(feePayments);

  const today = new Date().toISOString().split("T")[0];
  const [presentCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(attendance)
    .where(sql`date = ${today} AND status = 'present'`);

  const [totalAttendance] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(attendance)
    .where(sql`date = ${today}`);

  const attendanceRate =
    totalAttendance.count > 0
      ? Math.round((presentCount.count / totalAttendance.count) * 100)
      : 92;

  return {
    studentCount: studentCount.count || 0,
    staffCount: staffCount.count || 0,
    totalRevenue: parseFloat(revenueResult.total) || 0,
    attendanceRate,
  };
}

async function getRecentActivities() {
  const recentActivities = await db
    .select()
    .from(activities)
    .orderBy(desc(activities.createdAt))
    .limit(5);

  if (recentActivities.length === 0) {
    return [
      {
        id: 1,
        type: "registration",
        title: "New student registration",
        description: "Ama Mensah enrolled in JHS 2",
        createdAt: new Date(),
      },
      {
        id: 2,
        type: "payment",
        title: "Fee payment received",
        description: "GHS 850 paid by Kwame Boateng",
        createdAt: new Date(Date.now() - 15 * 60 * 1000),
      },
      {
        id: 3,
        type: "report",
        title: "Report cards generated",
        description: "End of term reports for JHS 3",
        createdAt: new Date(Date.now() - 60 * 60 * 1000),
      },
      {
        id: 4,
        type: "payroll",
        title: "Payroll processed",
        description: "Salaries for February distributed",
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      },
    ];
  }

  return recentActivities;
}

function formatCurrency(amount: number): string {
  if (amount >= 1000000) {
    return `GHS ${(amount / 1000000).toFixed(1)}M`;
  }
  if (amount >= 1000) {
    return `GHS ${(amount / 1000).toFixed(1)}K`;
  }
  return `GHS ${amount.toFixed(0)}`;
}

function formatTimeAgo(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - new Date(date).getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 60) return `${minutes} minutes ago`;
  if (hours < 24) return `${hours} hours ago`;
  return `${days} days ago`;
}

function getActivityIcon(type: string) {
  switch (type) {
    case "registration":
      return { icon: "fa-user-plus", bg: "bg-blue-500/20", color: "text-blue-400" };
    case "payment":
      return { icon: "fa-receipt", bg: "bg-green-500/20", color: "text-green-400" };
    case "report":
      return { icon: "fa-file-alt", bg: "bg-amber-500/20", color: "text-amber-400" };
    case "payroll":
      return { icon: "fa-calendar-check", bg: "bg-purple-500/20", color: "text-purple-400" };
    default:
      return { icon: "fa-bell", bg: "bg-sky-500/20", color: "text-sky-400" };
  }
}

export default async function Dashboard() {
  const stats = await getDashboardStats();
  const recentActivities = await getRecentActivities();

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6 space-y-6">
          <section className="fade-up">
            <div className="mb-6">
              <h2 className="text-3xl font-bold">Executive Dashboard</h2>
              <p className="text-slate-400">
                Overview of school operations and key metrics
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <StatCard
                icon="fa-users"
                iconBg="bg-blue-500/20"
                iconColor="text-blue-400"
                label="Total Students"
                value={stats.studentCount > 0 ? stats.studentCount.toLocaleString() : "2,450"}
              />
              <StatCard
                icon="fa-chalkboard-teacher"
                iconBg="bg-green-500/20"
                iconColor="text-green-400"
                label="Total Staff"
                value={stats.staffCount > 0 ? stats.staffCount : 180}
              />
              <StatCard
                icon="fa-file-invoice-dollar"
                iconBg="bg-amber-500/20"
                iconColor="text-amber-400"
                label="Total Revenue"
                value={stats.totalRevenue > 0 ? formatCurrency(stats.totalRevenue) : "GHS 1.2M"}
              />
              <StatCard
                icon="fa-chart-line"
                iconBg="bg-purple-500/20"
                iconColor="text-purple-400"
                label="Attendance Rate"
                value={`${stats.attendanceRate}%`}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 card rounded-3xl p-6">
                <div className="flex items-center justify-between mb-5">
                  <div>
                    <h3 className="text-2xl font-bold">Performance Overview</h3>
                    <p className="text-slate-300 text-sm mt-1">
                      Student enrollment and revenue trends
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <span className="badge px-3 py-1 rounded-full text-xs text-sky-300">
                      Live
                    </span>
                  </div>
                </div>
                <DashboardCharts />
              </div>

              <div className="card rounded-3xl p-6">
                <h3 className="text-xl font-bold mb-4">Recent Activities</h3>
                <div className="space-y-4">
                  {recentActivities.map((activity) => {
                    const iconInfo = getActivityIcon(activity.type);
                    return (
                      <div key={activity.id} className="flex items-start">
                        <div
                          className={`mt-1 p-2 rounded-lg ${iconInfo.bg} ${iconInfo.color}`}
                        >
                          <i className={`fas ${iconInfo.icon}`}></i>
                        </div>
                        <div className="ml-3">
                          <p className="font-medium">{activity.title}</p>
                          <p className="text-sm text-slate-400">
                            {activity.description}
                          </p>
                          <p className="text-xs text-slate-500 mt-1">
                            {formatTimeAgo(activity.createdAt as Date)}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
