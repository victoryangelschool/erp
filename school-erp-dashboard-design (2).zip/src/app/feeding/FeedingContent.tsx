"use client";

import { useState } from "react";
import Modal from "@/components/Modal";

/* ── types ── */
interface MenuItem { id: number; date: string; mealType: string; description: string | null; startTime: string | null; endTime: string | null; }
interface InvItem { id: number; itemName: string; quantity: string; unit: string | null; reorderLevel: string | null; status: string | null; }
interface ReqLineItem { id: number; batchId: number; inventoryItemId: number | null; itemName: string; quantityRequested: string; unit: string | null; }
interface Batch { id: number; date: string; requestedBy: string | null; purpose: string | null; status: string | null; items: ReqLineItem[]; }

interface Props { initialMenu: MenuItem[]; initialInventory: InvItem[]; initialBatches: Batch[]; }

const today = () => new Date().toISOString().split("T")[0];
const statusBadge = (s: string | null) => {
  const m: Record<string, string> = { in_stock: "bg-emerald-500/20 text-emerald-400", low_stock: "bg-amber-500/20 text-amber-400", out_of_stock: "bg-red-500/20 text-red-400" };
  const l: Record<string, string> = { in_stock: "In Stock", low_stock: "Low Stock", out_of_stock: "Out of Stock" };
  return <span className={`px-2 py-1 rounded-full text-xs font-semibold ${m[s || ""] || "bg-slate-500/20 text-slate-400"}`}>{l[s || ""] || "—"}</span>;
};
const reqBadge = (s: string | null) => {
  const m: Record<string, string> = { pending: "bg-amber-500/20 text-amber-400", approved: "bg-blue-500/20 text-blue-400", issued: "bg-emerald-500/20 text-emerald-400" };
  return <span className={`px-2 py-1 rounded-full text-xs font-semibold ${m[s || ""] || "bg-slate-500/20 text-slate-400"}`}>{(s || "pending").charAt(0).toUpperCase() + (s || "pending").slice(1)}</span>;
};

/* ── line-item draft for the multi-item request form ── */
interface DraftLine { inventoryItemId: string; quantityRequested: string; }

export default function FeedingContent({ initialMenu, initialInventory, initialBatches }: Props) {
  const [tab, setTab] = useState<"menu" | "inventory" | "requests">("menu");

  /* Menu */
  const [menu, setMenu] = useState<MenuItem[]>(initialMenu);
  const [menuModal, setMenuModal] = useState(false);
  const [menuForm, setMenuForm] = useState({ date: today(), mealType: "Breakfast", description: "", startTime: "", endTime: "" });
  const [menuBusy, setMenuBusy] = useState(false);
  const [menuDate, setMenuDate] = useState(today());

  /* Inventory */
  const [inv, setInv] = useState<InvItem[]>(initialInventory);
  const [invModal, setInvModal] = useState(false);
  const [editingInv, setEditingInv] = useState<InvItem | null>(null);
  const [invForm, setInvForm] = useState({ itemName: "", quantity: "", unit: "kg", reorderLevel: "5" });
  const [invBusy, setInvBusy] = useState(false);

  /* Requests (batches) */
  const [batches, setBatches] = useState<Batch[]>(initialBatches);
  const [reqModal, setReqModal] = useState(false);
  const [reqDate, setReqDate] = useState(today());
  const [reqRequestedBy, setReqRequestedBy] = useState("");
  const [reqPurpose, setReqPurpose] = useState("");
  const [draftLines, setDraftLines] = useState<DraftLine[]>([{ inventoryItemId: "", quantityRequested: "" }]);
  const [reqBusy, setReqBusy] = useState(false);

  /* Detail modal for a batch */
  const [detailBatch, setDetailBatch] = useState<Batch | null>(null);

  const filteredMenu = menu.filter(m => m.date === menuDate);
  const filteredBatches = batches.filter(b => b.date === reqDate);

  /* ── Menu handlers ── */
  const handleAddMenu = async (e: React.FormEvent) => {
    e.preventDefault(); setMenuBusy(true);
    try {
      const res = await fetch("/api/feeding/menu", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(menuForm) });
      if (res.ok) { const c = await res.json(); setMenu([c, ...menu]); setMenuModal(false); setMenuForm({ date: menuDate, mealType: "Breakfast", description: "", startTime: "", endTime: "" }); }
    } catch (err) { console.error(err); } finally { setMenuBusy(false); }
  };
  const handleDeleteMenu = async (id: number) => {
    if (!confirm("Delete this menu item?")) return;
    const res = await fetch(`/api/feeding/menu/${id}`, { method: "DELETE" });
    if (res.ok) setMenu(menu.filter(m => m.id !== id));
  };

  /* ── Inventory handlers ── */
  const openInvAdd = () => { setEditingInv(null); setInvForm({ itemName: "", quantity: "", unit: "kg", reorderLevel: "5" }); setInvModal(true); };
  const openInvEdit = (i: InvItem) => { setEditingInv(i); setInvForm({ itemName: i.itemName, quantity: i.quantity, unit: i.unit || "kg", reorderLevel: i.reorderLevel || "5" }); setInvModal(true); };
  const handleInvSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setInvBusy(true);
    try {
      if (editingInv) {
        const res = await fetch(`/api/feeding/inventory/${editingInv.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(invForm) });
        if (res.ok) { const u = await res.json(); setInv(inv.map(i => i.id === u.id ? u : i)); setInvModal(false); }
      } else {
        const res = await fetch("/api/feeding/inventory", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(invForm) });
        if (res.ok) { const c = await res.json(); setInv([...inv, c].sort((a, b) => a.itemName.localeCompare(b.itemName))); setInvModal(false); }
      }
    } catch (err) { console.error(err); } finally { setInvBusy(false); }
  };
  const handleInvDelete = async (id: number) => {
    if (!confirm("Delete this inventory item?")) return;
    const res = await fetch(`/api/feeding/inventory/${id}`, { method: "DELETE" });
    if (res.ok) setInv(inv.filter(i => i.id !== id));
  };

  /* ── Draft line helpers ── */
  const addLine = () => setDraftLines([...draftLines, { inventoryItemId: "", quantityRequested: "" }]);
  const removeLine = (idx: number) => { if (draftLines.length <= 1) return; setDraftLines(draftLines.filter((_, i) => i !== idx)); };
  const updateLine = (idx: number, field: keyof DraftLine, value: string) => {
    setDraftLines(draftLines.map((l, i) => i === idx ? { ...l, [field]: value } : l));
  };
  const getInvItem = (id: string) => inv.find(i => String(i.id) === id);
  const validLines = draftLines.filter(l => l.inventoryItemId && parseFloat(l.quantityRequested) > 0);

  /* ── Request submit (batch of items) ── */
  const openReqModal = () => {
    setReqRequestedBy(""); setReqPurpose("");
    setDraftLines([{ inventoryItemId: "", quantityRequested: "" }]);
    setReqModal(true);
  };
  const handleReqSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (validLines.length === 0) { alert("Add at least one item with a quantity."); return; }
    setReqBusy(true);
    try {
      const items = validLines.map(l => {
        const it = getInvItem(l.inventoryItemId);
        return { inventoryItemId: l.inventoryItemId, itemName: it?.itemName || "Unknown", quantityRequested: l.quantityRequested, unit: it?.unit || "" };
      });
      const res = await fetch("/api/feeding/requests", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date: reqDate, requestedBy: reqRequestedBy, purpose: reqPurpose, items }),
      });
      if (res.ok) { const b = await res.json(); setBatches([b, ...batches]); setReqModal(false); }
    } catch (err) { console.error(err); } finally { setReqBusy(false); }
  };

  /* ── Batch actions ── */
  const handleBatchAction = async (id: number, action: "approved" | "issued") => {
    const res = await fetch(`/api/feeding/requests/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: action }) });
    if (res.ok) {
      const u = await res.json();
      setBatches(batches.map(b => b.id === u.id ? u : b));
      if (detailBatch?.id === u.id) setDetailBatch(u);
      if (action === "issued") { const r = await fetch("/api/feeding/inventory"); if (r.ok) setInv(await r.json()); }
    }
  };
  const handleBatchDelete = async (id: number) => {
    if (!confirm("Delete this request?")) return;
    const res = await fetch(`/api/feeding/requests/${id}`, { method: "DELETE" });
    if (res.ok) { setBatches(batches.filter(b => b.id !== id)); if (detailBatch?.id === id) setDetailBatch(null); }
  };

  const tabs = [
    { key: "menu" as const, label: "Daily Menu", icon: "fa-utensils", count: filteredMenu.length },
    { key: "inventory" as const, label: "Kitchen Inventory", icon: "fa-box", count: inv.length },
    { key: "requests" as const, label: "Daily Requests", icon: "fa-clipboard-list", count: filteredBatches.length },
  ];

  return (
    <>
      <div className="flex flex-wrap gap-2 mb-6">
        {tabs.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)} className={`btn px-5 py-3 rounded-xl font-semibold transition ${tab === t.key ? "bg-sky-500 text-white" : "bg-white/5 border border-white/10 hover:bg-white/10"}`}>
            <i className={`fas ${t.icon} mr-2`}></i>{t.label} ({t.count})
          </button>
        ))}
      </div>

      {/* ═══ MENU ═══ */}
      {tab === "menu" && (
        <div className="card rounded-3xl p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-5">
            <div className="flex items-center gap-3"><h3 className="text-xl font-bold">Menu for</h3><input type="date" className="input w-44" value={menuDate} onChange={e => setMenuDate(e.target.value)} /></div>
            <button onClick={() => { setMenuForm({ ...menuForm, date: menuDate }); setMenuModal(true); }} className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"><i className="fas fa-plus mr-2"></i>Add Meal</button>
          </div>
          {filteredMenu.length === 0 ? (
            <div className="text-center py-12"><i className="fas fa-utensils text-4xl text-slate-600 mb-3"></i><p className="text-slate-400">No menu set for this date.</p></div>
          ) : (
            <div className="space-y-3">{filteredMenu.map(m => (
              <div key={m.id} className="p-4 rounded-xl bg-slate-900/50 flex items-center justify-between group">
                <div>
                  <div className="flex items-center gap-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${m.mealType === "Breakfast" ? "bg-amber-500/20 text-amber-400" : m.mealType === "Lunch" ? "bg-blue-500/20 text-blue-400" : "bg-purple-500/20 text-purple-400"}`}>{m.mealType}</span>
                    <span className="text-slate-400 text-sm">{m.startTime} — {m.endTime}</span>
                  </div>
                  <p className="mt-2 font-medium">{m.description || "—"}</p>
                </div>
                <button onClick={() => handleDeleteMenu(m.id)} className="text-red-400 hover:text-red-300 opacity-0 group-hover:opacity-100 transition"><i className="fas fa-trash"></i></button>
              </div>
            ))}</div>
          )}
        </div>
      )}

      {/* ═══ INVENTORY ═══ */}
      {tab === "inventory" && (
        <div className="card rounded-3xl p-6">
          <div className="flex items-center justify-between mb-5"><h3 className="text-xl font-bold">Kitchen Inventory</h3>
            <button onClick={openInvAdd} className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"><i className="fas fa-plus mr-2"></i>Add Item</button>
          </div>
          {inv.length === 0 ? (
            <div className="text-center py-12"><i className="fas fa-box text-4xl text-slate-600 mb-3"></i><p className="text-slate-400">No kitchen inventory.</p></div>
          ) : (
            <div className="table-wrap overflow-auto"><table className="min-w-full text-left text-sm"><thead className="text-slate-300"><tr className="border-b border-slate-700"><th className="py-3 pr-3">Item</th><th className="py-3 pr-3 text-right">Qty</th><th className="py-3 pr-3">Unit</th><th className="py-3 pr-3 text-right">Reorder</th><th className="py-3 pr-3">Status</th><th className="py-3 pr-3 text-right">Actions</th></tr></thead>
              <tbody>{inv.map(i => (
                <tr key={i.id} className="border-b border-slate-800/70">
                  <td className="py-3 pr-3 font-semibold">{i.itemName}</td><td className="py-3 pr-3 text-right font-bold">{parseFloat(i.quantity).toLocaleString()}</td><td className="py-3 pr-3 text-slate-400">{i.unit || "—"}</td><td className="py-3 pr-3 text-right text-slate-400">{i.reorderLevel || "5"}</td><td className="py-3 pr-3">{statusBadge(i.status)}</td>
                  <td className="py-3 pr-3 text-right space-x-2"><button onClick={() => openInvEdit(i)} className="text-sky-400 hover:text-sky-300"><i className="fas fa-edit"></i></button><button onClick={() => handleInvDelete(i.id)} className="text-red-400 hover:text-red-300"><i className="fas fa-trash"></i></button></td>
                </tr>
              ))}</tbody></table></div>
          )}
        </div>
      )}

      {/* ═══ REQUESTS ═══ */}
      {tab === "requests" && (
        <div className="card rounded-3xl p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-5">
            <div className="flex items-center gap-3"><h3 className="text-xl font-bold">Requests for</h3><input type="date" className="input w-44" value={reqDate} onChange={e => setReqDate(e.target.value)} /></div>
            <button onClick={openReqModal} className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"><i className="fas fa-plus mr-2"></i>New Request</button>
          </div>
          {inv.length === 0 ? (
            <div className="text-center py-12"><i className="fas fa-exclamation-triangle text-3xl text-amber-400 mb-3"></i><p className="text-slate-400">Add kitchen inventory items first.</p></div>
          ) : filteredBatches.length === 0 ? (
            <div className="text-center py-12"><i className="fas fa-clipboard-list text-4xl text-slate-600 mb-3"></i><p className="text-slate-400">No requests for this date.</p></div>
          ) : (
            <div className="space-y-4">
              {filteredBatches.map(b => (
                <div key={b.id} className="p-4 rounded-xl bg-slate-900/50 border border-slate-700/40">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      {reqBadge(b.status)}
                      <span className="font-semibold">{b.items.length} item{b.items.length !== 1 && "s"}</span>
                      {b.requestedBy && <span className="text-xs text-slate-400">by {b.requestedBy}</span>}
                    </div>
                    <div className="flex items-center gap-2">
                      {b.status === "pending" && <button onClick={() => handleBatchAction(b.id, "approved")} className="text-xs px-3 py-1 rounded-lg bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 font-semibold">Approve</button>}
                      {b.status === "approved" && <button onClick={() => handleBatchAction(b.id, "issued")} className="text-xs px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 font-semibold">Issue</button>}
                      <button onClick={() => setDetailBatch(b)} className="text-sky-400 hover:text-sky-300"><i className="fas fa-eye"></i></button>
                      <button onClick={() => handleBatchDelete(b.id)} className="text-red-400 hover:text-red-300"><i className="fas fa-trash"></i></button>
                    </div>
                  </div>
                  {b.purpose && <p className="text-sm text-slate-400 mb-2"><i className="fas fa-info-circle mr-1"></i>{b.purpose}</p>}
                  <div className="flex flex-wrap gap-2">
                    {b.items.map(item => (
                      <span key={item.id} className="px-3 py-1 rounded-lg bg-slate-800 text-sm">
                        {item.itemName} — <strong>{parseFloat(item.quantityRequested).toLocaleString()}</strong> {item.unit}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── Menu Modal ── */}
      <Modal isOpen={menuModal} onClose={() => setMenuModal(false)} title="Add Menu Item">
        <form onSubmit={handleAddMenu}>
          <div className="grid md:grid-cols-2 gap-4">
            <div><label className="text-sm text-slate-300">Date *</label><input type="date" className="input mt-2" value={menuForm.date} onChange={e => setMenuForm({ ...menuForm, date: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Meal *</label><select className="select mt-2" value={menuForm.mealType} onChange={e => setMenuForm({ ...menuForm, mealType: e.target.value })}><option>Breakfast</option><option>Lunch</option><option>Supper</option><option>Snack</option></select></div>
            <div><label className="text-sm text-slate-300">Start Time</label><input type="time" className="input mt-2" value={menuForm.startTime} onChange={e => setMenuForm({ ...menuForm, startTime: e.target.value })} /></div>
            <div><label className="text-sm text-slate-300">End Time</label><input type="time" className="input mt-2" value={menuForm.endTime} onChange={e => setMenuForm({ ...menuForm, endTime: e.target.value })} /></div>
            <div className="md:col-span-2"><label className="text-sm text-slate-300">Description *</label><textarea className="textarea mt-2" placeholder="e.g. Jollof rice with chicken and salad" value={menuForm.description} onChange={e => setMenuForm({ ...menuForm, description: e.target.value })} required /></div>
          </div>
          <div className="mt-5 flex gap-4"><button type="submit" disabled={menuBusy} className="btn flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold disabled:opacity-50">{menuBusy ? "Saving…" : "Add Meal"}</button><button type="button" onClick={() => setMenuModal(false)} className="btn px-5 py-3 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button></div>
        </form>
      </Modal>

      {/* ── Inventory Modal ── */}
      <Modal isOpen={invModal} onClose={() => setInvModal(false)} title={editingInv ? `Edit — ${editingInv.itemName}` : "Add Inventory Item"}>
        <form onSubmit={handleInvSubmit}>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="md:col-span-2"><label className="text-sm text-slate-300">Item Name *</label><input className="input mt-2" placeholder="e.g. Rice, Beans, Oil" value={invForm.itemName} onChange={e => setInvForm({ ...invForm, itemName: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Quantity *</label><input type="number" step="0.1" className="input mt-2" value={invForm.quantity} onChange={e => setInvForm({ ...invForm, quantity: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Unit</label><select className="select mt-2" value={invForm.unit} onChange={e => setInvForm({ ...invForm, unit: e.target.value })}><option value="kg">Kilograms</option><option value="liters">Litres</option><option value="bags">Bags</option><option value="crates">Crates</option><option value="pieces">Pieces</option><option value="tins">Tins</option><option value="bottles">Bottles</option></select></div>
            <div><label className="text-sm text-slate-300">Reorder Level</label><input type="number" step="0.1" className="input mt-2" value={invForm.reorderLevel} onChange={e => setInvForm({ ...invForm, reorderLevel: e.target.value })} /></div>
          </div>
          <div className="mt-5 flex gap-4"><button type="submit" disabled={invBusy} className="btn flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold disabled:opacity-50">{invBusy ? "Saving…" : editingInv ? "Update Item" : "Add Item"}</button><button type="button" onClick={() => setInvModal(false)} className="btn px-5 py-3 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button></div>
        </form>
      </Modal>

      {/* ── Multi-Item Request Modal ── */}
      <Modal isOpen={reqModal} onClose={() => setReqModal(false)} title="Daily Inventory Request">
        <form onSubmit={handleReqSubmit}>
          <div className="grid md:grid-cols-2 gap-4 mb-5">
            <div><label className="text-sm text-slate-300">Date *</label><input type="date" className="input mt-2" value={reqDate} onChange={e => setReqDate(e.target.value)} required /></div>
            <div><label className="text-sm text-slate-300">Requested By</label><input className="input mt-2" placeholder="e.g. Head Cook" value={reqRequestedBy} onChange={e => setReqRequestedBy(e.target.value)} /></div>
            <div className="md:col-span-2"><label className="text-sm text-slate-300">Purpose</label><input className="input mt-2" placeholder="e.g. Lunch and supper preparation" value={reqPurpose} onChange={e => setReqPurpose(e.target.value)} /></div>
          </div>

          <div className="border-t border-slate-700 pt-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-bold text-sky-300"><i className="fas fa-list mr-2"></i>Items Requested</h4>
              <button type="button" onClick={addLine} className="text-sm text-sky-400 hover:text-sky-300 font-semibold"><i className="fas fa-plus mr-1"></i>Add Item</button>
            </div>

            <div className="space-y-3">
              {draftLines.map((line, idx) => {
                const selItem = getInvItem(line.inventoryItemId);
                return (
                  <div key={idx} className="flex gap-2 items-start">
                    <div className="flex-1">
                      <select className="select text-sm" value={line.inventoryItemId} onChange={e => updateLine(idx, "inventoryItemId", e.target.value)} required>
                        <option value="">Select item</option>
                        {inv.map(i => (
                          <option key={i.id} value={i.id}>{i.itemName} — {parseFloat(i.quantity).toLocaleString()} {i.unit} avail.</option>
                        ))}
                      </select>
                    </div>
                    <div className="w-28">
                      <input type="number" step="0.1" min="0.1" max={selItem ? parseFloat(selItem.quantity) : undefined} className="input text-sm text-center" placeholder="Qty" value={line.quantityRequested} onChange={e => updateLine(idx, "quantityRequested", e.target.value)} required />
                    </div>
                    <div className="w-14 text-center text-sm text-slate-400 pt-3">{selItem?.unit || ""}</div>
                    {draftLines.length > 1 && (
                      <button type="button" onClick={() => removeLine(idx)} className="text-red-400 hover:text-red-300 pt-3"><i className="fas fa-times"></i></button>
                    )}
                  </div>
                );
              })}
            </div>

            {validLines.length > 0 && (
              <div className="mt-4 p-3 rounded-xl bg-slate-900/60 border border-slate-700/40">
                <p className="text-xs text-slate-400 mb-2">Request Summary — {validLines.length} item{validLines.length !== 1 && "s"}</p>
                <div className="flex flex-wrap gap-2">
                  {validLines.map((l, i) => {
                    const it = getInvItem(l.inventoryItemId);
                    return <span key={i} className="px-3 py-1 rounded-lg bg-sky-500/10 text-sky-300 text-sm">{it?.itemName}: <strong>{l.quantityRequested}</strong> {it?.unit}</span>;
                  })}
                </div>
              </div>
            )}
          </div>

          <div className="mt-5 flex gap-4">
            <button type="submit" disabled={reqBusy || validLines.length === 0} className="btn flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold disabled:opacity-50">{reqBusy ? "Submitting…" : `Submit Request (${validLines.length} items)`}</button>
            <button type="button" onClick={() => setReqModal(false)} className="btn px-5 py-3 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button>
          </div>
        </form>
      </Modal>

      {/* ── Batch Detail Modal ── */}
      {detailBatch && (
        <Modal isOpen={!!detailBatch} onClose={() => setDetailBatch(null)} title={`Request — ${detailBatch.date}`}>
          <div className="space-y-4">
            <div className="flex items-center gap-3">{reqBadge(detailBatch.status)}<span className="text-slate-400 text-sm">{detailBatch.items.length} items</span></div>
            {detailBatch.requestedBy && <p className="text-sm"><span className="text-slate-400">Requested by:</span> {detailBatch.requestedBy}</p>}
            {detailBatch.purpose && <p className="text-sm"><span className="text-slate-400">Purpose:</span> {detailBatch.purpose}</p>}
            <div className="table-wrap overflow-auto"><table className="min-w-full text-left text-sm"><thead className="text-slate-300"><tr className="border-b border-slate-700"><th className="py-2 pr-3">#</th><th className="py-2 pr-3">Item</th><th className="py-2 pr-3 text-right">Qty</th><th className="py-2 pr-3">Unit</th></tr></thead>
              <tbody>{detailBatch.items.map((item, i) => (
                <tr key={item.id} className="border-b border-slate-800/70">
                  <td className="py-2 pr-3 text-slate-400">{i + 1}</td><td className="py-2 pr-3 font-semibold">{item.itemName}</td><td className="py-2 pr-3 text-right font-bold">{parseFloat(item.quantityRequested).toLocaleString()}</td><td className="py-2 pr-3 text-slate-400">{item.unit || "—"}</td>
                </tr>
              ))}</tbody></table></div>
            <div className="flex gap-3">
              {detailBatch.status === "pending" && <button onClick={() => handleBatchAction(detailBatch.id, "approved")} className="btn flex-1 py-3 rounded-xl bg-blue-500 hover:bg-blue-400 text-white font-semibold">Approve</button>}
              {detailBatch.status === "approved" && <button onClick={() => handleBatchAction(detailBatch.id, "issued")} className="btn flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold">Issue &amp; Deduct Stock</button>}
              <button onClick={() => setDetailBatch(null)} className="btn px-5 py-3 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Close</button>
            </div>
          </div>
        </Modal>
      )}
    </>
  );
}
