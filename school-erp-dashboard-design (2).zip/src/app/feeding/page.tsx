import { db } from "@/db";
import { feedingMenu, kitchenInventory, dailyRequestBatches, dailyRequestItems, students } from "@/db/schema";
import { desc, sql, asc, eq } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import StatCard from "@/components/StatCard";
import FeedingContent from "./FeedingContent";

export const dynamic = "force-dynamic";

export default async function FeedingPage() {
  const todayStr = new Date().toISOString().split("T")[0];
  const [studentCount] = await db.select({ count: sql<number>`count(*)::int` }).from(students);
  const menuItems = await db.select().from(feedingMenu).orderBy(desc(feedingMenu.date), feedingMenu.mealType).limit(50);
  const invItems = await db.select().from(kitchenInventory).orderBy(asc(kitchenInventory.itemName));

  // Fetch batches with their items
  const batches = await db.select().from(dailyRequestBatches).orderBy(desc(dailyRequestBatches.createdAt)).limit(50);
  const batchesWithItems = [];
  for (const b of batches) {
    const items = await db.select().from(dailyRequestItems).where(eq(dailyRequestItems.batchId, b.id));
    batchesWithItems.push({ ...b, items });
  }

  const todayBatchCount = batchesWithItems.filter(b => b.date === todayStr).length;

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6 space-y-6">
          <section className="fade-up">
            <div className="mb-6">
              <h2 className="text-3xl font-bold">Feeding Management</h2>
              <p className="text-slate-400">Manage menus, kitchen inventory, and daily requisitions</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <StatCard icon="fa-utensils" iconBg="bg-blue-500/20" iconColor="text-blue-400" label="Students Enrolled" value={studentCount.count.toLocaleString()} />
              <StatCard icon="fa-box" iconBg="bg-green-500/20" iconColor="text-green-400" label="Inventory Items" value={invItems.length} />
              <StatCard icon="fa-clipboard-list" iconBg="bg-amber-500/20" iconColor="text-amber-400" label="Today's Requests" value={todayBatchCount} />
            </div>
            <FeedingContent initialMenu={menuItems} initialInventory={invItems} initialBatches={batchesWithItems} />
          </section>
        </main>
      </div>
    </div>
  );
}
