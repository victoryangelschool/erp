import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import ReportsContent from "./ReportsContent";

export const dynamic = "force-dynamic";

export default function ReportsPage() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6 space-y-6">
          <ReportsContent />
        </main>
      </div>
    </div>
  );
}
