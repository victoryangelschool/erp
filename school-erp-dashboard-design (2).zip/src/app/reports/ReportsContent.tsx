"use client";

import { useState, useRef } from "react";
import { useSchool } from "@/components/SchoolProvider";
import { printWithHeader } from "@/lib/printHeader";

/* ---------- constants ---------- */
const financialReports = [
  {
    key: "income_statement",
    title: "Income Statement",
    description: "Revenue and expenses summary",
    icon: "fa-file-invoice",
    color: "blue",
  },
  {
    key: "balance_sheet",
    title: "Balance Sheet",
    description: "Assets, liabilities, and equity",
    icon: "fa-balance-scale",
    color: "green",
  },
  {
    key: "cash_flow",
    title: "Cash Flow Statement",
    description: "Inflows and outflows of cash",
    icon: "fa-exchange-alt",
    color: "amber",
  },
  {
    key: "budget_vs_actual",
    title: "Budget vs Actual",
    description: "Compare planned vs actual spending",
    icon: "fa-chart-pie",
    color: "purple",
  },
];

const academicReports = [
  {
    key: "student_performance",
    title: "Student Performance",
    description: "Individual and class results",
    icon: "fa-graduation-cap",
    color: "blue",
  },
  {
    key: "class_reports",
    title: "Class Reports",
    description: "Subject-wise class performance",
    icon: "fa-chalkboard",
    color: "green",
  },
  {
    key: "attendance_analysis",
    title: "Attendance Analysis",
    description: "Trends and patterns in attendance",
    icon: "fa-chart-line",
    color: "amber",
  },
  {
    key: "enrollment_trends",
    title: "Enrollment Trends",
    description: "Student enrollment over time",
    icon: "fa-users",
    color: "purple",
  },
];

const allReports = [...financialReports, ...academicReports];

const periodOptions = [
  { value: "this_month", label: "This Month" },
  { value: "last_month", label: "Last Month" },
  { value: "this_term", label: "This Term (Termly)" },
  { value: "last_quarter", label: "Last Quarter" },
  { value: "this_year", label: "This Year" },
  { value: "all_time", label: "All Time" },
];

const colorMap: Record<string, { bg: string; text: string }> = {
  blue: { bg: "bg-blue-500/20", text: "text-blue-400" },
  green: { bg: "bg-green-500/20", text: "text-green-400" },
  amber: { bg: "bg-amber-500/20", text: "text-amber-400" },
  purple: { bg: "bg-purple-500/20", text: "text-purple-400" },
};

/* ---------- types ---------- */
interface ReportRow {
  label: string;
  amount: number;
  count?: number;
  extra?: string;
}
interface ReportSection {
  heading: string;
  rows: ReportRow[];
  total: number | null;
}
interface ReportData {
  title: string;
  period: string;
  sections: ReportSection[];
  netIncome: number | null;
}

/* ========================================================== */
export default function ReportsContent() {
  const school = useSchool();
  const [reportType, setReportType] = useState("income_statement");
  const [period, setPeriod] = useState("this_year");
  const [term, setTerm] = useState("First Term");
  const [loading, setLoading] = useState(false);
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [error, setError] = useState("");
  const printRef = useRef<HTMLDivElement>(null);

  /* pick report type from the cards */
  const handleCardClick = (key: string) => {
    setReportType(key);
    setReportData(null);
    // auto-scroll to generator
    document.getElementById("report-generator")?.scrollIntoView({ behavior: "smooth" });
  };

  /* generate report */
  const handleGenerate = async () => {
    setLoading(true);
    setError("");
    setReportData(null);
    try {
      const params = new URLSearchParams({
        type: reportType,
        period,
        term,
      });
      const res = await fetch(`/api/reports?${params}`);
      if (!res.ok) throw new Error("Failed to generate report");
      const data = await res.json();
      setReportData(data);
    } catch (err) {
      console.error(err);
      setError("Failed to generate report. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  /* export as CSV */
  const handleExportCSV = () => {
    if (!reportData) return;
    const lines: string[] = [];
    lines.push(`"${reportData.title}"`);
    lines.push(`"Period: ${reportData.period}"`);
    lines.push("");
    for (const section of reportData.sections) {
      lines.push(`"${section.heading}"`);
      lines.push('"Item","Amount","Details"');
      for (const row of section.rows) {
        lines.push(
          `"${row.label}","${row.amount}","${row.extra || row.count || ""}"`
        );
      }
      if (section.total !== null) {
        lines.push(`"TOTAL","${section.total}",""`);
      }
      lines.push("");
    }
    if (reportData.netIncome !== null) {
      lines.push(`"Net Income / Balance","${reportData.netIncome}",""`);
    }
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${reportData.title.replace(/\s+/g, "_")}_${period}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  /* print */
  const handlePrint = () => {
    if (!printRef.current) return;
    printWithHeader(school, printRef.current.innerHTML, reportData?.title || "Report");
  };

  /* helper: format amount for display */
  const isMonetary = (key: string) =>
    [
      "income_statement",
      "balance_sheet",
      "cash_flow",
      "budget_vs_actual",
      "financial_summary",
      "payroll_summary",
    ].includes(key);

  const fmtAmt = (n: number) => {
    if (isMonetary(reportType)) {
      return `GHS ${n.toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })}`;
    }
    return n.toLocaleString();
  };

  const currentReportMeta = allReports.find((r) => r.key === reportType);

  /* ========= render ========= */
  return (
    <section className="fade-up">
      <div className="mb-6">
        <h2 className="text-3xl font-bold">Reports &amp; Analytics</h2>
        <p className="text-slate-400">
          Generate comprehensive reports and analyze data
        </p>
      </div>

      {/* ---- report-type cards ---- */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Financial */}
        <div className="card rounded-3xl p-6">
          <h3 className="text-2xl font-bold mb-5">Financial Reports</h3>
          <div className="space-y-3">
            {financialReports.map((r) => {
              const c = colorMap[r.color] || colorMap.blue;
              const active = reportType === r.key;
              return (
                <button
                  key={r.key}
                  onClick={() => handleCardClick(r.key)}
                  className={`w-full text-left p-4 rounded-xl transition border ${
                    active
                      ? "border-sky-500/50 bg-sky-500/10"
                      : "border-transparent bg-slate-900/50 hover:bg-slate-900"
                  }`}
                >
                  <div className="flex items-center">
                    <div className={`p-2 rounded-lg ${c.bg} ${c.text}`}>
                      <i className={`fas ${r.icon}`}></i>
                    </div>
                    <div className="ml-4 flex-1">
                      <p className="font-semibold">{r.title}</p>
                      <p className="text-sm text-slate-400">{r.description}</p>
                    </div>
                    {active && (
                      <i className="fas fa-check-circle text-sky-400 ml-2"></i>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Academic */}
        <div className="card rounded-3xl p-6">
          <h3 className="text-2xl font-bold mb-5">Academic Reports</h3>
          <div className="space-y-3">
            {academicReports.map((r) => {
              const c = colorMap[r.color] || colorMap.blue;
              const active = reportType === r.key;
              return (
                <button
                  key={r.key}
                  onClick={() => handleCardClick(r.key)}
                  className={`w-full text-left p-4 rounded-xl transition border ${
                    active
                      ? "border-sky-500/50 bg-sky-500/10"
                      : "border-transparent bg-slate-900/50 hover:bg-slate-900"
                  }`}
                >
                  <div className="flex items-center">
                    <div className={`p-2 rounded-lg ${c.bg} ${c.text}`}>
                      <i className={`fas ${r.icon}`}></i>
                    </div>
                    <div className="ml-4 flex-1">
                      <p className="font-semibold">{r.title}</p>
                      <p className="text-sm text-slate-400">{r.description}</p>
                    </div>
                    {active && (
                      <i className="fas fa-check-circle text-sky-400 ml-2"></i>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ---- report generator ---- */}
      <div id="report-generator" className="card rounded-3xl p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-5">
          <div>
            <h3 className="text-2xl font-bold">Report Generator</h3>
            {currentReportMeta && (
              <p className="text-sm text-slate-400 mt-1">
                Selected:{" "}
                <span className="text-sky-300 font-semibold">
                  {currentReportMeta.title}
                </span>
              </p>
            )}
          </div>
          {reportData && (
            <div className="flex gap-2">
              <button
                onClick={handleExportCSV}
                className="btn px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold text-sm"
              >
                <i className="fas fa-file-csv mr-2"></i>Export CSV
              </button>
              <button
                onClick={handlePrint}
                className="btn px-4 py-2 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-semibold text-sm"
              >
                <i className="fas fa-print mr-2"></i>Print
              </button>
            </div>
          )}
        </div>

        {/* controls */}
        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="text-sm text-slate-300">Report Type</label>
            <select
              className="select mt-2"
              value={reportType}
              onChange={(e) => {
                setReportType(e.target.value);
                setReportData(null);
              }}
            >
              <optgroup label="Financial Reports">
                <option value="income_statement">Income Statement</option>
                <option value="balance_sheet">Balance Sheet</option>
                <option value="cash_flow">Cash Flow Statement</option>
                <option value="budget_vs_actual">Budget vs Actual</option>
              </optgroup>
              <optgroup label="Academic Reports">
                <option value="student_performance">Student Performance</option>
                <option value="class_reports">Class Reports</option>
                <option value="attendance_analysis">Attendance Analysis</option>
                <option value="enrollment_trends">Enrollment Trends</option>
              </optgroup>
              <optgroup label="Other">
                <option value="payroll_summary">Payroll Summary</option>
              </optgroup>
            </select>
          </div>
          <div>
            <label className="text-sm text-slate-300">Period</label>
            <select
              className="select mt-2"
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
            >
              {periodOptions.map((p) => (
                <option key={p.value} value={p.value}>
                  {p.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-sm text-slate-300">Term</label>
            <select
              className="select mt-2"
              value={term}
              onChange={(e) => setTerm(e.target.value)}
            >
              <option value="First Term">First Term</option>
              <option value="Second Term">Second Term</option>
              <option value="Third Term">Third Term</option>
            </select>
          </div>
        </div>

        <button
          onClick={handleGenerate}
          disabled={loading}
          className="btn mt-6 w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold disabled:opacity-50"
        >
          {loading ? (
            <>
              <i className="fas fa-spinner fa-spin mr-2"></i>Generating…
            </>
          ) : (
            <>
              <i className="fas fa-file-alt mr-2"></i>Generate Report
            </>
          )}
        </button>

        {/* error */}
        {error && (
          <div className="mt-4 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400">
            <i className="fas fa-exclamation-circle mr-2"></i>
            {error}
          </div>
        )}

        {/* rendered report */}
        {reportData && (
          <div className="mt-6">
            <div
              ref={printRef}
              className="rounded-2xl bg-slate-900/60 border border-slate-700/50 p-6"
            >
              {/* header */}
              <div className="border-b border-slate-700 pb-4 mb-6">
                <h2 className="text-2xl font-bold">{reportData.title}</h2>
                <p className="text-slate-400 text-sm mt-1">
                  Period: {reportData.period}
                </p>
                <p className="text-slate-500 text-xs mt-1">
                  Generated on {new Date().toLocaleDateString()} at{" "}
                  {new Date().toLocaleTimeString()}
                </p>
              </div>

              {/* sections */}
              {reportData.sections.map((section, si) => (
                <div key={si} className="mb-8">
                  <h4 className="text-lg font-bold mb-3 text-sky-300">
                    {section.heading}
                  </h4>

                  {section.rows.length === 0 ? (
                    <p className="text-slate-400 italic py-4">
                      No data available for this period.
                    </p>
                  ) : (
                    <div className="table-wrap overflow-auto">
                      <table className="min-w-full text-sm">
                        <thead className="text-slate-300">
                          <tr className="border-b border-slate-700">
                            <th className="py-2 pr-4 text-left">Item</th>
                            <th className="py-2 pr-4 text-right">
                              {isMonetary(reportType) ? "Amount" : "Value"}
                            </th>
                            {section.rows.some((r) => r.extra || r.count) && (
                              <th className="py-2 pr-4 text-left">Details</th>
                            )}
                          </tr>
                        </thead>
                        <tbody>
                          {section.rows.map((row, ri) => (
                            <tr
                              key={ri}
                              className="border-b border-slate-800/50"
                            >
                              <td className="py-3 pr-4 font-medium">
                                {row.label}
                              </td>
                              <td
                                className={`py-3 pr-4 text-right font-semibold whitespace-nowrap ${
                                  isMonetary(reportType)
                                    ? row.amount >= 0
                                      ? "text-emerald-400"
                                      : "text-red-400"
                                    : ""
                                }`}
                              >
                                {fmtAmt(row.amount)}
                              </td>
                              {section.rows.some(
                                (r) => r.extra || r.count
                              ) && (
                                <td className="py-3 pr-4 text-slate-400 text-sm">
                                  {row.extra ||
                                    (row.count
                                      ? `${row.count} entries`
                                      : "")}
                                </td>
                              )}
                            </tr>
                          ))}
                          {section.total !== null && (
                            <tr className="border-t-2 border-slate-600">
                              <td className="py-3 pr-4 font-bold text-white">
                                TOTAL
                              </td>
                              <td className="py-3 pr-4 text-right font-bold text-white whitespace-nowrap">
                                {fmtAmt(section.total)}
                              </td>
                              {section.rows.some(
                                (r) => r.extra || r.count
                              ) && <td></td>}
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              ))}

              {/* net income / bottom line */}
              {reportData.netIncome !== null && (
                <div
                  className={`rounded-xl p-4 mt-2 flex items-center justify-between ${
                    reportData.netIncome >= 0
                      ? "bg-emerald-500/10 border border-emerald-500/30"
                      : "bg-red-500/10 border border-red-500/30"
                  }`}
                >
                  <span className="font-bold text-lg">
                    {reportType === "cash_flow"
                      ? "Net Cash Flow"
                      : "Net Income / Balance"}
                  </span>
                  <span
                    className={`font-bold text-xl ${
                      reportData.netIncome >= 0
                        ? "text-emerald-400"
                        : "text-red-400"
                    }`}
                  >
                    {fmtAmt(reportData.netIncome)}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
