"use client";

import { useState } from "react";

interface AttendanceStats {
  totalStudents: number;
  presentToday: number;
  absentToday: number;
  attendanceRate: number;
}

interface AttendanceRecord {
  id: number;
  date: string | null;
  status: string | null;
  timeIn: string | null;
  timeOut: string | null;
  studentId: number | null;
}

interface Class {
  id: number;
  name: string;
}

interface Student {
  id: number;
  studentId: string;
  firstName: string;
  lastName: string;
}

interface AttendanceFormProps {
  stats: AttendanceStats;
  recentRecords: AttendanceRecord[];
  classes: Class[];
  students: Student[];
}

export default function AttendanceForm({
  stats,
  recentRecords,
  classes,
  students,
}: AttendanceFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split("T")[0],
    classId: "",
    studentId: "",
    status: "present",
    timeIn: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch("/api/attendance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        alert("Attendance marked successfully!");
        setFormData({
          date: new Date().toISOString().split("T")[0],
          classId: "",
          studentId: "",
          status: "present",
          timeIn: "",
        });
      }
    } catch (error) {
      console.error("Error marking attendance:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="fade-up">
      <div className="mb-6">
        <h2 className="text-3xl font-bold">Attendance Tracking</h2>
        <p className="text-slate-400">Track daily attendance for students and staff</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card rounded-3xl p-6">
          <h3 className="text-2xl font-bold mb-5">Mark Attendance</h3>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4">
              <div>
                <label className="text-sm text-slate-300">Date</label>
                <input
                  type="date"
                  className="input mt-2"
                  value={formData.date}
                  onChange={(e) =>
                    setFormData({ ...formData, date: e.target.value })
                  }
                  required
                />
              </div>
              <div>
                <label className="text-sm text-slate-300">Class</label>
                <select
                  className="select mt-2"
                  value={formData.classId}
                  onChange={(e) =>
                    setFormData({ ...formData, classId: e.target.value })
                  }
                >
                  <option value="">Select Class</option>
                  {classes.map((cls) => (
                    <option key={cls.id} value={cls.id}>
                      {cls.name}
                    </option>
                  ))}
                  <option value="staff">Staff</option>
                </select>
              </div>
              <div>
                <label className="text-sm text-slate-300">Student</label>
                <select
                  className="select mt-2"
                  value={formData.studentId}
                  onChange={(e) =>
                    setFormData({ ...formData, studentId: e.target.value })
                  }
                  required
                >
                  <option value="">Select Student</option>
                  {students.map((student) => (
                    <option key={student.id} value={student.id}>
                      {student.firstName} {student.lastName} ({student.studentId})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm text-slate-300">Status</label>
                <select
                  className="select mt-2"
                  value={formData.status}
                  onChange={(e) =>
                    setFormData({ ...formData, status: e.target.value })
                  }
                  required
                >
                  <option value="present">Present</option>
                  <option value="absent">Absent</option>
                  <option value="late">Late</option>
                  <option value="excused">Excused</option>
                </select>
              </div>
              <div>
                <label className="text-sm text-slate-300">Time In</label>
                <input
                  type="time"
                  className="input mt-2"
                  value={formData.timeIn}
                  onChange={(e) =>
                    setFormData({ ...formData, timeIn: e.target.value })
                  }
                />
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold disabled:opacity-50"
              >
                {isSubmitting ? "Marking..." : "Mark Attendance"}
              </button>
            </div>
          </form>
        </div>

        <div className="card rounded-3xl p-6">
          <h3 className="text-2xl font-bold mb-5">Attendance Summary</h3>
          <div className="space-y-4">
            <div className="flex justify-between py-2 border-b border-slate-700">
              <span>Total Students</span>
              <span className="font-semibold">{stats.totalStudents.toLocaleString()}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-700">
              <span>Present Today</span>
              <span className="font-semibold text-emerald-400">
                {stats.presentToday.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-700">
              <span>Absent Today</span>
              <span className="font-semibold text-red-400">
                {stats.absentToday.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-700">
              <span>Attendance Rate</span>
              <span className="font-semibold">{stats.attendanceRate}%</span>
            </div>
          </div>

          <div className="mt-6">
            <h4 className="font-bold mb-3">Recent Attendance</h4>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {recentRecords.length === 0 ? (
                <p className="text-slate-400 text-sm">No recent attendance records</p>
              ) : (
                recentRecords.slice(0, 5).map((record) => (
                  <div
                    key={record.id}
                    className="flex justify-between text-sm p-2 rounded bg-slate-900/50"
                  >
                    <span>{record.date}</span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-xs ${
                        record.status === "present"
                          ? "bg-emerald-500/20 text-emerald-400"
                          : record.status === "absent"
                          ? "bg-red-500/20 text-red-400"
                          : "bg-amber-500/20 text-amber-400"
                      }`}
                    >
                      {record.status}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
