import { db } from "@/db";
import { users, staff, classes } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import UsersContent from "./UsersContent";

export const dynamic = "force-dynamic";

export default async function UsersPage() {
  const [usersList, staffList, classesList] = await Promise.all([
    db.select({ id: users.id, username: users.username, role: users.role, fullName: users.fullName, staffId: users.staffId, classId: users.classId, isActive: users.isActive, createdAt: users.createdAt }).from(users).orderBy(asc(users.username)),
    db.select({ id: staff.id, staffId: staff.staffId, firstName: staff.firstName, lastName: staff.lastName }).from(staff).where(eq(staff.status, "active")),
    db.select().from(classes).orderBy(asc(classes.name)),
  ]);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6">
          <UsersContent initialUsers={usersList} staffList={staffList} classes={classesList} />
        </main>
      </div>
    </div>
  );
}
