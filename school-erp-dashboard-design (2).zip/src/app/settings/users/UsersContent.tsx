"use client";

import { useState } from "react";
import Link from "next/link";
import Modal from "@/components/Modal";

interface User { id: number; username: string; role: string; fullName: string; staffId: number | null; classId: number | null; isActive: boolean | null; createdAt: Date | null; }
interface Staff { id: number; staffId: string; firstName: string; lastName: string; }
interface Class { id: number; name: string; }

const ROLES = [
  { value: "admin", label: "Administrator", desc: "Full access to all modules", color: "bg-red-500/20 text-red-400" },
  { value: "headmaster", label: "Headmaster", desc: "Full access, read-only finance", color: "bg-purple-500/20 text-purple-400" },
  { value: "finance", label: "Finance Officer", desc: "Finance, billing, payroll only", color: "bg-amber-500/20 text-amber-400" },
  { value: "registrar", label: "Registrar", desc: "Student records, admissions, attendance", color: "bg-blue-500/20 text-blue-400" },
  { value: "teacher", label: "Teacher", desc: "Own class attendance, grading, CA only", color: "bg-green-500/20 text-green-400" },
];

export default function UsersContent({ initialUsers, staffList, classes: cls }: { initialUsers: User[]; staffList: Staff[]; classes: Class[] }) {
  const [usersList, setUsersList] = useState<User[]>(initialUsers);
  const [modal, setModal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ username: "", password: "", role: "teacher", fullName: "", staffId: "", classId: "" });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    try {
      const res = await fetch("/api/users", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      if (res.ok) { const u = await res.json(); setUsersList([...usersList, u]); setModal(false); setForm({ username: "", password: "", role: "teacher", fullName: "", staffId: "", classId: "" }); }
      else { const d = await res.json(); alert(d.error || "Failed"); }
    } catch (err) { console.error(err); } finally { setBusy(false); }
  };

  const toggleActive = async (u: User) => {
    const res = await fetch(`/api/users/${u.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ isActive: !u.isActive }) });
    if (res.ok) { const updated = await res.json(); setUsersList(usersList.map(x => x.id === updated.id ? updated : x)); }
  };

  const handleDelete = async (u: User) => {
    if (!confirm(`Delete user "${u.username}"? This cannot be undone.`)) return;
    const res = await fetch(`/api/users/${u.id}`, { method: "DELETE" });
    if (res.ok) setUsersList(usersList.filter(x => x.id !== u.id));
  };

  const cName = (id: number | null) => cls.find(c => c.id === id)?.name || "—";
  const roleBadge = (r: string) => { const role = ROLES.find(ro => ro.value === r); return <span className={`px-2 py-1 rounded-full text-xs font-semibold ${role?.color || "bg-slate-500/20 text-slate-400"}`}>{role?.label || r}</span>; };

  return (
    <section className="fade-up space-y-6">
      <div className="flex justify-between gap-4">
        <div>
          <Link href="/settings" className="text-sky-400 hover:text-sky-300 text-sm mb-2 inline-block"><i className="fas fa-arrow-left mr-1"></i> Back to Settings</Link>
          <h2 className="text-3xl font-bold">User Accounts &amp; Permissions</h2>
          <p className="text-slate-400">Create, manage and control access for all system users</p>
        </div>
        <button onClick={() => setModal(true)} className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold self-start"><i className="fas fa-plus mr-2"></i>Add User</button>
      </div>

      {/* Role legend */}
      <div className="card rounded-3xl p-4">
        <p className="text-sm font-semibold text-slate-300 mb-2">Role Permissions</p>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
          {ROLES.map(r => (
            <div key={r.value} className="p-3 rounded-xl bg-slate-900/50">
              {roleBadge(r.value)}
              <p className="text-xs text-slate-400 mt-1">{r.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="card rounded-3xl p-6">
        {usersList.length === 0 ? (
          <div className="text-center py-16"><i className="fas fa-users-cog text-4xl text-slate-600 mb-4"></i><p className="text-slate-400">No user accounts. Click &quot;Add User&quot; to create one.</p></div>
        ) : (
          <div className="table-wrap overflow-auto"><table className="min-w-full text-left text-sm"><thead className="text-slate-300"><tr className="border-b border-slate-700">
            <th className="py-3 pr-3">Username</th><th className="py-3 pr-3">Full Name</th><th className="py-3 pr-3">Role</th><th className="py-3 pr-3">Assigned Class</th><th className="py-3 pr-3">Status</th><th className="py-3 pr-3 text-right">Actions</th>
          </tr></thead><tbody>
            {usersList.map(u => (
              <tr key={u.id} className="border-b border-slate-800/70">
                <td className="py-3 pr-3 font-mono">{u.username}</td>
                <td className="py-3 pr-3 font-semibold">{u.fullName}</td>
                <td className="py-3 pr-3">{roleBadge(u.role)}</td>
                <td className="py-3 pr-3">{u.classId ? cName(u.classId) : "—"}</td>
                <td className="py-3 pr-3"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${u.isActive ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}>{u.isActive ? "Active" : "Disabled"}</span></td>
                <td className="py-3 pr-3 text-right space-x-2">
                  <button onClick={() => toggleActive(u)} className={`text-xs px-3 py-1 rounded-lg font-semibold ${u.isActive ? "bg-amber-500/10 text-amber-400 hover:bg-amber-500/20" : "bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20"}`}>{u.isActive ? "Disable" : "Enable"}</button>
                  <button onClick={() => handleDelete(u)} className="text-red-400 hover:text-red-300" title="Delete"><i className="fas fa-trash"></i></button>
                </td>
              </tr>
            ))}
          </tbody></table></div>
        )}
      </div>

      <Modal isOpen={modal} onClose={() => setModal(false)} title="Create User Account">
        <form onSubmit={handleSubmit}>
          <div className="grid md:grid-cols-2 gap-4">
            <div><label className="text-sm text-slate-300">Username *</label><input className="input mt-2" placeholder="e.g. jdoe" value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Password *</label><input type="password" className="input mt-2" placeholder="Min 6 characters" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required minLength={6} /></div>
            <div><label className="text-sm text-slate-300">Full Name *</label><input className="input mt-2" value={form.fullName} onChange={e => setForm({ ...form, fullName: e.target.value })} required /></div>
            <div><label className="text-sm text-slate-300">Role *</label>
              <select className="select mt-2" value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}>
                {ROLES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
              </select>
            </div>
            <div><label className="text-sm text-slate-300">Link to Staff</label>
              <select className="select mt-2" value={form.staffId} onChange={e => setForm({ ...form, staffId: e.target.value })}>
                <option value="">None</option>{staffList.map(s => <option key={s.id} value={s.id}>{s.firstName} {s.lastName} ({s.staffId})</option>)}
              </select>
            </div>
            <div><label className="text-sm text-slate-300">Assigned Class <span className="text-xs text-slate-500">(for teachers)</span></label>
              <select className="select mt-2" value={form.classId} onChange={e => setForm({ ...form, classId: e.target.value })}>
                <option value="">None</option>{cls.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
          </div>
          <div className="mt-4 p-3 rounded-xl bg-slate-900/60 border border-slate-700/40 text-sm text-slate-400">
            <p><strong>Teacher:</strong> Can only mark attendance and enter grades for their assigned class.</p>
            <p className="mt-1"><strong>Finance:</strong> Billing, payments, payroll, and financial reports only.</p>
            <p className="mt-1"><strong>Admin:</strong> Unrestricted access to all modules.</p>
          </div>
          <div className="mt-5 flex gap-4">
            <button type="submit" disabled={busy} className="btn flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold disabled:opacity-50">{busy ? "Creating…" : "Create User"}</button>
            <button type="button" onClick={() => setModal(false)} className="btn px-5 py-3 rounded-xl bg-slate-600 hover:bg-slate-500 text-white">Cancel</button>
          </div>
        </form>
      </Modal>
    </section>
  );
}
