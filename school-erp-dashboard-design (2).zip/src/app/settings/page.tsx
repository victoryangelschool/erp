import { db } from "@/db";
import { classes, subjects, incomeItems, expenseItems } from "@/db/schema";
import { asc } from "drizzle-orm";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import SettingsContent from "./SettingsContent";

export const dynamic = "force-dynamic";

async function getData() {
  const [classesList, subjectsList, incomeItemsList, expenseItemsList] =
    await Promise.all([
      db.select().from(classes).orderBy(asc(classes.name)),
      db.select().from(subjects).orderBy(asc(subjects.name)),
      db.select().from(incomeItems).orderBy(asc(incomeItems.name)),
      db.select().from(expenseItems).orderBy(asc(expenseItems.name)),
    ]);

  return { classesList, subjectsList, incomeItemsList, expenseItemsList };
}

export default async function SettingsPage() {
  const data = await getData();

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 lg:ml-80">
        <Header />
        <main className="p-4 sm:p-6 space-y-6">
          <SettingsContent
            initialClasses={data.classesList}
            initialSubjects={data.subjectsList}
            initialIncomeItems={data.incomeItemsList}
            initialExpenseItems={data.expenseItemsList}
          />
        </main>
      </div>
    </div>
  );
}
