"use client";

import { useState } from "react";
import Modal from "@/components/Modal";

/* ---------- types ---------- */
interface ClassItem {
  id: number;
  name: string;
  level: string | null;
  capacity: number | null;
}
interface SubjectItem {
  id: number;
  name: string;
  code: string | null;
  description: string | null;
  classId: number | null;
}
interface CategoryItem {
  id: number;
  name: string;
  description: string | null;
}

interface Props {
  initialClasses: ClassItem[];
  initialSubjects: SubjectItem[];
  initialIncomeItems: CategoryItem[];
  initialExpenseItems: CategoryItem[];
}

/* ========================================================== */
export default function SettingsContent({
  initialClasses,
  initialSubjects,
  initialIncomeItems,
  initialExpenseItems,
}: Props) {
  const [activeTab, setActiveTab] = useState<
    "classes" | "subjects" | "incomeItems" | "expenseItems"
  >("classes");

  /* ---- classes ---- */
  const [classesList, setClassesList] = useState<ClassItem[]>(initialClasses);
  const [classModal, setClassModal] = useState(false);
  const [editingClass, setEditingClass] = useState<ClassItem | null>(null);
  const [classForm, setClassForm] = useState({ name: "", level: "", capacity: "40" });
  const [classSubmitting, setClassSubmitting] = useState(false);

  /* ---- subjects ---- */
  const [subjectsList, setSubjectsList] = useState<SubjectItem[]>(initialSubjects);
  const [subjectModal, setSubjectModal] = useState(false);
  const [editingSubject, setEditingSubject] = useState<SubjectItem | null>(null);
  const [subjectForm, setSubjectForm] = useState({
    name: "",
    code: "",
    description: "",
    classId: "",
  });
  const [subjectSubmitting, setSubjectSubmitting] = useState(false);

  /* ---- income items ---- */
  const [incItems, setIncItems] = useState<CategoryItem[]>(initialIncomeItems);
  const [incModal, setIncModal] = useState(false);
  const [incForm, setIncForm] = useState({ name: "", description: "" });
  const [incSubmitting, setIncSubmitting] = useState(false);

  /* ---- expense items ---- */
  const [expItems, setExpItems] = useState<CategoryItem[]>(initialExpenseItems);
  const [expModal, setExpModal] = useState(false);
  const [expForm, setExpForm] = useState({ name: "", description: "" });
  const [expSubmitting, setExpSubmitting] = useState(false);

  /* ========= handlers ========= */

  // CLASSES
  const openClassAdd = () => {
    setEditingClass(null);
    setClassForm({ name: "", level: "", capacity: "40" });
    setClassModal(true);
  };
  const openClassEdit = (c: ClassItem) => {
    setEditingClass(c);
    setClassForm({
      name: c.name,
      level: c.level || "",
      capacity: String(c.capacity ?? 40),
    });
    setClassModal(true);
  };
  const handleClassSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setClassSubmitting(true);
    try {
      if (editingClass) {
        const res = await fetch(`/api/classes/${editingClass.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(classForm),
        });
        if (res.ok) {
          const updated = await res.json();
          setClassesList(classesList.map((c) => (c.id === updated.id ? updated : c)));
        }
      } else {
        const res = await fetch("/api/classes", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(classForm),
        });
        if (res.ok) {
          const created = await res.json();
          setClassesList([...classesList, created].sort((a, b) =>
            a.name.localeCompare(b.name)
          ));
        }
      }
      setClassModal(false);
    } catch (err) {
      console.error(err);
    } finally {
      setClassSubmitting(false);
    }
  };
  const handleClassDelete = async (id: number) => {
    if (!confirm("Delete this class? Students assigned to it will become unlinked.")) return;
    try {
      const res = await fetch(`/api/classes/${id}`, { method: "DELETE" });
      if (res.ok) setClassesList(classesList.filter((c) => c.id !== id));
      else {
        const data = await res.json();
        alert(data.error || "Failed to delete");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // SUBJECTS
  const openSubjectAdd = () => {
    setEditingSubject(null);
    setSubjectForm({ name: "", code: "", description: "", classId: "" });
    setSubjectModal(true);
  };
  const openSubjectEdit = (s: SubjectItem) => {
    setEditingSubject(s);
    setSubjectForm({
      name: s.name,
      code: s.code || "",
      description: s.description || "",
      classId: s.classId ? String(s.classId) : "",
    });
    setSubjectModal(true);
  };
  const handleSubjectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubjectSubmitting(true);
    try {
      if (editingSubject) {
        const res = await fetch(`/api/subjects/${editingSubject.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(subjectForm),
        });
        if (res.ok) {
          const updated = await res.json();
          setSubjectsList(subjectsList.map((s) => (s.id === updated.id ? updated : s)));
        }
      } else {
        const res = await fetch("/api/subjects", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(subjectForm),
        });
        if (res.ok) {
          const created = await res.json();
          setSubjectsList([...subjectsList, created].sort((a, b) =>
            a.name.localeCompare(b.name)
          ));
        }
      }
      setSubjectModal(false);
    } catch (err) {
      console.error(err);
    } finally {
      setSubjectSubmitting(false);
    }
  };
  const handleSubjectDelete = async (id: number) => {
    if (!confirm("Delete this subject?")) return;
    try {
      const res = await fetch(`/api/subjects/${id}`, { method: "DELETE" });
      if (res.ok) setSubjectsList(subjectsList.filter((s) => s.id !== id));
      else {
        const data = await res.json();
        alert(data.error || "Failed to delete");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // INCOME ITEMS
  const handleIncSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIncSubmitting(true);
    try {
      const res = await fetch("/api/income-items", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(incForm),
      });
      if (res.ok) {
        const created = await res.json();
        setIncItems([...incItems, created].sort((a, b) => a.name.localeCompare(b.name)));
        setIncModal(false);
        setIncForm({ name: "", description: "" });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIncSubmitting(false);
    }
  };
  const handleIncDelete = async (id: number) => {
    if (!confirm("Delete this income item?")) return;
    try {
      const res = await fetch(`/api/income-items/${id}`, { method: "DELETE" });
      if (res.ok) setIncItems(incItems.filter((i) => i.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  // EXPENSE ITEMS
  const handleExpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setExpSubmitting(true);
    try {
      const res = await fetch("/api/expense-items", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(expForm),
      });
      if (res.ok) {
        const created = await res.json();
        setExpItems([...expItems, created].sort((a, b) => a.name.localeCompare(b.name)));
        setExpModal(false);
        setExpForm({ name: "", description: "" });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setExpSubmitting(false);
    }
  };
  const handleExpDelete = async (id: number) => {
    if (!confirm("Delete this expense item?")) return;
    try {
      const res = await fetch(`/api/expense-items/${id}`, { method: "DELETE" });
      if (res.ok) setExpItems(expItems.filter((i) => i.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  const getClassName = (classId: number | null) => {
    if (!classId) return "All Classes";
    return classesList.find((c) => c.id === classId)?.name || "—";
  };

  /* ========= tab definitions ========= */
  const tabs = [
    { key: "classes" as const, label: "Classes", icon: "fa-chalkboard" },
    { key: "subjects" as const, label: "Subjects", icon: "fa-book" },
    { key: "incomeItems" as const, label: "Income Items", icon: "fa-arrow-down" },
    { key: "expenseItems" as const, label: "Expense Items", icon: "fa-arrow-up" },
  ];

  /* ========= render ========= */
  return (
    <section className="fade-up">
      <div className="mb-6">
        <h2 className="text-3xl font-bold">Settings</h2>
        <p className="text-slate-400">
          Manage classes, subjects, income items and expense items
        </p>
      </div>

      {/* tab bar */}
      <div className="flex flex-wrap gap-2 mb-6">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setActiveTab(t.key)}
            className={`btn px-5 py-3 rounded-xl font-semibold transition ${
              activeTab === t.key
                ? "bg-sky-500 text-white"
                : "bg-white/5 border border-white/10 hover:bg-white/10"
            }`}
          >
            <i className={`fas ${t.icon} mr-2`}></i>
            {t.label}
          </button>
        ))}
      </div>

      {/* -------- CLASSES -------- */}
      {activeTab === "classes" && (
        <div className="card rounded-3xl p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-5">
            <div>
              <h3 className="text-2xl font-bold">Classes</h3>
              <p className="text-slate-400 text-sm">
                {classesList.length} class{classesList.length !== 1 && "es"} configured
              </p>
            </div>
            <button
              onClick={openClassAdd}
              className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"
            >
              <i className="fas fa-plus mr-2"></i>Add Class
            </button>
          </div>

          {classesList.length === 0 ? (
            <p className="text-slate-400 text-center py-10">
              No classes yet. Click &quot;Add Class&quot; to get started.
            </p>
          ) : (
            <div className="table-wrap overflow-auto">
              <table className="min-w-full text-left text-sm">
                <thead className="text-slate-300">
                  <tr className="border-b border-slate-700">
                    <th className="py-3 pr-4">#</th>
                    <th className="py-3 pr-4">Name</th>
                    <th className="py-3 pr-4">Level</th>
                    <th className="py-3 pr-4">Capacity</th>
                    <th className="py-3 pr-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {classesList.map((c, i) => (
                    <tr key={c.id} className="border-b border-slate-800/70">
                      <td className="py-3 pr-4 text-slate-400">{i + 1}</td>
                      <td className="py-3 pr-4 font-semibold">{c.name}</td>
                      <td className="py-3 pr-4">{c.level || "—"}</td>
                      <td className="py-3 pr-4">{c.capacity ?? 40}</td>
                      <td className="py-3 pr-4 text-right space-x-3">
                        <button
                          onClick={() => openClassEdit(c)}
                          className="text-sky-400 hover:text-sky-300"
                        >
                          <i className="fas fa-edit"></i>
                        </button>
                        <button
                          onClick={() => handleClassDelete(c.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* -------- SUBJECTS -------- */}
      {activeTab === "subjects" && (
        <div className="card rounded-3xl p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-5">
            <div>
              <h3 className="text-2xl font-bold">Subjects</h3>
              <p className="text-slate-400 text-sm">
                {subjectsList.length} subject{subjectsList.length !== 1 && "s"} configured
              </p>
            </div>
            <button
              onClick={openSubjectAdd}
              className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"
            >
              <i className="fas fa-plus mr-2"></i>Add Subject
            </button>
          </div>

          {subjectsList.length === 0 ? (
            <p className="text-slate-400 text-center py-10">
              No subjects yet. Click &quot;Add Subject&quot; to get started.
            </p>
          ) : (
            <div className="table-wrap overflow-auto">
              <table className="min-w-full text-left text-sm">
                <thead className="text-slate-300">
                  <tr className="border-b border-slate-700">
                    <th className="py-3 pr-4">#</th>
                    <th className="py-3 pr-4">Name</th>
                    <th className="py-3 pr-4">Code</th>
                    <th className="py-3 pr-4">Class</th>
                    <th className="py-3 pr-4">Description</th>
                    <th className="py-3 pr-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {subjectsList.map((s, i) => (
                    <tr key={s.id} className="border-b border-slate-800/70">
                      <td className="py-3 pr-4 text-slate-400">{i + 1}</td>
                      <td className="py-3 pr-4 font-semibold">{s.name}</td>
                      <td className="py-3 pr-4">{s.code || "—"}</td>
                      <td className="py-3 pr-4">{getClassName(s.classId)}</td>
                      <td className="py-3 pr-4 max-w-[200px] truncate">
                        {s.description || "—"}
                      </td>
                      <td className="py-3 pr-4 text-right space-x-3">
                        <button
                          onClick={() => openSubjectEdit(s)}
                          className="text-sky-400 hover:text-sky-300"
                        >
                          <i className="fas fa-edit"></i>
                        </button>
                        <button
                          onClick={() => handleSubjectDelete(s.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* -------- INCOME ITEMS -------- */}
      {activeTab === "incomeItems" && (
        <div className="card rounded-3xl p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-5">
            <div>
              <h3 className="text-2xl font-bold">Income Items</h3>
              <p className="text-slate-400 text-sm">
                Categories of income used when receiving payments
              </p>
            </div>
            <button
              onClick={() => {
                setIncForm({ name: "", description: "" });
                setIncModal(true);
              }}
              className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"
            >
              <i className="fas fa-plus mr-2"></i>Add Income Item
            </button>
          </div>

          {incItems.length === 0 ? (
            <p className="text-slate-400 text-center py-10">
              No income items yet. Add items like &quot;School Fees&quot;, &quot;Donation&quot;, etc.
            </p>
          ) : (
            <div className="table-wrap overflow-auto">
              <table className="min-w-full text-left text-sm">
                <thead className="text-slate-300">
                  <tr className="border-b border-slate-700">
                    <th className="py-3 pr-4">#</th>
                    <th className="py-3 pr-4">Name</th>
                    <th className="py-3 pr-4">Description</th>
                    <th className="py-3 pr-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {incItems.map((item, i) => (
                    <tr key={item.id} className="border-b border-slate-800/70">
                      <td className="py-3 pr-4 text-slate-400">{i + 1}</td>
                      <td className="py-3 pr-4 font-semibold">
                        <span className="inline-flex items-center">
                          <span className="w-2 h-2 rounded-full bg-emerald-400 mr-2"></span>
                          {item.name}
                        </span>
                      </td>
                      <td className="py-3 pr-4">{item.description || "—"}</td>
                      <td className="py-3 pr-4 text-right">
                        <button
                          onClick={() => handleIncDelete(item.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* -------- EXPENSE ITEMS -------- */}
      {activeTab === "expenseItems" && (
        <div className="card rounded-3xl p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-5">
            <div>
              <h3 className="text-2xl font-bold">Expense Items</h3>
              <p className="text-slate-400 text-sm">
                Categories of expense used when making payments
              </p>
            </div>
            <button
              onClick={() => {
                setExpForm({ name: "", description: "" });
                setExpModal(true);
              }}
              className="btn px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold"
            >
              <i className="fas fa-plus mr-2"></i>Add Expense Item
            </button>
          </div>

          {expItems.length === 0 ? (
            <p className="text-slate-400 text-center py-10">
              No expense items yet. Add items like &quot;Utilities&quot;, &quot;Supplies&quot;, etc.
            </p>
          ) : (
            <div className="table-wrap overflow-auto">
              <table className="min-w-full text-left text-sm">
                <thead className="text-slate-300">
                  <tr className="border-b border-slate-700">
                    <th className="py-3 pr-4">#</th>
                    <th className="py-3 pr-4">Name</th>
                    <th className="py-3 pr-4">Description</th>
                    <th className="py-3 pr-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {expItems.map((item, i) => (
                    <tr key={item.id} className="border-b border-slate-800/70">
                      <td className="py-3 pr-4 text-slate-400">{i + 1}</td>
                      <td className="py-3 pr-4 font-semibold">
                        <span className="inline-flex items-center">
                          <span className="w-2 h-2 rounded-full bg-red-400 mr-2"></span>
                          {item.name}
                        </span>
                      </td>
                      <td className="py-3 pr-4">{item.description || "—"}</td>
                      <td className="py-3 pr-4 text-right">
                        <button
                          onClick={() => handleExpDelete(item.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ========= MODALS ========= */}

      {/* Class modal */}
      <Modal
        isOpen={classModal}
        onClose={() => setClassModal(false)}
        title={editingClass ? "Edit Class" : "Add Class"}
      >
        <form onSubmit={handleClassSubmit}>
          <div className="grid gap-4">
            <div>
              <label className="text-sm text-slate-300">Class Name *</label>
              <input
                className="input mt-2"
                placeholder="e.g. JHS 1A"
                value={classForm.name}
                onChange={(e) => setClassForm({ ...classForm, name: e.target.value })}
                required
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">Level</label>
              <select
                className="select mt-2"
                value={classForm.level}
                onChange={(e) => setClassForm({ ...classForm, level: e.target.value })}
              >
                <option value="">Select Level</option>
                <option value="Creche">Crèche</option>
                <option value="Nursery">Nursery</option>
                <option value="Kindergarten">Kindergarten</option>
                <option value="Primary">Primary</option>
                <option value="Junior High School">Junior High School</option>
                <option value="Senior High School">Senior High School</option>
              </select>
            </div>
            <div>
              <label className="text-sm text-slate-300">Capacity</label>
              <input
                type="number"
                className="input mt-2"
                value={classForm.capacity}
                onChange={(e) => setClassForm({ ...classForm, capacity: e.target.value })}
              />
            </div>
          </div>
          <div className="mt-6 flex gap-4">
            <button
              type="submit"
              disabled={classSubmitting}
              className="btn px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white disabled:opacity-50"
            >
              {classSubmitting ? "Saving…" : editingClass ? "Update Class" : "Add Class"}
            </button>
            <button
              type="button"
              onClick={() => setClassModal(false)}
              className="btn px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>

      {/* Subject modal */}
      <Modal
        isOpen={subjectModal}
        onClose={() => setSubjectModal(false)}
        title={editingSubject ? "Edit Subject" : "Add Subject"}
      >
        <form onSubmit={handleSubjectSubmit}>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-slate-300">Subject Name *</label>
              <input
                className="input mt-2"
                placeholder="e.g. Mathematics"
                value={subjectForm.name}
                onChange={(e) =>
                  setSubjectForm({ ...subjectForm, name: e.target.value })
                }
                required
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">Subject Code</label>
              <input
                className="input mt-2"
                placeholder="e.g. MATH101"
                value={subjectForm.code}
                onChange={(e) =>
                  setSubjectForm({ ...subjectForm, code: e.target.value })
                }
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">Assigned Class</label>
              <select
                className="select mt-2"
                value={subjectForm.classId}
                onChange={(e) =>
                  setSubjectForm({ ...subjectForm, classId: e.target.value })
                }
              >
                <option value="">All Classes (General)</option>
                {classesList.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="text-sm text-slate-300">Description</label>
              <textarea
                className="textarea mt-2"
                placeholder="Optional description"
                value={subjectForm.description}
                onChange={(e) =>
                  setSubjectForm({ ...subjectForm, description: e.target.value })
                }
              />
            </div>
          </div>
          <div className="mt-6 flex gap-4">
            <button
              type="submit"
              disabled={subjectSubmitting}
              className="btn px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white disabled:opacity-50"
            >
              {subjectSubmitting
                ? "Saving…"
                : editingSubject
                ? "Update Subject"
                : "Add Subject"}
            </button>
            <button
              type="button"
              onClick={() => setSubjectModal(false)}
              className="btn px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>

      {/* Income Item modal */}
      <Modal
        isOpen={incModal}
        onClose={() => setIncModal(false)}
        title="Add Income Item"
      >
        <form onSubmit={handleIncSubmit}>
          <div className="grid gap-4">
            <div>
              <label className="text-sm text-slate-300">Item Name *</label>
              <input
                className="input mt-2"
                placeholder="e.g. School Fees, Donation, Canteen Sales"
                value={incForm.name}
                onChange={(e) => setIncForm({ ...incForm, name: e.target.value })}
                required
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">Description</label>
              <textarea
                className="textarea mt-2"
                placeholder="Optional description"
                value={incForm.description}
                onChange={(e) =>
                  setIncForm({ ...incForm, description: e.target.value })
                }
              />
            </div>
          </div>
          <div className="mt-6 flex gap-4">
            <button
              type="submit"
              disabled={incSubmitting}
              className="btn px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white disabled:opacity-50"
            >
              {incSubmitting ? "Saving…" : "Add Income Item"}
            </button>
            <button
              type="button"
              onClick={() => setIncModal(false)}
              className="btn px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>

      {/* Expense Item modal */}
      <Modal
        isOpen={expModal}
        onClose={() => setExpModal(false)}
        title="Add Expense Item"
      >
        <form onSubmit={handleExpSubmit}>
          <div className="grid gap-4">
            <div>
              <label className="text-sm text-slate-300">Item Name *</label>
              <input
                className="input mt-2"
                placeholder="e.g. Utilities, Staff Lunch, Stationery"
                value={expForm.name}
                onChange={(e) => setExpForm({ ...expForm, name: e.target.value })}
                required
              />
            </div>
            <div>
              <label className="text-sm text-slate-300">Description</label>
              <textarea
                className="textarea mt-2"
                placeholder="Optional description"
                value={expForm.description}
                onChange={(e) =>
                  setExpForm({ ...expForm, description: e.target.value })
                }
              />
            </div>
          </div>
          <div className="mt-6 flex gap-4">
            <button
              type="submit"
              disabled={expSubmitting}
              className="btn px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white disabled:opacity-50"
            >
              {expSubmitting ? "Saving…" : "Add Expense Item"}
            </button>
            <button
              type="button"
              onClick={() => setExpModal(false)}
              className="btn px-5 py-2 rounded-xl bg-slate-600 hover:bg-slate-500 text-white"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>
    </section>
  );
}
