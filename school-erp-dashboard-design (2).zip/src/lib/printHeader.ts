import { SchoolInfo } from "@/components/SchoolProvider";

/**
 * Generates the HTML string for the school letterhead
 * used in all printed documents (bills, payslips, report cards, receipts).
 */
export function schoolHeaderHtml(info: SchoolInfo): string {
  const logo = info.logoUrl
    ? `<img src="${info.logoUrl}" alt="" style="width:50px;height:50px;border-radius:8px;object-fit:cover;margin:0 auto 4px" />`
    : "";
  return `
    <div style="text-align:center;margin-bottom:16px;border-bottom:2px solid #333;padding-bottom:12px">
      ${logo}
      <h2 style="margin:0;font-size:22px;font-weight:800">${info.name}</h2>
      <p style="margin:2px 0;color:#555;font-size:12px;font-style:italic">${info.motto}</p>
      <p style="margin:2px 0;color:#666;font-size:11px">${info.address} &nbsp;|&nbsp; ${info.phone} &nbsp;|&nbsp; ${info.email}</p>
    </div>
  `;
}

/**
 * Opens a print window with the school header and content.
 */
export function printWithHeader(info: SchoolInfo, bodyHtml: string, title: string) {
  const w = window.open("", "_blank");
  if (!w) return;
  w.document.write(`
    <html><head><title>${title}</title>
    <style>
      body{font-family:Arial,sans-serif;padding:32px;color:#111;max-width:750px;margin:auto}
      table{width:100%;border-collapse:collapse;margin:10px 0}
      th,td{padding:7px 10px;border-bottom:1px solid #ddd;text-align:left}
      th{background:#f5f5f5;font-weight:600}
      .right{text-align:right}
      h2{margin:0}h4{margin:14px 0 4px}
      .total-row{font-weight:bold;border-top:2px solid #333}
      .highlight{font-size:18px;padding:14px;border-radius:8px;text-align:center;margin-top:16px;font-weight:bold}
    </style></head><body>
    ${schoolHeaderHtml(info)}
    ${bodyHtml}
    </body></html>
  `);
  w.document.close();
  w.print();
}
