/** Role-based permission definitions */

export interface AuthUser {
  id: number;
  username: string;
  role: "admin" | "headmaster" | "finance" | "registrar" | "teacher";
  fullName: string;
  staffId: number | null;
  classId: number | null;
}

export interface NavItem {
  href: string;
  icon: string;
  label: string;
  roles: string[]; // which roles can see this item — empty = everyone
}

export const NAV_ITEMS: NavItem[] = [
  { href: "/", icon: "fa-home", label: "Dashboard", roles: [] },
  { href: "/school-profile", icon: "fa-school", label: "School Profile", roles: ["admin", "headmaster"] },
  { href: "/students", icon: "fa-user-graduate", label: "Students", roles: ["admin", "headmaster", "registrar"] },
  { href: "/staff", icon: "fa-chalkboard-teacher", label: "Staff", roles: ["admin", "headmaster"] },
  { href: "/attendance", icon: "fa-calendar-check", label: "Attendance", roles: ["admin", "headmaster", "registrar", "teacher"] },
  { href: "/sign-log", icon: "fa-door-open", label: "Sign In / Out", roles: ["admin", "headmaster", "registrar"] },
  { href: "/academics", icon: "fa-book-open", label: "Academics", roles: ["admin", "headmaster", "teacher"] },
  { href: "/billing", icon: "fa-file-invoice", label: "Student Billing", roles: ["admin", "headmaster", "finance"] },
  { href: "/finance", icon: "fa-money-bill-wave", label: "Finance", roles: ["admin", "finance"] },
  { href: "/payroll", icon: "fa-wallet", label: "Payroll", roles: ["admin", "finance"] },
  { href: "/inventory", icon: "fa-boxes", label: "Inventory", roles: ["admin", "headmaster"] },
  { href: "/assets", icon: "fa-tools", label: "Assets", roles: ["admin", "headmaster"] },
  { href: "/feeding", icon: "fa-utensils", label: "Feeding", roles: ["admin", "headmaster"] },
  { href: "/reports", icon: "fa-chart-bar", label: "Reports", roles: ["admin", "headmaster", "finance"] },
  { href: "/letters", icon: "fa-envelope-open-text", label: "Letters", roles: ["admin", "headmaster"] },
  { href: "/settings", icon: "fa-cog", label: "Settings", roles: ["admin"] },
  { href: "/settings/users", icon: "fa-users-cog", label: "User Accounts", roles: ["admin"] },
  { href: "/training", icon: "fa-graduation-cap", label: "Training Docs", roles: ["admin", "headmaster"] },
];

export function getVisibleNavItems(role: string | null): NavItem[] {
  if (!role) return NAV_ITEMS; // no auth = show all (pre-login)
  return NAV_ITEMS.filter(item => item.roles.length === 0 || item.roles.includes(role));
}

export function getUserFromCookie(): AuthUser | null {
  if (typeof document === "undefined") return null;
  try {
    const match = document.cookie.split("; ").find(c => c.startsWith("erp_user="));
    if (!match) return null;
    return JSON.parse(decodeURIComponent(match.split("=").slice(1).join("=")));
  } catch {
    return null;
  }
}

export function clearAuthCookie() {
  document.cookie = "erp_user=; path=/; max-age=0";
}
