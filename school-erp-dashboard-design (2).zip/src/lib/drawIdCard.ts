/** Cross-browser rounded rectangle */
function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number | [number, number, number, number]) {
  const [tl, tr, br, bl] = typeof r === "number" ? [r, r, r, r] : r;
  ctx.beginPath(); ctx.moveTo(x + tl, y); ctx.lineTo(x + w - tr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + tr); ctx.lineTo(x + w, y + h - br);
  ctx.quadraticCurveTo(x + w, y + h, x + w - br, y + h); ctx.lineTo(x + bl, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - bl); ctx.lineTo(x, y + tl);
  ctx.quadraticCurveTo(x, y, x + tl, y); ctx.closePath();
}

function loadImg(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    if (src.startsWith("http")) img.crossOrigin = "anonymous";
    img.onload = () => resolve(img); img.onerror = () => reject(new Error("Image load failed")); img.src = src;
  });
}

function saveCanvasAsImage(canvas: HTMLCanvasElement, filename: string) {
  try {
    const dataUrl = canvas.toDataURL("image/png");
    const byteString = atob(dataUrl.split(",")[1]);
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) ia[i] = byteString.charCodeAt(i);
    const blob = new Blob([ab], { type: "image/png" });
    const blobUrl = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = blobUrl; a.download = filename;
    a.style.position = "fixed"; a.style.left = "-9999px"; document.body.appendChild(a);
    setTimeout(() => { a.click(); setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(blobUrl); }, 1000); }, 100);
  } catch {
    try {
      const dataUrl = canvas.toDataURL("image/png");
      const w = window.open(); if (w) { w.document.write(`<html><body style="margin:0;display:flex;justify-content:center;align-items:center;min-height:100vh;background:#111"><img src="${dataUrl}" style="max-width:100%"/></body></html>`); w.document.close(); }
    } catch { alert("Could not download. Please try a different browser."); }
  }
}

function drawPlaceholder(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  ctx.fillStyle = "rgba(255,255,255,0.15)"; ctx.font = "60px Arial,sans-serif"; ctx.textAlign = "center";
  ctx.fillText("?", x + w / 2, y + h / 2 + 20);
}

function label(ctx: CanvasRenderingContext2D, lbl: string, val: string, x: number, y: number, lblColor: string, valColor: string) {
  ctx.font = "14px Arial,sans-serif"; ctx.fillStyle = lblColor;
  const lblWidth = ctx.measureText(lbl).width; ctx.fillText(lbl, x, y);
  ctx.fillStyle = valColor; ctx.font = "16px Arial,sans-serif"; ctx.fillText(val || "—", x + lblWidth + 8, y);
}

async function drawHeader(ctx: CanvasRenderingContext2D, W: number, schoolName: string, schoolLogoUrl: string | undefined, subtitle: string, bgColor: string, subtitleColor: string) {
  ctx.fillStyle = bgColor;
  rr(ctx, 0, 0, W, 80, [24, 24, 0, 0]); ctx.fill();

  let textX = W / 2;
  // Draw school logo in header if available
  if (schoolLogoUrl) {
    try {
      const logo = await loadImg(schoolLogoUrl);
      const lSize = 44; const lx = 16; const ly = 18;
      ctx.save(); rr(ctx, lx, ly, lSize, lSize, 8); ctx.clip();
      ctx.drawImage(logo, lx, ly, lSize, lSize); ctx.restore();
      textX = (W + lSize + 24) / 2; // shift text slightly right
    } catch { /* skip logo */ }
  }

  ctx.fillStyle = "#fff"; ctx.font = "bold 24px Arial,sans-serif"; ctx.textAlign = "center";
  ctx.fillText(schoolName.toUpperCase(), textX, 38);
  ctx.font = "13px Arial,sans-serif"; ctx.fillStyle = subtitleColor;
  ctx.fillText(subtitle, textX, 60);
}

// ── Student ID Card ──

export interface StudentCardData {
  studentId: string; firstName: string; lastName: string; className: string;
  dateOfBirth: string; parentName: string; parentPhone: string;
  photoUrl: string | null; qrDataUrl: string;
  schoolName?: string; schoolLogoUrl?: string;
}

export async function downloadStudentIdCard(data: StudentCardData) {
  const W = 720, H = 460;
  const canvas = document.createElement("canvas"); canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d"); if (!ctx) { alert("Canvas not supported"); return; }

  try {
    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, "#0f172a"); g.addColorStop(1, "#1e3a5f");
    ctx.fillStyle = g; rr(ctx, 0, 0, W, H, 24); ctx.fill();

    await drawHeader(ctx, W, data.schoolName || "School", data.schoolLogoUrl, "Student Identification Card", "#0284c7", "#bae6fd");

    const px = 40, py = 105, pw = 140, ph = 170;
    ctx.fillStyle = "rgba(255,255,255,0.08)"; rr(ctx, px, py, pw, ph, 12); ctx.fill();
    if (data.photoUrl) { try { const img = await loadImg(data.photoUrl); ctx.save(); rr(ctx, px, py, pw, ph, 12); ctx.clip(); ctx.drawImage(img, px, py, pw, ph); ctx.restore(); } catch { drawPlaceholder(ctx, px, py, pw, ph); } } else { drawPlaceholder(ctx, px, py, pw, ph); }

    ctx.textAlign = "left"; let ty = 135;
    ctx.fillStyle = "#fff"; ctx.font = "bold 24px Arial,sans-serif";
    ctx.fillText(`${data.firstName} ${data.lastName}`, 210, ty); ty += 38; ctx.font = "16px Arial,sans-serif";
    label(ctx, "ID:", data.studentId, 210, ty, "#7dd3fc", "#e0f2fe"); ty += 32;
    label(ctx, "Class:", data.className, 210, ty, "#7dd3fc", "#e0f2fe"); ty += 32;
    label(ctx, "DOB:", data.dateOfBirth, 210, ty, "#7dd3fc", "#e0f2fe");

    label(ctx, "Guardian:", data.parentName, 40, 330, "#7dd3fc", "#fff");
    label(ctx, "Phone:", data.parentPhone, 40, 356, "#7dd3fc", "#fff");

    if (data.qrDataUrl) { try { const qr = await loadImg(data.qrDataUrl); ctx.drawImage(qr, W - 165, 295, 125, 125); } catch {} }

    ctx.strokeStyle = "rgba(255,255,255,0.12)"; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(40, H - 38); ctx.lineTo(W - 40, H - 38); ctx.stroke();
    ctx.fillStyle = "rgba(255,255,255,0.3)"; ctx.font = "11px Arial,sans-serif"; ctx.textAlign = "center";
    ctx.fillText(`This card is the property of ${data.schoolName || "the school"}`, W / 2, H - 16);

    saveCanvasAsImage(canvas, `${data.studentId}_ID_Card.png`);
  } catch (err) { console.error(err); alert("Failed to generate ID card."); }
}

// ── Staff ID Card ──

export interface StaffCardData {
  staffId: string; firstName: string; lastName: string; position: string;
  department: string; qualification: string; phone: string;
  photoUrl: string | null; qrDataUrl: string;
  schoolName?: string; schoolLogoUrl?: string;
}

export async function downloadStaffIdCard(data: StaffCardData) {
  const W = 720, H = 460;
  const canvas = document.createElement("canvas"); canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d"); if (!ctx) { alert("Canvas not supported"); return; }

  try {
    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, "#0f172a"); g.addColorStop(1, "#1a3a2a");
    ctx.fillStyle = g; rr(ctx, 0, 0, W, H, 24); ctx.fill();

    await drawHeader(ctx, W, data.schoolName || "School", data.schoolLogoUrl, "Staff Identification Card", "#059669", "#a7f3d0");

    const px = 40, py = 105, pw = 140, ph = 170;
    ctx.fillStyle = "rgba(255,255,255,0.08)"; rr(ctx, px, py, pw, ph, 12); ctx.fill();
    if (data.photoUrl) { try { const img = await loadImg(data.photoUrl); ctx.save(); rr(ctx, px, py, pw, ph, 12); ctx.clip(); ctx.drawImage(img, px, py, pw, ph); ctx.restore(); } catch { drawPlaceholder(ctx, px, py, pw, ph); } } else { drawPlaceholder(ctx, px, py, pw, ph); }

    ctx.textAlign = "left"; let ty = 135;
    ctx.fillStyle = "#fff"; ctx.font = "bold 24px Arial,sans-serif";
    ctx.fillText(`${data.firstName} ${data.lastName}`, 210, ty); ty += 38; ctx.font = "16px Arial,sans-serif";
    label(ctx, "ID:", data.staffId, 210, ty, "#6ee7b7", "#d1fae5"); ty += 32;
    label(ctx, "Position:", data.position, 210, ty, "#6ee7b7", "#d1fae5"); ty += 32;
    label(ctx, "Dept:", data.department, 210, ty, "#6ee7b7", "#d1fae5");

    label(ctx, "Qualification:", data.qualification, 40, 330, "#6ee7b7", "#fff");
    label(ctx, "Phone:", data.phone, 40, 356, "#6ee7b7", "#fff");

    if (data.qrDataUrl) { try { const qr = await loadImg(data.qrDataUrl); ctx.drawImage(qr, W - 165, 295, 125, 125); } catch {} }

    ctx.strokeStyle = "rgba(255,255,255,0.12)"; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(40, H - 38); ctx.lineTo(W - 40, H - 38); ctx.stroke();
    ctx.fillStyle = "rgba(255,255,255,0.3)"; ctx.font = "11px Arial,sans-serif"; ctx.textAlign = "center";
    ctx.fillText(`This card is the property of ${data.schoolName || "the school"}`, W / 2, H - 16);

    saveCanvasAsImage(canvas, `${data.staffId}_ID_Card.png`);
  } catch (err) { console.error(err); alert("Failed to generate ID card."); }
}
