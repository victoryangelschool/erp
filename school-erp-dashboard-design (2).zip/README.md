# School ERP System

A comprehensive school administration suite built with Next.js, PostgreSQL, and Drizzle ORM.

## Features

- **Student Management** — Registration, profiles, photos, GPS, ID cards with QR codes
- **Staff Management** — Profiles, qualifications, Tax ID, SSNIT, ID cards
- **Academics** — Curriculum, assessments, continuous assessment (CA), grading (30:70/40:60/50:50), timetable, report cards, analytics
- **Student Billing** — Term bills for school/class/individual, installment payments, printable statements
- **Finance** — Income & expense tracking, student QR lookup for payments
- **Payroll** — 6 allowances, Ghana deductions (SSNIT, PAYE), loans/advances, payslips
- **Inventory & Assets** — Stock tracking, asset register with depreciation and photos
- **Feeding** — Daily menus, kitchen inventory, multi-item requisition forms
- **Reports** — 9 report types (financial + academic) with CSV export and printing
- **Sign In/Out** — Daily entry/exit via ID or QR camera scan
- **Letter Writing** — School letterhead, signature upload, share via email/WhatsApp
- **Role-Based Access** — 5 roles (Admin, Headmaster, Finance, Registrar, Teacher)
- **School Branding** — Logo and name on sidebar, ID cards, all printouts

## Tech Stack

- **Frontend**: Next.js 16 (App Router), React, Tailwind CSS
- **Backend**: Next.js API Routes
- **Database**: PostgreSQL with Drizzle ORM
- **Auth**: Cookie-based sessions with SHA-256 password hashing
- **QR Codes**: `qrcode` (generation) + `jsqr` (camera scanning)

## Setup

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/school-erp.git
cd school-erp
```

### 2. Install dependencies

```bash
npm install
```

### 3. Set up the database

Create a PostgreSQL database and update `.env`:

```bash
cp .env.example .env
# Edit .env with your DATABASE_URL
```

**Free PostgreSQL options:**
- [Neon](https://neon.tech) — recommended, free tier
- [Supabase](https://supabase.com) — free tier

### 4. Push the schema

```bash
npx drizzle-kit push
```

### 5. Seed the database

```bash
npm run build
npm start
# Then visit: http://localhost:3000/api/seed (POST request)
# Or: curl -X POST http://localhost:3000/api/seed
```

### 6. Start the development server

```bash
npm run dev
```

Visit `http://localhost:3000/login`

**Default admin credentials:** `admin` / `admin123`

## Deployment on Vercel

1. Push to GitHub
2. Go to [vercel.com](https://vercel.com) → Import Project
3. Add `DATABASE_URL` in Environment Variables
4. Deploy

After deployment, run the seed by visiting `https://your-app.vercel.app/api/seed` (POST).

## User Roles

| Role | Access |
|---|---|
| **Administrator** | Full unrestricted access |
| **Headmaster** | Full access, read-only finance |
| **Finance Officer** | Billing, payments, payroll, reports |
| **Registrar** | Student records, admissions, attendance |
| **Teacher** | Own class attendance, grading, CA only |

## Training Documents

After deployment, access:
- Training Manual: `/training-manual.html`
- Training Presentation: `/training-presentation.html`
- Training Hub: `/training`

## License

MIT
